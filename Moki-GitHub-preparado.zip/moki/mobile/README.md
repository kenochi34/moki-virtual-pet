# Moki mobile export

This directory preserves the separately supplied Capacitor project export.
It contains Android and iOS project files, `capacitor.config.json`, a
`package.json`, a `pnpm-lock.yaml`, and bundled web output.

Application ID: `com.delbolsillo.moki`.

No APK, AAB, IPA, signing keystore, or private signing certificate was present
in the supplied archive. Deployment-specific `android/app/google-services.json`
has been excluded; configure your own Firebase app when rebuilding push support.
Firebase client configuration is not treated as a private server credential.

The bundled web output has not been rebuilt from the source in the repository
root. The two exports can describe different points in the project's history.
Do not present this snapshot as a reproducible build of an APK without checking
the source revision and actual release binary.

The exported Capacitor configuration uses `webDir: "dist"`. A new native sync
requires a populated `dist` directory and the appropriate dependencies and
Android/iOS toolchains. The root web export's hosted services and assets also
need to be addressed before that build is self-contained.

Existing generated wrappers, comments, and vendor notices have been preserved.
No native compilation or signing was performed during preparation.
