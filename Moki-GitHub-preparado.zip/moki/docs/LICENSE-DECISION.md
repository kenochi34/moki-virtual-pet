# License decision — owner review required

No project-wide license was present in the supplied export. None has been applied
by this preparation. A public GitHub repository alone does not make a project
open source: an appropriate license must grant the relevant permissions.

The owner should choose the intended licensing terms for their own code before
publishing. Two common options to review are:

- MIT: https://choosealicense.com/licenses/mit/
- GNU GPL v3: https://choosealicense.com/licenses/gpl-3.0/

After choosing, add the exact license text as `LICENSE`, fill in the correct
copyright attribution where applicable, and update the README and package
metadata. Preserve third-party license notices. Explicitly decide how artwork,
logos, and other assets are covered; the source ZIP does not contain the hosted
images or their original license metadata.

This document is a pending decision record, not a license grant.

Reference:
https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository
