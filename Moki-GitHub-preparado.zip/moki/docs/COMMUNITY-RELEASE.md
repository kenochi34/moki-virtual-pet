# Nothing community release preparation

The rule supplied by the project owner requires open source, a source-hosting
link, a VirusTotal report for a download, and an additional Koodous report for
an APK.

## Still required

1. Select and apply the project license.
2. Create the owner's GitHub account and source repository. Upload the extracted
   source tree, not just a ZIP attachment, so contributors can inspect the code.
3. Resolve export gaps or clearly describe them in the repository. Confirm the
   source corresponds to the shared release; neither APK bytes nor an APK hash
   were supplied for verification in this preparation.
4. Analyze the exact downloadable APK with VirusTotal and Koodous and retain the
   actual result URLs. Record its SHA-256 alongside its version/build number.
5. Add the repository and report URLs to the community post. If the APK changes,
   make sure the linked reports describe the replacement file.

No account, repository, public release, or external scan has been created by
this preparation. Do not claim a clean scan or completed open-source compliance
until the corresponding results and license actually exist.
