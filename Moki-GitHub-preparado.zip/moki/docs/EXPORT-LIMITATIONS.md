# Export limitations and validation

## What was checked

- Archive structure and paths, without executing uploaded code.
- Presence of the original React/TypeScript source, including `pages/_index.tsx`.
- Relative source imports and references to hosted assets.
- Common hardcoded credential patterns; no matches in the prepared text files.
- Environment configuration: the database value in the original web export was
  a placeholder. The VAPID key was a public key, not a private signing key.
- File-by-file comparison of retained game source against the uploaded export.

These checks are not VirusTotal or Koodous malware analyses. No report links
were generated, no dependencies were installed, and no web/native build or
runtime test was completed in this environment.

## Hosted images

The web export references 225 distinct literal `/_cdn/...` asset paths in runtime
source/configuration, but contains none of those images. This includes sprites,
rooms, maps, and icons. `asset-inventory.json` records the paths and referring
files. It is an inventory of literal references, not proof that no dynamically
constructed paths exist.

Restoring images at the same URL paths avoids changing the game code. With the
exported Hono server, corresponding files can be placed under
`static/_cdn/static/`; a development-only server needs equivalent static serving.

## Notifications and backend

- `helpers/mokiPushDelivery.tsx` imports `@floot/push`.
- `endpoints/moki/push_POST.ts` imports `@floot/queueTask`.
- These modules are Floot services; their implementations are not in this ZIP or
  declared as installable dependencies in the web export.
- `helpers/pushClient.tsx` expects `/floot-push-sw.js`, which is absent from the web
  source export. Generated copies exist in the mobile snapshot; that does not
  replace the hosted backend or provide standalone notification delivery.
- `helpers/schema.tsx` contains database types, not a full SQL migration or a
  schema dump. No user/device database records were included or requested.
- The reminder schedule and native platform manifest overrides were retained
  under `docs/floot/`, away from the public static directory.

Hosting this code on GitHub does not require moving the running application off
Floot. These limitations matter for independent builds and contributions.

## Dependencies and tests

The original web dependency versions have been preserved. The web export has no
lockfile. Its existing test files are preserved, but it does not include a
standalone test runner configuration or all test dependencies (for example,
`@testing-library/react`). Existing tests were not reported as passing here.

## Configuration changes in this prepared copy

- Excluded `env.json`; added blank `env.example.json` and a credential-aware
  `.gitignore`.
- Replaced the public VAPID configuration with an empty value for a new deployment.
- Excluded native Firebase deployment configuration.
- Replaced the private development-history README with public-facing documentation.
- Excluded internal development prompts, conversations, and future-content notes;
  retained the runtime-related schedule and native manifest overrides as references.
- Added package name/version and command aliases without changing dependencies.
- Left gameplay, animations, sounds, timers, adoption, and progression code intact.
- Did not apply a license or publish anything.

Floot's export documentation:
https://floot.com/docs/projects/self-hosting
