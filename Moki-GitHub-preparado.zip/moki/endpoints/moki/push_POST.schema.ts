import {z} from 'zod';
import superjson from 'superjson';
import {mokiReminderPolicy} from '../../helpers/mokiReminderPolicy';
const webEndpoint=z.string().max(4096).url().refine(value=>{try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&!u.hash&&(u.hostname==='fcm.googleapis.com'||u.hostname==='updates.push.services.mozilla.com'||u.hostname.endsWith('.push.services.mozilla.com')||u.hostname==='web.push.apple.com'||u.hostname.endsWith('.web.push.apple.com')||u.hostname.endsWith('.notify.windows.com'));}catch{return false;}},'Unsupported push endpoint');
const token=z.string().min(20).max(4096).regex(/^[A-Za-z0-9:_-]+$/);
const subscription=z.union([
 z.object({endpoint:webEndpoint,keys:z.object({p256dh:z.string().min(60).max(200).regex(/^[A-Za-z0-9_=-]+$/),auth:z.string().min(16).max(100).regex(/^[A-Za-z0-9_=-]+$/)})}).passthrough(),
 z.object({fcmToken:token,platform:z.enum(['android','ios'])}).passthrough(),
 z.object({apnsToken:z.string().regex(/^[a-fA-F0-9]{64}$/),platform:z.literal('ios')}).passthrough()
]);
export const schema=z.object({deviceKey:z.string().regex(/^[a-f0-9]{64}$/),action:z.enum(['subscribe','sync','remove','test']),delaySeconds:z.union([z.literal(0),z.literal(10)]).optional(),subscription:subscription.optional(),snapshot:mokiReminderPolicy.snapshot.optional(),preferences:mokiReminderPolicy.preferences.optional(),language:z.enum(['es','en']).optional(),timezone:z.string().max(100).refine(mokiReminderPolicy.validZone).optional()}).superRefine((data,ctx)=>{if(data.action==='subscribe'&&(!data.subscription||!data.snapshot||!data.preferences||!data.language||!data.timezone))ctx.addIssue({code:z.ZodIssueCode.custom,message:'Subscription context is missing'});if(data.action==='sync'&&(!data.snapshot||!data.preferences||!data.language||!data.timezone))ctx.addIssue({code:z.ZodIssueCode.custom,message:'Reminder context is missing'});});
export type InputType=z.infer<typeof schema>;
export type OutputType={ok:boolean;enabled:boolean;testAccepted?:boolean;testScheduled?:boolean};
export const postMokiPush=async(input:InputType,init?:RequestInit):Promise<OutputType>=>{
 const data=schema.parse(input);const response=await fetch('/_api/moki/push',{method:'POST',body:superjson.stringify(data),...init,headers:{'Content-Type':'application/json',...init?.headers}});const result=superjson.parse<OutputType&{error?:string}>(await response.text());if(!response.ok)throw new Error(result.error??'sync_failed');return result;
};