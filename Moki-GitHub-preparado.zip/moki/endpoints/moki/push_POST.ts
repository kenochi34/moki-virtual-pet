import {createHash,randomUUID} from 'node:crypto';
import {queueTask} from '@floot/queueTask';
import {sql} from 'kysely';
import superjson from 'superjson';
import {schema,type OutputType} from './push_POST.schema';
import {db} from '../../helpers/db';
import type {Json} from '../../helpers/schema';
import {mokiPushDelivery} from '../../helpers/mokiPushDelivery';
const response=(value:OutputType|{error:string},status=200)=>new Response(superjson.stringify(value),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
export async function handle(request:Request){
 try{
  const body=await request.text();if(body.length>32768)return response({error:'request_too_large'},413);
  let decoded:unknown;try{decoded=superjson.parse(body);}catch{return response({error:'invalid_request'},400);}
  const parsed=schema.safeParse(decoded);if(!parsed.success)return response({error:'invalid_request'},400);
  const input=parsed.data,deviceHash=createHash('sha256').update(input.deviceKey).digest('hex'),now=new Date();
  if(input.action==='remove'){await db.deleteFrom('mokiPushDevices').where('deviceHash','=',deviceHash).execute();return response({ok:true,enabled:false});}
  if(input.action==='test'){
   if(input.delaySeconds===10){
    const reservation=await db.transaction().execute(async trx=>{
     const row=await trx.selectFrom('mokiPushDevices').select(['enabled','lastTestAt']).where('deviceHash','=',deviceHash).forUpdate().executeTakeFirst();
     if(!row?.enabled)return {error:'not_subscribed',status:403};
     if(row.lastTestAt&&now.getTime()-row.lastTestAt.getTime()<60000)return {error:'test_cooldown',status:429};
     await trx.updateTable('mokiPushDevices').set({lastTestAt:now}).where('deviceHash','=',deviceHash).execute();
     return {previous:row.lastTestAt};
    });
    if('error'in reservation)return response({error:reservation.error!},reservation.status);
    const testId=randomUUID();
    try{
     // The request ends after enqueueing. Leaving the app cannot cancel the worker.
     await queueTask('mokiTestNotification',{deviceHash,scheduledAt:now.toISOString(),testId},{budget:1});
    }catch{
     await db.updateTable('mokiPushDevices').set({lastTestAt:reservation.previous}).where('deviceHash','=',deviceHash).where('lastTestAt','=',now).execute();
     console.warn('Moki background test could not be queued',{testId});
     return response({error:'notification_service_unavailable'},503);
    }
    console.info('Moki background test queued',{testId});
    return response({ok:true,enabled:true,testScheduled:true});
   }
   const testTime=new Date();
   const outcome=await db.transaction().execute(async trx=>{
    const row=await trx.selectFrom('mokiPushDevices').selectAll().where('deviceHash','=',deviceHash).forUpdate().executeTakeFirst();
    if(!row?.enabled)return {error:'not_subscribed',status:403};
    if(row.lastTestAt&&testTime.getTime()-row.lastTestAt.getTime()<60000)return {error:'test_cooldown',status:429};
    await trx.updateTable('mokiPushDevices').set({lastTestAt:testTime}).where('deviceHash','=',deviceHash).execute();
    let result;try{result=await mokiPushDelivery(row,'test');}catch{return {error:'push_not_accepted',status:502};}
    if(result?.gone){await trx.deleteFrom('mokiPushDevices').where('deviceHash','=',deviceHash).execute();return {error:'subscription_expired',status:410};}
    return result?.success?{success:true}:{error:'push_not_accepted',status:502};
   });
   return 'success'in outcome?response({ok:true,enabled:true,testAccepted:true}):response({error:outcome.error!},outcome.status);
  }
  const context={snapshot:input.snapshot as Json,preferences:input.preferences as Json,language:input.language!,timezone:input.timezone!,lastSeenAt:now,updatedAt:now,nextCheckAt:new Date(now.getTime()+15*60000)};
  if(input.action==='subscribe'){
   const sub=input.subscription!,identity=typeof sub.endpoint==='string'?sub.endpoint:typeof sub.fcmToken==='string'?sub.fcmToken:String(sub.apnsToken);
   // Device credentials own the row; a different credential cannot take over its subscription.
   await db.insertInto('mokiPushDevices').values({deviceHash,subscriptionIdentity:identity,subscription:sub as Json,enabled:true,...context}).onConflict(oc=>oc.column('deviceHash').doUpdateSet({subscriptionIdentity:identity,subscription:sub as Json,enabled:true,...context,revision:sql`moki_push_devices.revision + 1`})).execute();
   return response({ok:true,enabled:true});
  }
  const row=await db.updateTable('mokiPushDevices').set({...context,revision:sql`revision + 1`}).where('deviceHash','=',deviceHash).where('enabled','=',true).returning('deviceHash').executeTakeFirst();
  return row?response({ok:true,enabled:true}):response({error:'not_subscribed'},403);
 }catch(error){const code=(error as {code?:string}).code;if(code==='23505')return response({error:'subscription_in_use'},409);console.error('Moki push request failed',{name:error instanceof Error?error.name:'unknown',code:code??'none'});return response({error:'notification_service_unavailable'},503);}
}