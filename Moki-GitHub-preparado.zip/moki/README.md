# Moki — Virtual Pet

A retro virtual pet game built with React and TypeScript in Floot, with
Capacitor projects for Android and iOS.

**Source release candidate, prepared October 3, 2026.** The source reports
`0.2.3-beta`. No open-source license has been selected yet, and this package
must not be described as an already licensed open-source release.

## What's included

- Pet care, growth, adoption, accessories, and local game saves.
- Moki, bird, alien, and robot families, plus the divine collection.
- Minigames, exercise, exploration, and synthesized retro sounds and voices.
- Notification client code, backend handlers, and reminder logic.
- The separately exported Android/iOS project under `mobile/`.

The game logic and interface files have not been changed during packaging.
The public Web Push key was replaced with an empty configuration value.

## Project layout

| Path | Contents |
| --- | --- |
| `pages/` | Application page and layout |
| `components/` | UI and game screens |
| `helpers/` | Game logic, artwork definitions, audio, notifications, existing tests |
| `endpoints/` | Notification API and request schema |
| `static/` | Web manifest; hosted images are not in the supplied export |
| `mobile/` | Separate Capacitor Android/iOS export and its own dependencies |
| `docs/` | Export limitations, asset inventory, provenance, and release preparation |

## Local setup — partial export

This is a source snapshot, **not a verified standalone distribution**. Read
[`docs/EXPORT-LIMITATIONS.md`](docs/EXPORT-LIMITATIONS.md) before trying to run it.
It lacks hosted images, database migrations, and Floot service implementations.

Use Node.js and pnpm compatible with the versions in `package.json`:

```sh
pnpm install
pnpm run dev
```

The browser game references image paths under `/_cdn/static/`. Restore the
referenced images before expecting the original visuals. The inventory is in
[`docs/asset-inventory.json`](docs/asset-inventory.json). The development server
does not reproduce Floot's hosted services or storage.

The exported web build and server commands are:

```sh
pnpm run build
pnpm run start
```

Before running the server, copy `env.example.json` to local `env.json`, set your
own database configuration, and implement the missing platform services.
Set the matching public Web Push key in `helpers/_publicConfigs.tsx` when
configuring a replacement notification service. Never commit private keys.

These commands were documented from the export; they were not run successfully
as part of this preparation. No compiled APK is included.

## Android and iOS

See [`mobile/README.md`](mobile/README.md). Its bundled web files came from a
separate export and have not been verified to match the root source or the APK
shared in the community. Rebuild and record the release's source revision
before claiming that correspondence.

## Contributing and license

License selection is pending. See
[`docs/LICENSE-DECISION.md`](docs/LICENSE-DECISION.md).
Third-party dependencies retain their own licenses. No ownership or
redistribution rights in third-party components are changed by this package.

## Community release

Publish readable source with the chosen license, and include the VirusTotal
and Koodous reports for the **exact APK offered for download**. See
[`docs/COMMUNITY-RELEASE.md`](docs/COMMUNITY-RELEASE.md).

Made with Floot.
