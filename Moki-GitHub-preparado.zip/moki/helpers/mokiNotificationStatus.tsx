type Channel={id:string;importance?:number};
type Messaging={
  checkPermissions?:()=>Promise<{receive:string}>;
  listChannels?:()=>Promise<{channels:Channel[]}>;
  getDeliveredNotifications?:()=>Promise<{notifications:unknown[]}>;
};
type Capacitor={isNativePlatform?:()=>boolean;getPlatform?:()=>string;Plugins?:{FirebaseMessaging?:Messaging;PushNotifications?:Messaging}};
async function inspect(cap:Capacitor|undefined=(globalThis as unknown as {Capacitor?:Capacitor}).Capacitor) {
  const platform=cap?.isNativePlatform?.()?cap.getPlatform?.()??'native':'web';
  const native=platform!=='web'?(cap?.Plugins?.FirebaseMessaging??cap?.Plugins?.PushNotifications):undefined;
  if(!native)return {platform,permission:'unknown',channel:'unknown',visible:null as number|null};
  const [permission,channels,delivered]=await Promise.allSettled([
    Promise.resolve().then(()=>native.checkPermissions?.()),
    Promise.resolve().then(()=>platform==='android'?native.listChannels?.():undefined),
    Promise.resolve().then(()=>native.getDeliveredNotifications?.())
  ]);
  const list=channels.status==='fulfilled'?channels.value?.channels:undefined;
  const channel=list?.find(item=>item.id==='fcm_fallback_notification_channel');
  const importance=channel?.importance;
  return {
    platform,
    permission:permission.status==='fulfilled'?permission.value?.receive??'unknown':'unknown',
    channel:platform!=='android'?'not_applicable':!list?'unknown':!channel?'missing':importance===0?'blocked':typeof importance!=='number'?'unknown':importance<3?'silent':importance<4?'standard':'heads_up',
    visible:delivered.status==='fulfilled'?delivered.value?.notifications?.length??null:null
  };
}
export const mokiNotificationStatus={inspect};
