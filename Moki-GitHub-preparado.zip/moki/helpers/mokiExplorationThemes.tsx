import {mokiVariants} from './mokiVariants';
import {mokiExpeditions,type RouteId} from './mokiExpeditions';
type Language='es'|'en';
type Family=ReturnType<typeof mokiVariants.family>;
type Point={left:string;top:string};
type Positions=Record<'home'|'garden'|'stream'|'forest'|'ruins'|'gardenTravel'|'streamTravel',Point>;
const at=(x:number,y:number):Point=>({left:x+'%',top:y+'%'});
const worlds:Record<Family,{src:string;positions:Positions}>={
 moki:{src:'/_cdn/static/4823d2fa-907b-4d65-a811-c157f731285a.png',positions:{home:at(26,59),garden:at(74,84),stream:at(26,42),forest:at(42,20),ruins:at(78,32),gardenTravel:at(55,64),streamTravel:at(40,44)}},
 robot:{src:'/_cdn/static/c3b3f44d-ef51-4174-978f-fdf384cf6b5b.png',positions:{home:at(26,73),garden:at(74,82),stream:at(26,52),forest:at(31,24),ruins:at(75,35),gardenTravel:at(51,68),streamTravel:at(41,53)}},
 alien:{src:'/_cdn/static/4b2bfff5-d2db-4f73-908e-7dba6ededc38.png',positions:{home:at(23,69),garden:at(26,53),stream:at(75,82),forest:at(44,24),ruins:at(79,40),gardenTravel:at(40,51),streamTravel:at(53,65)}},
 bird:{src:'/_cdn/static/b30bf32f-ab03-4284-8442-63ba45e0d2dd.png',positions:{home:at(24,72),garden:at(74,65),stream:at(26,43),forest:at(48,21),ruins:at(80,35),gardenTravel:at(53,61),streamTravel:at(39,44)}},
 divine:{src:'/_cdn/static/fbc71ab2-cae5-4606-a583-7c2b1dc29a01.png',positions:{home:at(26,74),garden:at(26,51),stream:at(74,76),forest:at(46,24),ruins:at(79,42),gardenTravel:at(40,52),streamTravel:at(57,61)}}
};
const copy={
 robot:{
  es:{home:'Estudio de Moki',forest:'Puerto orbital',ruins:'Torre del núcleo',discovery:'Encontró un rincón nuevo entre luces y circuitos.',garden:['Plaza solar','Un paseo entre paneles solares y jardines de la ciudad.'],stream:['Circuito urbano','Cruza el canal de luz y descubre los caminos de la ciudad.']},
  en:{home:'Moki’s studio',forest:'Orbital harbor',ruins:'Core tower',discovery:'Found a new corner among lights and circuits.',garden:['Solar plaza','A short walk among solar panels and city gardens.'],stream:['City circuit','Cross the glowing canal and discover the city paths.']}
 },
 alien:{
  es:{home:'Refugio cósmico',forest:'Bosque luminoso',ruins:'Portal orbital',discovery:'Siguió un destello entre plantas de otro mundo.',garden:['Jardín estelar','Un paseo entre flores brillantes bajo lunas lejanas.'],stream:['Senda de cristales','Sigue el río luminoso entre cristales de otro planeta.']},
  en:{home:'Cosmic haven',forest:'Glowing forest',ruins:'Orbital portal',discovery:'Followed a glimmer among otherworldly plants.',garden:['Star garden','A short walk among glowing flowers beneath distant moons.'],stream:['Crystal trail','Follow the glowing river through another planet’s crystals.']}
 },
 bird:{
  es:{home:'Nido de Moki',forest:'Árbol de las brisas',ruins:'Templo de plumas',discovery:'Descubrió un tesoro entre ramas y pétalos.',garden:['Claro del nido','Una salida corta hasta las flores junto al nido.'],stream:['Camino de las copas','Recorre puentes de cuerda entre las casas de los árboles.']},
  en:{home:'Moki’s nest',forest:'Breeze tree',ruins:'Feather temple',discovery:'Discovered a treasure among branches and petals.',garden:['Nest clearing','A short outing to the flowers beside the nest.'],stream:['Canopy trail','Explore rope bridges between the treetop houses.']}
 },
 divine:{
  es:{home:'Refugio celeste',forest:'Arboleda celeste',ruins:'Santuario del eclipse',discovery:'Encontró un pequeño regalo entre luces del alba.',garden:['Jardín del alba','Pasea entre flores doradas sobre las nubes.'],stream:['Senda de auroras','Cruza los puentes de cristal siguiendo las auroras.']},
  en:{home:'Celestial haven',forest:'Celestial grove',ruins:'Eclipse sanctuary',discovery:'Found a little gift among the lights of dawn.',garden:['Dawn garden','Stroll among golden flowers above the clouds.'],stream:['Aurora trail','Follow the auroras across crystal bridges.']}
 }
};
function get(variant:unknown,language:Language){
 const family=mokiVariants.family(variant),world=worlds[family];
 const custom=family==='moki'?undefined:copy[family][language];
 const routes={} as Record<RouteId,{name:string;description:string}>;
 for(const id of ['garden','stream'] as const)routes[id]={name:custom?.[id][0]??mokiExpeditions.routes[id].name[language],description:custom?.[id][1]??mokiExpeditions.routes[id].description[language]};
 const labels=custom?{home:custom.home,forest:custom.forest,ruins:custom.ruins,discovery:custom.discovery}:{};
 const robotCare=family==='robot'?(language==='es'?{food:'Energía',rest:'Reposo',clean:'Desgaste',care:'Prepara sus cuidados: energía de 40% o más; fatiga y desgaste hasta 60%; ánimo de 40% o más.'}:{food:'Energy',rest:'Standby',clean:'Wear',care:'Prepare care: energy at least 40%; fatigue and wear at 60% or less; mood at least 40%.'}):{};
 return {...world,family,routes,labels:{...labels,...robotCare}};
}
export const mokiExplorationThemes={get};
