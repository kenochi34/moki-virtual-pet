type ItemId = 'leafClip'|'streamScarf'|'cap'|'glasses'|'bandana'|'beanie'|'bow'|'flower'|'scarf'|'visor'|'starGlasses'|'medal'|'headphones'|'crown'|'celestialCirclet'|'auroraRibbon'|'prismGlasses'|'witchHat'|'pumpkinGlasses'|'batScarf';
type Slot = 'head'|'eyes'|'neck';
type Outfit = Record<Slot,ItemId|null>;
type Wardrobe = {owned:ItemId[];equipped:Outfit};
type Item = {id:ItemId;slot:Slot;price:number;source:'shop'|'reward'|'expedition';chests:number;name:{es:string;en:string};color:string;family?:'divine';collection?:'halloween'};
const catalog:Item[] = [
 {id:'leafClip',slot:'head',price:0,source:'expedition',chests:0,name:{es:'Brote del jardín',en:'Garden sprout'},color:'#91d78a'},
 {id:'streamScarf',slot:'neck',price:0,source:'expedition',chests:0,name:{es:'Pañuelo del arroyo',en:'Stream scarf'},color:'#7ed9ea'},
 {id:'bandana',slot:'neck',price:5,source:'shop',chests:0,name:{es:'Pañuelo Cometa',en:'Comet bandana'},color:'#ed8a78'},
 {id:'cap',slot:'head',price:10,source:'shop',chests:0,name:{es:'Gorra Estelar',en:'Star cap'},color:'#b5a0ed'},
 {id:'glasses',slot:'eyes',price:15,source:'shop',chests:0,name:{es:'Gafas Sol',en:'Sun glasses'},color:'#f3c66d'},
 {id:'beanie',slot:'head',price:12,source:'shop',chests:0,name:{es:'Gorro Lunar',en:'Moon beanie'},color:'#7ec9f5'},
 {id:'bow',slot:'head',price:14,source:'shop',chests:0,name:{es:'Lazo Pop',en:'Pop bow'},color:'#ff82bc'},
 {id:'flower',slot:'head',price:16,source:'shop',chests:0,name:{es:'Flor Solar',en:'Sunflower clip'},color:'#ffda65'},
 {id:'scarf',slot:'neck',price:18,source:'shop',chests:0,name:{es:'Bufanda Menta',en:'Mint scarf'},color:'#91edd0'},
 {id:'visor',slot:'eyes',price:22,source:'shop',chests:0,name:{es:'Visor Neón',en:'Neon visor'},color:'#65ebef'},
 {id:'starGlasses',slot:'eyes',price:25,source:'shop',chests:0,name:{es:'Gafas Estrella',en:'Star glasses'},color:'#fc84d0'},
 {id:'medal',slot:'neck',price:0,source:'reward',chests:1,name:{es:'Medalla Amistad',en:'Friendship medal'},color:'#ffe397'},
 {id:'headphones',slot:'head',price:0,source:'reward',chests:3,name:{es:'Auriculares Ritmo',en:'Rhythm headphones'},color:'#bdaaef'},
 {id:'crown',slot:'head',price:0,source:'reward',chests:7,name:{es:'Corona Cosmos',en:'Cosmic crown'},color:'#f8cf66'},
 {id:'celestialCirclet',slot:'head',price:30,source:'shop',chests:0,family:'divine',name:{es:'Diadema Alba',en:'Dawn circlet'},color:'#ffe4a0'},
 {id:'auroraRibbon',slot:'neck',price:20,source:'shop',chests:0,family:'divine',name:{es:'Lazo Aurora',en:'Aurora ribbon'},color:'#b2eed7'},
 {id:'prismGlasses',slot:'eyes',price:25,source:'shop',chests:0,family:'divine',name:{es:'Gafas Prisma',en:'Prism glasses'},color:'#d9c2ef'},
 {id:'witchHat',slot:'head',price:18,source:'shop',chests:0,collection:'halloween',name:{es:'Sombrero de Bruja',en:'Witch hat'},color:'#b696ed'},
 {id:'pumpkinGlasses',slot:'eyes',price:15,source:'shop',chests:0,collection:'halloween',name:{es:'Gafas Calabaza',en:'Pumpkin glasses'},color:'#ffa84f'},
 {id:'batScarf',slot:'neck',price:10,source:'shop',chests:0,collection:'halloween',name:{es:'Pañuelo Murciélago',en:'Bat scarf'},color:'#c49ee8'},
];
function create():Wardrobe{return {owned:[],equipped:{head:null,eyes:null,neck:null}};}
function restore(value:unknown):Wardrobe {
 const next=create();if(!value||typeof value!=='object')return next;
 const raw=value as {owned?:unknown;equipped?:unknown};
 if(Array.isArray(raw.owned))next.owned=catalog.filter(item=>(raw.owned as unknown[]).includes(item.id)).map(item=>item.id);
 if(raw.equipped&&typeof raw.equipped==='object'){
  const equipped=raw.equipped as Record<string,unknown>;
  for(const item of catalog)if(next.owned.includes(item.id)&&equipped[item.slot]===item.id)next.equipped[item.slot]=item.id;
 }
 return next;
}
function unlock(wardrobe:Wardrobe,chests:number):Wardrobe {
 const earned=catalog.filter(item=>item.source==='reward'&&chests>=item.chests&&!wardrobe.owned.includes(item.id)).map(item=>item.id);
 return earned.length?{...wardrobe,owned:[...wardrobe.owned,...earned]}:wardrobe;
}
function compatible(id:string,variant:string){const item=catalog.find(item=>item.id===id);return !!item&&(!item.family||variant==='auri');}
function forVariant(wardrobe:Wardrobe,variant:string):Wardrobe {const equipped={...wardrobe.equipped};for(const slot of ['head','eyes','neck'] as const)if(equipped[slot]&&!compatible(equipped[slot]!,variant))equipped[slot]=null;return {...wardrobe,equipped};}
function buy(wardrobe:Wardrobe,stars:number,id:string,variant='green',divineUnlocked=false){
 const item=catalog.find(item=>item.id===id);
 if(!item)return {wardrobe,stars,status:'invalid' as const};
 if(wardrobe.owned.includes(item.id))return {wardrobe,stars,status:'owned' as const};
 if(item.family&&(!divineUnlocked||!compatible(id,variant)))return {wardrobe,stars,status:'locked' as const};
 if(item.source!=='shop')return {wardrobe,stars,status:'locked' as const};
 if(!Number.isSafeInteger(stars)||stars<item.price)return {wardrobe,stars,status:'insufficient' as const};
 return {stars:stars-item.price,wardrobe:{owned:[...wardrobe.owned,item.id],equipped:{...wardrobe.equipped,[item.slot]:item.id}},status:'bought' as const};
}
function equip(wardrobe:Wardrobe,id:string|null,variant='green'):Wardrobe{
 if(id===null)return {...wardrobe,equipped:create().equipped};
 const item=catalog.find(item=>item.id===id);
 if(!item||!wardrobe.owned.includes(item.id)||!compatible(id,variant))return wardrobe;
 return {...wardrobe,equipped:{...wardrobe.equipped,[item.slot]:wardrobe.equipped[item.slot]===item.id?null:item.id}};
}
function preview(wardrobe:Wardrobe,id:ItemId|null,variant='green'):Outfit{
 const item=catalog.find(item=>item.id===id);return item&&compatible(item.id,variant)?{...wardrobe.equipped,[item.slot]:item.id}:{...wardrobe.equipped};
}
export const mokiWardrobe={catalog,create,restore,unlock,buy,equip,preview,compatible,forVariant};
