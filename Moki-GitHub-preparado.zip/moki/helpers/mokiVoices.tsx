import {mokiVariants} from './mokiVariants';
type Variant=typeof mokiVariants.ids[number];
export type MokiVoiceCue='fed'|'clean'|'awake'|'exercise'|'pet';
type Profile={hz:number;pace:number;wave:OscillatorType;notes:readonly number[]};
type Note={at:number;hz:number;length:number;volume:number;endHz:number;type:OscillatorType;contour:number[]};
// Each variant has a stable pitch, rhythm and syllable pattern, rather than a random voice.
const profiles:Record<Variant,Profile>={
 green:{hz:440,pace:1,wave:'triangle',notes:[1,.87,1.15]},
 lila:{hz:345,pace:1.18,wave:'sine',notes:[1,1.12]},
 amber:{hz:550,pace:.82,wave:'triangle',notes:[1,1.28,.94,1.12]},
 cielo:{hz:1130,pace:.9,wave:'sine',notes:[1,1.2,1.08]},
 coral:{hz:1320,pace:.76,wave:'triangle',notes:[1,1.18,.94,1.25]},
 noche:{hz:850,pace:1.14,wave:'sine',notes:[1,.8,1.06]},
 orbita:{hz:390,pace:1,wave:'sine',notes:[1,1.22,.95]},
 nova:{hz:570,pace:.78,wave:'triangle',notes:[1,1.38,1.12]},
 nebula:{hz:285,pace:1.24,wave:'sine',notes:[1,1.15]},
 bit:{hz:620,pace:.95,wave:'square',notes:[1,1.25,1.5]},
 volt:{hz:790,pace:.72,wave:'square',notes:[1,1.5,1.25,2]},
 tuerca:{hz:310,pace:1.12,wave:'triangle',notes:[1,1.19,1.34]},
 auri:{hz:690,pace:1.12,wave:'sine',notes:[1,1.25,1.5]}
};
const cues:Record<MokiVoiceCue,{pitch:number;pace:number;shape:readonly number[]}>={
 fed:{pitch:.92,pace:1.05,shape:[1,.96,1.07]},
 clean:{pitch:1.1,pace:.9,shape:[.92,1.14,1.06]},
 awake:{pitch:.87,pace:1.12,shape:[.82,1,1.25]},
 exercise:{pitch:1.05,pace:.9,shape:[1,1.18,1.35]},
 pet:{pitch:1,pace:1,shape:[1,1.09,1.03]}
};
function phrase(value:Variant,cue:MokiVoiceCue):Note[]{
 const variant=mokiVariants.restore(value),family=mokiVariants.family(variant),p=profiles[variant],m=cues[cue];
 const notes:Note[]=[];let at=0;
 p.notes.forEach((ratio,index)=>{
  const hz=p.hz*ratio*m.pitch*m.shape[index%m.shape.length];
  const length=(family==='bird'?.075:family==='robot'?.08:family==='divine'?.17:.12)*p.pace*m.pace;
  const contour=family==='bird'?[hz*.76,hz*1.25,hz*.93]
   :family==='alien'?[hz*.82,hz*1.22,hz*.88,hz*1.15,hz*.91]
   :family==='robot'?[hz,hz,hz]
   :family==='divine'?[hz,hz*1.003,hz]
   :[hz*.9,hz*1.08,hz*.96];
  notes.push({at,hz:contour[0],length,volume:family==='robot'?.12:family==='bird'?.18:.23,endHz:contour[contour.length-1],type:p.wave,contour});
  if(family==='divine')notes.push({at:at+.025,hz:hz*2,length:length*.8,volume:.065,endHz:hz*2,type:'sine',contour:[hz*2,hz*2]});
  at+=length+(family==='robot'?.042:.025)*p.pace;
 });
 return notes;
}
function afterAnimation(phase:string):MokiVoiceCue|null{
 return phase==='eating'?'fed':phase==='bathing'?'clean':phase==='waking'?'awake':null;
}
// An offline result can be shown, but must not suddenly speak when the app is reopened.
function completedWorkout(previous:number|null,result:{complete:boolean;endedAt:number}|null,now:number):boolean{
 return previous!==null&&Boolean(result?.complete)&&result!.endedAt>previous&&now>=result!.endedAt&&now-result!.endedAt<1500;
}
export const mokiVoices={phrase,afterAnimation,completedWorkout};
