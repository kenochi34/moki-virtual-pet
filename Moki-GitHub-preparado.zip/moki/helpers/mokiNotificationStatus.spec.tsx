import {mokiNotificationStatus} from './mokiNotificationStatus';
import {schema} from '../endpoints/moki/push_POST.schema';

describe('Moki notification diagnosis',()=>{
  function device(receive:string,importance:number,visible=0){
    return {isNativePlatform:()=>true,getPlatform:()=> 'android',Plugins:{FirebaseMessaging:{
      checkPermissions:async()=>({receive}),
      listChannels:async()=>({channels:[{id:'fcm_fallback_notification_channel',importance}]}),
      getDeliveredNotifications:async()=>({notifications:Array.from({length:visible},()=>({}))})
    }}};
  }
  it('distinguishes permission denied from a disabled channel',async()=>{
    expect((await mokiNotificationStatus.inspect(device('denied',5))).permission).toBe('denied');
    const channel=await mokiNotificationStatus.inspect(device('granted',0));
    expect(channel.permission).toBe('granted');expect(channel.channel).toBe('blocked');
  });
  it('does not confuse no pop-up with blocked notifications',async()=>{
    expect((await mokiNotificationStatus.inspect(device('granted',2))).channel).toBe('silent');
    expect((await mokiNotificationStatus.inspect(device('granted',3))).channel).toBe('standard');
    const result=await mokiNotificationStatus.inspect(device('granted',5,2));
    expect(result.channel).toBe('heads_up');expect(result.visible).toBe(2);
  });
  it('reports unavailable native checks honestly without breaking settings',async()=>{
    const cap=device('granted',5);
    cap.Plugins.FirebaseMessaging.listChannels=async()=>{throw new Error('Unavailable');};
    const result=await mokiNotificationStatus.inspect(cap);
    expect(result.permission).toBe('granted');expect(result.channel).toBe('unknown');
    expect((await mokiNotificationStatus.inspect({isNativePlatform:()=>false})).platform).toBe('web');
  });
  it('keeps old APK test requests compatible and limits background tests to ten seconds',()=>{
    const base={deviceKey:'a'.repeat(64),action:'test'};
    expect(schema.safeParse(base).success).toBeTrue();
    expect(schema.safeParse({...base,delaySeconds:0}).success).toBeTrue();
    expect(schema.safeParse({...base,delaySeconds:10}).success).toBeTrue();
    for(const delaySeconds of [-1,11,300])expect(schema.safeParse({...base,delaySeconds}).success).toBeFalse();
  });
});
