import {mokiPet} from './mokiPet';
import {mokiExpeditions} from './mokiExpeditions';
import {mokiAccessories} from './mokiAccessories';
const start=1800000000000;
function ready(stage:'baby'|'teen'|'adult'='adult'){
 const egg=mokiPet.create(start);
 return {...egg,stage,hunger:20,fatigue:20,dirt:20,mood:90,care:100};
}
describe('Exploration persistence and rewards',()=>{
 it('migrates old saves without replacing the pet, collection or coins',()=>{
  const p=ready();p.name='Toby';p.player.stars=27;
  const old=JSON.parse(JSON.stringify(p));delete old.expedition;delete old.expeditionReward;delete old.player.expeditions;
  const saved=mokiPet.restore(JSON.stringify(old),start);
  expect(saved.name).toBe('Toby');expect(saved.player.stars).toBe(27);expect(saved.variant).toBe(p.variant);expect(saved.expedition).toBeNull();expect(saved.player.expeditions).toEqual({garden:0,stream:0});
 });
 it('persists an unfinished trip and resolves it once at its deadline',()=>{
  const p=mokiPet.startExpedition(ready(),'garden',start,.73),id=p.expedition!.id;
  const saved=mokiPet.restore(JSON.stringify(p),start+7*60000);
  expect(saved.expedition!.id).toBe(id);
  const done=mokiPet.advance(saved,start+15*60000);
  expect(done.expedition).toBeNull();expect(done.expeditionReward!.complete).toBeTrue();expect(done.player.expeditions.garden).toBe(1);expect(done.player.stars).toBe(0);
  const again=mokiPet.restore(JSON.stringify(done),start+60*60000);
  expect(again.player.expeditions.garden).toBe(1);expect(again.expeditionReward).toEqual(done.expeditionReward);
  const claimed=mokiPet.claimExpedition(again,id,start+60*60000);
  expect(claimed.player.stars).toBe(done.expeditionReward!.coins);expect(claimed.expeditionReward).toBeNull();
  expect(mokiPet.claimExpedition(claimed,id,start+60*60000).player.stars).toBe(claimed.player.stars);
 });
 it('has the same care costs online and after closing for hours',()=>{
  const p=mokiPet.startExpedition(ready(),'stream',start,.25);
  let active=p;for(let i=1;i<=120;i++)active=mokiPet.advance(active,start+i*60000);
  const offline=mokiPet.restore(JSON.stringify(p),start+120*60000);
  for(const key of ['hunger','fatigue','dirt','mood','care'] as const)expect(active[key]).toBeCloseTo(offline[key],7);
  expect(offline.expeditionReward).toEqual(active.expeditionReward);expect(offline.expeditionReward!.endedAt).toBe(start+3600000);
 });
 it('does not reset or extend a trip on clock rollback',()=>{
  const p=mokiPet.startExpedition(ready(),'garden',start,.5);
  const before=mokiPet.restore(JSON.stringify(p),start-60000);
  expect(before.expedition).toEqual(p.expedition);expect(before.updatedAt).toBe(start);expect(before.expeditionReward).toBeNull();
 });
 it('blocks care, games, gym, another trip and adoption while away',()=>{
  const p=mokiPet.startExpedition(ready(),'garden',start,.5);
  expect(mokiPet.act(p,'feed',start).hunger).toBe(p.hunger);
  expect(mokiPet.act(p,'sleep',start).sleeping).toBeFalse();
  expect(mokiPet.act(p,'startWorkout',start).workout).toBeNull();
  expect(mokiPet.startGame(p,start).minigame).toBeNull();
  expect(mokiPet.startMemory(p,start).memory).toBeNull();
  expect(mokiPet.startExpedition(p,'stream',start).expedition!.id).toBe(p.expedition!.id);
  expect(mokiPet.renew(p,start+1000).bornAt).toBe(p.bornAt);
 });
 it('requires suitable age, awake state and care before departure',()=>{
  const p=ready('baby');
  expect(mokiPet.startExpedition(p,'garden',start).expedition).not.toBeNull();
  expect(mokiPet.startExpedition(p,'stream',start).expedition).toBeNull();
  expect(mokiPet.startExpedition({...p,sleeping:true},'garden',start).expedition).toBeNull();
  expect(mokiPet.startExpedition({...p,hunger:61},'garden',start).expedition).toBeNull();
  expect(mokiPet.startExpedition({...p,mood:39},'garden',start).expedition).toBeNull();
  expect(mokiPet.startExpedition(mokiPet.create(start),'garden',start).expedition).toBeNull();
 });
 it('returns early with partial coins, no accessory and no completed trip',()=>{
  const p=mokiPet.startExpedition(ready(),'stream',start,.3);
  const early=mokiPet.recallExpedition(p,start+30*60000),full=mokiExpeditions.finish(p.expedition!,start+3600000,p.player.expeditions,[]);
  expect(early.expedition).toBeNull();expect(early.expeditionReward!.coins).toBe(Math.floor(full.coins/2));expect(early.expeditionReward!.accessory).toBeNull();expect(early.expeditionReward!.complete).toBeFalse();expect(early.player.expeditions.stream).toBe(0);
  expect(mokiPet.recallExpedition(early,start+31*60000).expeditionReward).toEqual(early.expeditionReward);
 });
 it('guarantees a missing accessory by the fifth completed trip and keeps it on adoption',()=>{
  const p=ready();p.player.expeditions.stream=4;
  const run=mokiPet.startExpedition(p,'stream',start,.99);
  const done=mokiPet.advance(run,start+3600000);
  expect(done.expeditionReward!.accessory).toBe('streamScarf');
  expect(mokiPet.renew(done,start+3600000).bornAt).toBe(start);
  const claimed=mokiPet.claimExpedition(done,done.expeditionReward!.id,start+3600000);
  expect(claimed.player.wardrobe.owned).toContain('streamScarf');
  const saved=mokiPet.restore(JSON.stringify(claimed),start+3600000);
  expect(saved.player.wardrobe.owned).toContain('streamScarf');
  const next=mokiPet.renew(saved,start+3600001);
  expect(next.player.wardrobe.owned).toContain('streamScarf');expect(next.player.expeditions.stream).toBe(5);
 });
 it('does not reroll rewards or grant owned accessories again',()=>{
  const p=ready();p.player.wardrobe.owned=['leafClip'];p.player.expeditions.garden=8;
  const run=mokiPet.startExpedition(p,'garden',start,.01);
  const a=mokiPet.advance(run,start+900000),b=mokiPet.restore(JSON.stringify(run),start+900000);
  expect(a.expeditionReward).toEqual(b.expeditionReward);expect(a.expeditionReward!.accessory).toBeNull();
 });
 it('keeps the earned bag even if the player returns after neglect caused death',()=>{
  const p=mokiPet.startExpedition(ready(),'garden',start,.5);
  const later=mokiPet.restore(JSON.stringify(p),start+7*24*3600000);
  expect(later.life.diedAt).not.toBeNull();expect(later.expeditionReward!.complete).toBeTrue();
  const claimed=mokiPet.claimExpedition(later,later.expeditionReward!.id,start+7*24*3600000);
  expect(claimed.player.stars).toBe(later.expeditionReward!.coins);
 });
 it('drops malformed expedition data without resetting the save',()=>{
  const p=mokiPet.startExpedition(ready(),'garden',start,.5);p.player.stars=12;
  const bad={...p,expedition:{...p.expedition,endsAt:Infinity}};
  const restored=mokiPet.restore(JSON.stringify(bad),start);
  expect(restored.expedition).toBeNull();expect(restored.player.stars).toBe(12);expect(restored.stage).toBe('adult');
 });
 it('provides visible pixel art for both discoverable accessories',()=>{
  expect(mokiAccessories.icon('leafClip').length).toBeGreaterThan(0);
  expect(mokiAccessories.icon('streamScarf').length).toBeGreaterThan(0);
 });
});
