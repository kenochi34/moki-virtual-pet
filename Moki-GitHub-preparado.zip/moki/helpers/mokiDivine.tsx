import {mokiVariants} from './mokiVariants';
function progress(raised:unknown,unlocked=false){
 const required=mokiVariants.ids.filter(id=>mokiVariants.family(id)!=='divine');
 const known=mokiVariants.history(raised),complete=required.filter(id=>known.includes(id));
 const groups=mokiVariants.families.filter(family=>family!=='divine').map(family=>({family,ids:required.filter(id=>mokiVariants.family(id)===family)}));
 return {required,complete,groups,total:required.length,count:complete.length,percent:Math.round(complete.length/required.length*100),unlocked:unlocked||complete.length===required.length};
}
export const mokiDivine={progress};