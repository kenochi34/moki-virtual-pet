type Condition = { stage: 'egg'|'baby'|'teen'|'adult'; dirt:number; hunger:number; mood:number };
function read(pet: Condition) {
  const born=pet.stage!=='egg';
  return { dirty:born && pet.dirt>=50, veryDirty:born && pet.dirt>=80,
    hungry:born && pet.hunger>=65, veryHungry:born && pet.hunger>=85,
    sad:born && pet.mood<40, verySad:born && pet.mood<20 };
}
function draw(ctx:CanvasRenderingContext2D, stage:Condition['stage'], frame:number, condition:ReturnType<typeof read>,fit?:{eyes:number[];ink:string;cream:string;bird?:boolean}) {
  if(stage==='egg' || frame>3) return;
  ctx.save();
  // These tiny, integer-aligned facial poses use the original sprite palette.
  // Mouth anchors are calibrated separately for the baby, teen and adult sheets.
  if(fit?.bird && condition.sad) {
    ctx.fillStyle=fit.ink;
    const [x,y,w,,rx,ry,rw]=fit.eyes;
    ctx.fillRect(x,y-2,Math.max(2,w-1),1);ctx.fillRect(x+w-1,y-3,1,1);
    ctx.fillRect(rx+1,ry-2,Math.max(2,rw-1),1);ctx.fillRect(rx,ry-3,1,1);
  } else if(!fit?.bird && (condition.sad || condition.hungry)) {
    const [x,y]=fit ? [Math.round((fit.eyes[0]+fit.eyes[2]+fit.eyes[4])/2)-3,Math.min(fit.eyes[1]+fit.eyes[3],fit.eyes[5]+fit.eyes[7])] : stage==='baby' ? [22,41] : stage==='teen' ? [21,34] : [18,32];
    ctx.fillStyle=fit?.cream??'#fff1ce'; ctx.fillRect(x,y,7,4);
    ctx.fillStyle=fit?.ink??'#092b3c';
    if(condition.sad) {
      ctx.fillRect(x+2,y+1,3,1);
      ctx.fillRect(x+1,y+2,1,1);ctx.fillRect(x+5,y+2,1,1);
    } else {
      ctx.fillRect(x+2,y,3,1);ctx.fillRect(x+1,y+1,5,2);ctx.fillRect(x+2,y+3,3,1);
      ctx.fillStyle='#867152';ctx.fillRect(x+3,y+2,2,1);
    }
  }
  if(condition.dirty) {
    // Clip dirt to opaque sprite pixels; stains can never float off its body.
    ctx.globalCompositeOperation='source-atop';
    const patches=stage==='baby' ? [[18,48],[34,50],[38,34],[28,53]] :
      stage==='teen' ? [[24,45],[35,49],[44,46],[17,37]] : [[29,43],[42,50],[16,52],[35,35]];
    patches.slice(0,condition.veryDirty ? 4 : 2).forEach(([x,y],i)=>{
      const offset=frame===1 && i===0 ? -1 : 0;
      ctx.fillStyle='#867152';ctx.fillRect(x,y+offset,3,2);ctx.fillRect(x+1,y+offset-1,2,1);
      ctx.fillStyle='#baaa85';ctx.fillRect(x,y+offset,1,1);
    });
  }
  ctx.restore();
}
export const mokiCondition = { read, draw };
