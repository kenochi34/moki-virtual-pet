import {mokiVoices,type MokiVoiceCue} from './mokiVoices';
import {mokiVariants} from './mokiVariants';
type Effect = 'catch' | 'button' | 'crack' | 'hatch' | 'heart' | 'eat' | 'bath' | 'sleep' | 'wake' | 'charge' | 'maintain' | 'powerDown' | 'powerUp';
function create() {
  let context: AudioContext | null = null;
  let master: GainNode | null = null;
  let enabled = true;
  let last = -Infinity;
  let lastEffect: Effect | null = null;
  let voiceRequest=0,voiceUntil=-Infinity,lastPet=-Infinity;
  let lastCue:MokiVoiceCue|null=null,lastCueAt=-Infinity;
  const voices = new Set<{ source: AudioScheduledSourceNode; gain: GainNode; group: string }>();
  function stop(group?: string) {
    if(!group||group==='voice'){voiceRequest++;voiceUntil=-Infinity;}
    for (const voice of voices) {
      if (group && voice.group !== group) continue;
      try { voice.source.stop(); } catch {}
      voice.source.disconnect(); voice.gain.disconnect(); voices.delete(voice);
    }
  }
  function getContext() {
    if (typeof window === 'undefined') return null;
    if (!context || context.state === 'closed') {
      const Constructor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Constructor) return null;
      context = new Constructor();
      master = context.createGain(); master.gain.value = .8;
      const filter = context.createBiquadFilter();
      filter.type = 'lowpass'; filter.frequency.value = 2600; filter.Q.value = .5;
      master.connect(filter); filter.connect(context.destination);
    }
    if (context.state === 'suspended') void context.resume().catch(() => {});
    return context;
  }
  function emitTone(ctx:AudioContext,now:number,group:string,at: number, hz: number, length: number, volume = .3, endHz = hz, type: OscillatorType = 'triangle',contour?:readonly number[]) {
        if (voices.size >= 32) return;
        const source = ctx.createOscillator(), gain = ctx.createGain();
        const start = now + at + .006;
        source.type = type;
        source.frequency.setValueAtTime(hz, start);
        if(contour&&contour.length>1)contour.slice(1).forEach((hz,i)=>source.frequency.exponentialRampToValueAtTime(Math.max(40,hz),start+length*(i+1)/(contour.length-1)));
        else source.frequency.exponentialRampToValueAtTime(Math.max(40, endHz), start + length);
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(volume, start + .009);
        gain.gain.exponentialRampToValueAtTime(.0001, start + length);
        source.connect(gain); gain.connect(master!);
        const voice = { source, gain, group }; voices.add(voice);
        source.onended = () => { source.disconnect(); gain.disconnect(); voices.delete(voice); };
        source.start(start); source.stop(start + length + .015);
      }
  function voice(variant:typeof mokiVariants.ids[number],cue:MokiVoiceCue){
    if(!enabled||(typeof document!=='undefined'&&document.hidden))return;
    try {
      const ctx=getContext();if(!ctx||!master)return;
      const ticket=++voiceRequest,requested=performance.now();
      const speak=()=>{
        if(ticket!==voiceRequest||!enabled||document.hidden||ctx.state!=='running'||performance.now()-requested>300)return;
        const now=ctx.currentTime;
        if(cue==='pet'&&(now-lastPet<.65||now<voiceUntil))return;
        if(cue===lastCue&&now-lastCueAt<.15)return;
        stop('voice');
        if(cue!=='pet'){stop('action');stop('tap');}
        if(cue==='pet')lastPet=now;
        lastCue=cue;lastCueAt=now;
        const phrase=mokiVoices.phrase(variant,cue);
        voiceUntil=now+Math.max(...phrase.map(note=>note.at+note.length))+.03;
        for(const n of phrase)emitTone(ctx,now,'voice',n.at,n.hz,n.length,n.volume,n.endHz,n.type,n.contour);
      };
      if(ctx.state==='running')speak();
      else void ctx.resume().then(speak).catch(()=>{});
    }catch{/* A voice must never interrupt a care action. */}
  }
  function play(effect: Effect, strength = 1) {
    if (!enabled || (typeof document !== 'undefined' && document.hidden)) return;
    try {
      const ctx = getContext();
      if (!ctx || !master) return;
      const now = ctx.currentTime;
      if (effect === lastEffect && now - last < .055) return;
      last = now; lastEffect = effect;
      const group = ['eat','bath','charge','maintain','powerDown','powerUp','sleep','wake'].includes(effect) ? 'action' : 'tap';
      if (group === 'action') stop('action');
      // Replace old taps rather than stacking loud voices during rapid tapping.
      if (group === 'tap') stop('tap');
      function tone(at:number,hz:number,length:number,volume=.3,endHz=hz,type:OscillatorType='triangle'){
        emitTone(ctx!,now,group,at,hz,length,volume,endHz,type);
      }
      function crack(at: number, volume: number) {
        const length = .075, size = Math.ceil(ctx!.sampleRate * length);
        const buffer = ctx!.createBuffer(1, size, ctx!.sampleRate), samples = buffer.getChannelData(0);
        let previous = 0;
        for (let i = 0; i < size; i++) { previous = (previous + Math.random() * .7 - .35) * .65; samples[i] = previous; }
        const source = ctx!.createBufferSource(), gain = ctx!.createGain();
        source.buffer = buffer;
        const start = now + at + .006;
        gain.gain.setValueAtTime(0,start); gain.gain.linearRampToValueAtTime(volume,start+.004);
        gain.gain.exponentialRampToValueAtTime(.0001,start+length);
        source.connect(gain); gain.connect(master!);
        const voice = {source,gain,group}; voices.add(voice);
        source.onended=()=>{ source.disconnect(); gain.disconnect(); voices.delete(voice); };
        source.start(start); source.stop(start+length+.01);
      }
      switch (effect) {
        case 'catch': tone(0,880,.075,.18,1175); break;
        case 'button': tone(0,640,.075,.17,850,'square'); break;
        case 'crack':
          crack(0,.55); tone(.015,190 + strength * 24,.09,.25,130);
          if (strength > 2) crack(.07,.3);
          break;
        case 'hatch':
          crack(0,.6);
          [523,659,784,1047].forEach((hz,i)=>tone(.08+i*.12,hz,.22,.3));
          break;
        case 'heart': tone(0,659,.16,.29,784); tone(.13,988,.24,.25,1047); break;
        case 'charge': [440,554,659,880].forEach((hz,i)=>tone(i*.6,hz,.18,.23,hz+35,'triangle'));break;
        case 'maintain': [0,.6,1.2,1.8].forEach((at,i)=>{tone(at,180+i*40,.12,.19,120,'triangle');tone(at+.14,530,.08,.13);});tone(2.9,880,.22,.2);break;
        case 'powerDown': [523,392,262,131].forEach((hz,i)=>tone(i*.3,hz,.28,.18,Math.max(90,hz-30),'triangle'));break;
        case 'powerUp': [196,294,440,659].forEach((hz,i)=>tone(i*.2,hz,.2,.2,hz+20,'triangle'));break;
        case 'eat':
          [0,.45,.9,1.55,2,2.5].forEach((at,i)=>tone(at,i%2 ? 280 : 340,.105,.35,170,'square'));
          tone(2.85,784,.18,.24); break;
        case 'bath':
          Array.from({length:12},(_,i)=>{ tone(i*.48,380+(i%3)*110,.14,.27,850); if(i%3===0) crack(i*.48+.09,.2); });
          tone(5.8,880,.24,.22,1100); break;
        case 'sleep': [523,440,330].forEach((hz,i)=>tone(i*.17,hz,.24,.22)); break;
        case 'wake': [330,440,659].forEach((hz,i)=>tone(i*.14,hz,.19,.22)); break;
      }
    } catch { /* Audio support must never interrupt caring for Moki. */ }
  }
  return {
    play, voice, stop,
    setEnabled(value: boolean) { enabled = value; if (!value) stop(); },
    dispose() { stop(); if (context) void context.close().catch(()=>{}); context=null; master=null; }
  };
}
export const mokiSounds = { create };
