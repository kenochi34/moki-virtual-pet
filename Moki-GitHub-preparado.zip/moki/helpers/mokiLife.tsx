import {mokiVariants} from './mokiVariants';
type Need='hunger'|'fatigue'|'dirt';
type Life={version:1;startedAt:number;criticalSince:Record<Need,number|null>;diedAt:number|null;cause:Need|null};
type Subject={stage:string;variant:string;sleeping:boolean;hunger:number;fatigue:number;dirt:number;updatedAt:number;life:Life};
const keys:Need[]=['hunger','fatigue','dirt'];
const threshold=95,graceMs=48*3600000;
function create(now:number):Life{return {version:1,startedAt:now,criticalSince:{hunger:null,fatigue:null,dirt:null},diedAt:null,cause:null};}
function restore(value:unknown,now:number):Life{
 const s=value as Life|undefined;
 if(!s||s.version!==1||!Number.isFinite(s.startedAt)||s.startedAt<0||!s.criticalSince)return create(now);
 const life=create(s.startedAt);
 for(const key of keys){const t=s.criticalSince[key];if(typeof t==='number'&&Number.isFinite(t)&&t>=s.startedAt&&t<=now)life.criticalSince[key]=t;}
 if(typeof s.diedAt==='number'&&Number.isFinite(s.diedAt)&&s.diedAt>=s.startedAt&&s.diedAt<=now&&keys.includes(s.cause as Need)){life.diedAt=s.diedAt;life.cause=s.cause;}
 return life;
}
function advance(pet:Subject,now:number):Life{
 const life={...pet.life,criticalSince:{...pet.life.criticalSince}};
 if(life.diedAt!==null)return life;
 if(pet.stage==='egg')return create(Math.max(now,life.startedAt));
 const end=Math.max(now,pet.updatedAt),from=Math.max(pet.updatedAt,life.startedAt),hours=Math.max(0,end-from)/3600000;
 const robot=mokiVariants.family(pet.variant)==='robot';
 const rates={hunger:pet.sleeping?(robot?-40:2):12,fatigue:pet.sleeping?-120:10,dirt:pet.sleeping?1.5:9};
 for(const key of keys){
  // Taking a rest (or plugging in a robot) starts recovery immediately.
  if(pet.sleeping&&(key==='fatigue'||robot&&key==='hunger')){life.criticalSince[key]=null;continue;}
  const rate=rates[key],start=Math.max(0,Math.min(100,pet[key]+rate*Math.max(0,from-pet.updatedAt)/3600000));
  const finish=Math.max(0,Math.min(100,start+rate*hours));
  if(finish<threshold){life.criticalSince[key]=null;continue;}
  const crossed=start>=threshold?from:from+(threshold-start)/rate*3600000;
  const since=start>=threshold&&life.criticalSince[key]!==null?life.criticalSince[key]!:crossed;
  life.criticalSince[key]=since;
  const deadline=since+graceMs;
  if(deadline<=end&&(life.diedAt===null||deadline<life.diedAt)){life.diedAt=deadline;life.cause=key;}
 }
 return life;
}
function status(life:Life,now=Date.now()){
 const active=keys.filter(key=>life.criticalSince[key]!==null).sort((a,b)=>life.criticalSince[a]!-life.criticalSince[b]!);
 const cause=life.cause??active[0]??null;
 const remaining=cause?Math.max(0,life.criticalSince[cause]!+graceMs-now):graceMs;
 return {dead:life.diedAt!==null,critical:active.length>0,cause,remainingHours:Math.ceil(remaining/3600000),active};
}
export const mokiLife={create,restore,advance,status,threshold,graceMs};