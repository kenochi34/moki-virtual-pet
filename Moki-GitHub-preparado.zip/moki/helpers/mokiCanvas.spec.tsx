import {mokiCanvas} from './mokiCanvas';
import {mokiAccessories} from './mokiAccessories';
import {mokiWardrobe} from './mokiWardrobe';
import {mokiVariantArt} from './mokiVariantArt';
import {mokiVariants} from './mokiVariants';
import {mokiWorkoutAnimation} from './mokiWorkoutAnimation';
import {mokiDivineMotion} from './mokiDivineMotion';
import {mokiAlienMotion} from './mokiAlienMotion';
import {mokiRobotMotion} from './mokiRobotMotion';

function context(blocked=false) {
  const fillRect=jasmine.createSpy('fillRect').and.callFake((...values:number[])=>{
    if(values.some(value=>!Number.isFinite(value)))throw new Error('Invalid accessory position');
  });
  const ctx={
    fillRect,save:()=>{},restore:()=>{},drawImage:jasmine.createSpy('drawImage'),
    putImageData:jasmine.createSpy('putImageData'),getTransform:()=>({e:0,f:0}),
    createImageData:(width:number,height:number)=>({data:new Uint8ClampedArray(width*height*4),width,height}),
    getImageData:(_x:number,_y:number,width:number,height:number)=>{
      if(blocked)throw new DOMException('The canvas has been tainted by cross-origin data.','SecurityError');
      const data=new Uint8ClampedArray(width*height*4);
      for(let y=15;y<60;y++)for(let x=8;x<55;x++){const i=(y*width+x)*4;data[i]=225;data[i+1]=170;data[i+2]=100;data[i+3]=255;}
      return {data,width,height};
    }
  };
  return ctx as unknown as CanvasRenderingContext2D;
}

describe('Moki canvas regressions',()=>{
  it('requests readable images before starting a native/CDN image load',async()=>{
    const order:string[]=[];
    let image!:HTMLImageElement;
    spyOnProperty(HTMLImageElement.prototype,'src','set').and.callFake(function(this:HTMLImageElement,value:string){
      image=this;order.push('cors:'+this.crossOrigin,'src:'+value);
    });
    const loaded=mokiCanvas.load('/_cdn/static/sprite.png');
    expect(order).toEqual(['cors:anonymous','src:/_cdn/static/sprite.png']);
    image.dispatchEvent(new window.Event('load'));
    expect(await loaded).toBe(image);
    expect(image.onload).toBeNull();expect(image.onerror).toBeNull();
  });

  it('reports a genuinely missing image without leaving its callbacks attached',async()=>{
    let image!:HTMLImageElement;
    spyOnProperty(HTMLImageElement.prototype,'src','set').and.callFake(function(this:HTMLImageElement){image=this;});
    const loaded=mokiCanvas.load('/missing.png');
    const rejected=expectAsync(loaded).toBeRejectedWithError('Could not load Moki sprite: /missing.png');
    image.dispatchEvent(new window.Event('error'));await rejected;
    expect(image.onload).toBeNull();expect(image.onerror).toBeNull();
  });

  it('handles blocked readback but does not hide unrelated programming errors',()=>{
    expect(mokiCanvas.readPixels(context(true),0,0,64,64)).toBeNull();
    const ctx=context();
    spyOn(ctx,'getImageData').and.throwError('bad dimensions');
    expect(()=>mokiCanvas.readPixels(ctx,0,0,64,64)).toThrowError('bad dimensions');
  });

  for(const blocked of [false,true]) {
    it('draws every compatible closet item for all variants/stages with '+(blocked?'blocked':'readable')+' pixels',()=>{
      for(const variant of mokiVariants.ids)for(const stage of ['baby','teen','adult'] as const)for(const item of mokiWardrobe.catalog){
        if(!mokiWardrobe.compatible(item.id,variant))continue;
        const outfit=mokiWardrobe.preview(mokiWardrobe.create(),item.id,variant);
        for(const phase of ['idle','eating','exercising']){
          const ctx=context(blocked);
          expect(()=>mokiAccessories.draw(ctx,stage,phase,0,outfit,0,false,mokiVariantArt.eyes(variant,stage,phase,0),mokiVariants.family(variant)!=='moki',variant)).not.toThrow();
          expect(ctx.fillRect).toHaveBeenCalled();
        }
      }
    });
  }

  it('keeps Auri, alien and robot sprites visible when optional lighting cannot read pixels',()=>{
    const ctx=context(true);
    for(const [variant,motion] of [['auri',mokiDivineMotion],['orbita',mokiAlienMotion],['bit',mokiRobotMotion]] as const){
      for(const phase of ['egg','idle','sleeping','eating','bathing','exercising']){
        expect(()=>motion.draw(ctx,variant,1200,phase,false)).not.toThrow();
      }
    }
    expect(ctx.putImageData).not.toHaveBeenCalled();
  });

  it('still applies Auri lighting to readable image data',()=>{
    const ctx=context();
    mokiDivineMotion.draw(ctx,'auri',1800,'idle',false);
    expect(ctx.putImageData).toHaveBeenCalled();
  });

  it('prepares all three workout stages even if palette readback is blocked',()=>{
    const ctx=context(true);
    spyOn(HTMLCanvasElement.prototype,'getContext').and.returnValue(ctx as any);
    const sheets=mokiWorkoutAnimation.prepare({} as HTMLImageElement);
    expect(Object.keys(sheets)).toEqual(['baby','teen','adult']);
    for(const sheet of Object.values(sheets)){expect(sheet.width).toBe(256);expect(sheet.height).toBe(64);}
    expect(ctx.drawImage).toHaveBeenCalledTimes(12);
    expect(ctx.putImageData).not.toHaveBeenCalled();
  });

  it('lets bathing and sleep proceed when accessory sparkle readback is blocked',()=>{
    const ctx=context(true);
    spyOn(HTMLCanvasElement.prototype,'getContext').and.returnValue(ctx as any);
    expect(mokiAccessories.prepareRemoval({} as HTMLImageElement,'baby',{head:'cap',eyes:null,neck:'bandana'})).toBeNull();
  });
});
