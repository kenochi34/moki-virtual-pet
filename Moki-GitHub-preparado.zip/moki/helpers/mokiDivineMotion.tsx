import {mokiCanvas} from './mokiCanvas';
const pulse=[0,.05,.12,.2,.3,.38,.42,.38,.3,.2,.12,.05];
function enabled(variant:string){return variant==='auri';}
function hover(variant:string,phase:string,time:number,reduced=false){return enabled(variant)&&phase==='idle'&&!reduced?[0,0,-1,-1,-2,-2,-1,-1][Math.floor(time/450)%8]:0;}
function draw(ctx:CanvasRenderingContext2D,variant:string,time:number,phase:string,reduced=false){
 if(!enabled(variant))return;
 const frame=mokiCanvas.readPixels(ctx,0,0,64,64);if(!frame)return;
 const d=frame.data;
 const light=reduced?.08:pulse[Math.floor(time/(phase==='sleeping'?450:320))%pulse.length];
 for(let y=0;y<32;y++)for(let x=0;x<64;x++){
  const i=(y*64+x)*4,r=d[i],g=d[i+1],b=d[i+2];
  if(!d[i+3]||r<180||g<120||b>190||r<g*1.1)continue;
  for(let k=0;k<3;k++)d[i+k]=Math.round(d[i+k]+(255-d[i+k])*light);
 }
 ctx.putImageData(frame,0,0);
}
export const mokiDivineMotion={enabled,hover,draw};