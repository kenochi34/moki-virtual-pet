import {mokiCanvas} from './mokiCanvas';
// Palette cycling lights only the alien's accent pixels. Geometry stays on the pixel grid.
const ids=['orbita','nova','nebula'];
const pulse=[0,.04,.12,.24,.42,.66,.85,1,.85,.66,.42,.24,.12,.04];
function enabled(variant:string) {return ids.includes(variant);}
function accent(variant:string,r:number,g:number,b:number) {
  if(variant==='orbita')return r<110 && g>190 && b>180;
  if(variant==='nova')return r>160 && b>125 && g<125 && b>g*1.5;
  if(variant==='nebula')return b>110 && r>75 && g<155 && b>r*1.15 && b>g*1.35;
  return false;
}
function level(variant:string,time:number,x:number,y:number,phase:string,reduced=false) {
  if(reduced)return .12;
  const resting=phase==='sleeping'||phase==='lying';
  const tick=resting?420:variant==='nova'?210:variant==='nebula'?270:250;
  // Antenna-to-belly wave, alternating Nova spots, and a left-to-right tentacle wave.
  const shift=variant==='orbita'?Math.floor(y/14):variant==='nova'?(x<32?0:2):Math.floor(x/9);
  const step=((Math.floor(time/tick)-shift)%pulse.length+pulse.length)%pulse.length;
  return .03+pulse[step]*(resting?.19:.48);
}
function hover(variant:string,phase:string,time:number,reduced=false) {
  if(variant!=='nebula'||phase!=='idle'||reduced)return 0;
  return [0,0,-1,-1,-2,-2,-1,-1][Math.floor(time/320)%8];
}
function draw(ctx:CanvasRenderingContext2D,variant:string,time:number,phase:string,reduced=false) {
  if(!enabled(variant))return;
  const image=mokiCanvas.readPixels(ctx,0,0,64,64);if(!image)return;
  const d=image.data;
  for(let y=0;y<64;y++)for(let x=0;x<64;x++) {
    const i=(y*64+x)*4;
    if(!d[i+3] || (phase==='bathing' && y>=49) || !accent(variant,d[i],d[i+1],d[i+2]))continue;
    const light=level(variant,time,x,y,phase,reduced);
    for(let channel=0;channel<3;channel++)d[i+channel]=Math.round(d[i+channel]+(255-d[i+channel])*light);
  }
  ctx.putImageData(image,0,0);
}
export const mokiAlienMotion={enabled,accent,level,hover,draw};