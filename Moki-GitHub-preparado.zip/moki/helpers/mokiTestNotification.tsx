import {setTimeout as delay} from 'node:timers/promises';
import {db} from './db';
import {mokiPushDelivery} from './mokiPushDelivery';

export async function mokiTestNotification(payload:{deviceHash:string;scheduledAt:string;testId:string}){
 const scheduledAt=new Date(payload.scheduledAt);
 if(!/^[a-f0-9]{64}$/.test(payload.deviceHash)||!Number.isFinite(scheduledAt.getTime()))throw new Error('Invalid notification test');
 console.info('Moki background test started',{testId:payload.testId});
 // queueTask's delayed mode has a five-minute minimum; this short wait belongs in its worker.
 await delay(Math.max(0,scheduledAt.getTime()+10000-Date.now()));
 // Claim once before external delivery. Disable/removal, a newer test or a retry makes this a no-op.
 const row=await db.updateTable('mokiPushDevices').set({lastTestAt:new Date()})
  .where('deviceHash','=',payload.deviceHash).where('enabled','=',true).where('lastTestAt','=',scheduledAt)
  .returningAll().executeTakeFirst();
 if(!row){console.info('Moki background test skipped',{testId:payload.testId});return;}
 try{
  const result=await mokiPushDelivery(row,'test');
  if(result?.gone)await db.deleteFrom('mokiPushDevices').where('deviceHash','=',payload.deviceHash).where('subscriptionIdentity','=',row.subscriptionIdentity).execute();
  console.info('Moki background test finished',{testId:payload.testId,accepted:result?.success??false,statusCode:result?.statusCode??0});
 }catch(error){console.error('Moki background test failed',{testId:payload.testId,name:error instanceof Error?error.name:'unknown'});throw error;}
}