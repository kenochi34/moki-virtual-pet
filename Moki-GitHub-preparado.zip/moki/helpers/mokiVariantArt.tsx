import {mokiDivineArt} from './mokiDivineArt';
import {mokiRobotArt} from './mokiRobotArt';
import {mokiAlienArt} from './mokiAlienArt';
import {mokiBirdArt} from './mokiBirdArt';
import {mokiConfig} from './mokiConfig';
import {mokiVariants} from './mokiVariants';
type Id=typeof mokiVariants.ids[number];
type Stage='baby'|'teen'|'adult';
type Phase=keyof typeof mokiConfig.animations;
type Eyes=[number,number,number,number,number,number,number,number];
const data={...mokiDivineArt,...mokiRobotArt,...mokiAlienArt,...mokiBirdArt,"lila":{"egg":"/_cdn/static/cb442a6d-61fe-4602-a56e-7616fde05b7e-moki-lila-egg.png","stages":{"baby":{"sheets":["/_cdn/static/9cec2bb9-a5fa-4f37-b435-f50ce6c85dba-moki-lila-baby-idle.png","/_cdn/static/922fabd0-6634-4b4a-adc9-8165e19f807f-moki-lila-baby-descanso.png","/_cdn/static/01da0438-f8be-4cfa-963d-30ced1f7f1f1-moki-lila-baby-comer.png","/_cdn/static/21bd28ae-1d2f-4403-a98a-f651f93af39e-moki-lila-baby-bano.png"],"workout":"/_cdn/static/3cc5c016-0886-44e7-8b1d-088698ddb61b-moki-lila-baby-exercise.png","anchors":{"idle":[[18,36,5,6,28,38,7,6],[19,36,5,6,29,38,7,6],[21,37,5,6,31,39,7,6],[21,37,5,6,31,39,7,6],[19,36,5,6,29,38,7,6],[20,38,5,6,30,40,7,6],[20,38,5,6,30,40,7,6],[18,36,5,6,28,38,7,6]],"descanso":[[18,36,5,6,28,38,7,6],[21,45,5,6,30,47,7,6],[21,45,5,6,30,47,7,6],[19,44,5,6,29,46,7,6],[19,44,5,6,29,46,7,6],[19,45,5,6,29,47,7,6],[19,45,5,6,29,47,7,6],[21,45,5,6,30,47,7,6],[15,37,5,6,24,39,7,6],[15,37,5,6,24,39,7,6],[19,36,5,6,29,38,7,6],[18,36,5,6,28,38,7,6]],"comer":[[20,38,4,6,30,40,6,6],[20,37,4,6,30,39,6,6],[20,39,4,6,30,41,6,6],[20,39,4,6,30,41,6,6],[20,37,4,6,30,39,6,6],[20,39,4,6,30,41,6,6],[21,38,4,6,31,40,6,6],[20,38,4,6,30,40,6,6]],"bano":[[22,34,4,6,32,36,6,6],[23,33,4,6,33,38,6,6],[21,33,4,6,31,35,6,6],[21,34,4,6,31,36,6,6]],"exercise":[[18,47,4,6,28,49,6,6],[18,41,4,6,28,43,6,6],[21,35,4,6,31,37,6,6],[19,46,4,6,29,48,6,6]]}},"teen":{"sheets":["/_cdn/static/0b20a9cf-56b8-4c97-b00c-5c587f99123f-moki-lila-teen-idle.png","/_cdn/static/6deb68eb-24b6-4a6a-a486-b68fe2ad0c37-moki-lila-teen-descanso.png","/_cdn/static/9a93a069-df01-48e2-b2ad-e0d937a1a3ec-moki-lila-teen-comer.png","/_cdn/static/c6afe664-fda4-497a-bd2c-cdc959cb8fcd-moki-lila-teen-bano.png"],"workout":"/_cdn/static/1a1f3835-d809-4715-a2bf-8a1e7f37a824-moki-lila-teen-exercise.png","anchors":{"idle":[[16,31,4,7,27,33,6,7],[18,31,4,7,29,33,6,7],[20,32,4,7,31,34,6,7],[20,32,4,7,31,34,6,7],[18,31,4,7,29,33,6,7],[18,34,4,7,29,36,6,7],[18,34,4,7,29,36,6,7],[16,31,4,7,27,33,6,7]],"descanso":[[16,31,4,7,27,33,6,7],[17,45,4,7,28,47,6,7],[17,45,4,7,28,47,6,7],[20,41,4,7,30,43,6,7],[20,41,4,7,30,43,6,7],[20,43,4,7,30,45,6,7],[20,43,4,7,30,45,6,7],[17,45,4,7,28,47,6,7],[22,29,4,7,32,31,6,7],[22,29,4,7,32,31,6,7],[18,31,4,7,29,33,6,7],[16,31,4,7,27,33,6,7]],"comer":[[19,34,5,6,30,36,7,6],[19,34,5,6,30,36,7,6],[20,35,5,6,31,37,7,6],[20,35,5,6,31,37,7,6],[19,34,5,6,30,36,7,6],[20,35,5,6,31,37,7,6],[19,34,5,6,30,36,7,6],[19,34,5,6,30,36,7,6]],"bano":[[18,31,5,7,29,33,7,7],[20,33,5,7,31,35,7,7],[22,30,5,7,33,31,7,7],[21,30,5,7,32,32,7,7]],"exercise":[[16,46,5,5,27,48,7,5],[17,36,5,5,28,38,7,5],[19,34,5,5,29,36,7,5],[18,46,5,5,29,48,7,5]]}},"adult":{"sheets":["/_cdn/static/265bc142-db3b-4fe8-a079-6dfe3e42c358-moki-lila-adult-idle.png","/_cdn/static/27ad5213-ac46-4a8d-b993-ce6d185538db-moki-lila-adult-descanso.png","/_cdn/static/4714f17a-ce15-41a7-83d5-b32db9fbae30-moki-lila-adult-comer.png","/_cdn/static/83c03dc9-8f97-4a2a-bc36-7d463ef980f6-moki-lila-adult-bano.png"],"workout":"/_cdn/static/dcaa1274-f08d-488c-b78c-4ecd984f4f1a-moki-lila-adult-exercise.png","anchors":{"idle":[[15,24,5,7,28,26,7,7],[16,24,5,7,29,26,7,7],[15,25,5,7,29,27,7,7],[16,26,5,7,27,28,7,7],[16,23,5,7,29,25,7,7],[16,23,5,7,29,25,7,7],[16,23,5,7,29,25,7,7],[15,24,5,7,28,26,7,7]],"descanso":[[12,26,6,7,25,28,8,7],[12,33,6,7,25,35,8,7],[12,40,6,7,23,43,8,7],[18,34,6,7,29,36,8,7],[18,34,6,7,29,36,8,7],[18,34,6,7,29,36,8,7],[18,34,6,7,29,36,8,7],[11,42,6,7,24,44,8,7],[18,34,6,7,29,36,8,7],[12,25,6,7,25,27,8,7],[15,25,6,7,28,27,8,7],[12,26,6,7,25,28,8,7]],"comer":[[12,23,5,6,25,25,7,6],[12,23,5,6,25,25,7,6],[13,23,5,6,26,25,7,6],[14,23,5,6,26,26,7,6],[12,23,5,6,25,25,7,6],[12,23,5,6,25,25,7,6],[13,23,5,6,26,25,7,6],[12,23,5,6,25,25,7,6]],"bano":[[19,34,4,6,30,36,6,6],[17,26,4,6,31,21,6,6],[19,34,4,6,30,36,6,6],[19,34,4,6,30,36,6,6]],"exercise":[[11,33,6,6,24,35,8,6],[11,24,6,6,24,26,8,6],[14,26,6,6,27,28,8,6],[13,34,6,6,26,36,8,6]]}}}},"amber":{"egg":"/_cdn/static/dad11037-2a26-41c3-8f61-ddb7d47beb79-moki-amber-egg.png","stages":{"baby":{"sheets":["/_cdn/static/195b137a-d4e3-4dab-93f1-b5572d8be3f6-moki-amber-baby-idle.png","/_cdn/static/aea8cace-bdd4-4492-bcd7-1685b22886e9-moki-amber-baby-descanso.png","/_cdn/static/c5a684ce-5c85-4a23-b64c-e9dcac7091cd-moki-amber-baby-comer.png","/_cdn/static/4d211f47-04cc-47ba-a539-1fdf234b7cbd-moki-amber-baby-bano.png"],"workout":"/_cdn/static/20b2047c-299b-4a82-8f57-b3ea59464ef4-moki-amber-baby-exercise.png","anchors":{"idle":[[19,36,4,7,29,38,6,7],[19,37,4,7,29,39,6,7],[18,39,4,7,29,41,6,7],[18,39,4,7,29,41,6,7],[19,37,4,7,29,39,6,7],[19,37,4,7,29,39,6,7],[19,37,4,7,29,39,6,7],[19,36,4,7,29,38,6,7]],"descanso":[[19,36,4,7,29,38,6,7],[16,45,4,7,26,47,6,7],[16,45,4,7,26,47,6,7],[19,42,4,7,28,44,6,7],[19,42,4,7,28,44,6,7],[19,44,4,7,28,46,6,7],[19,44,4,7,28,46,6,7],[16,45,4,7,26,47,6,7],[23,31,4,7,34,33,6,7],[23,31,4,7,34,33,6,7],[19,37,4,7,29,39,6,7],[19,36,4,7,29,38,6,7]],"comer":[[19,35,4,7,29,37,6,7],[21,34,4,7,31,36,6,7],[20,35,4,7,30,37,6,7],[20,35,4,7,30,37,6,7],[21,34,4,7,31,36,6,7],[20,35,4,7,30,37,6,7],[20,34,4,7,30,37,6,7],[19,35,4,7,29,37,6,7]],"bano":[[20,28,4,6,30,30,5,6],[21,27,4,6,32,29,5,6],[14,28,4,6,24,30,5,6],[21,29,4,6,32,31,5,6]],"exercise":[[15,42,4,5,25,44,6,5],[16,36,4,5,25,38,6,5],[23,32,4,5,34,34,6,5],[17,42,4,5,27,44,6,5]]}},"teen":{"sheets":["/_cdn/static/e4aa710b-191b-4b5b-8937-c19b9a72c5b1-moki-amber-teen-idle.png","/_cdn/static/86942239-7232-40e0-8123-1e9830153106-moki-amber-teen-descanso.png","/_cdn/static/4994124f-3112-464d-a71b-9dba82a34f57-moki-amber-teen-comer.png","/_cdn/static/f3384971-ceb2-4a70-8cd6-b96c8795f2d4-moki-amber-teen-bano.png"],"workout":"/_cdn/static/76285056-4267-4117-913a-6e4233a12285-moki-amber-teen-exercise.png","anchors":{"idle":[[16,27,4,7,27,29,6,7],[14,27,4,7,25,29,6,7],[14,30,4,7,25,33,6,7],[14,30,4,7,25,33,6,7],[14,27,4,7,25,29,6,7],[17,30,4,7,28,32,6,7],[17,30,4,7,28,32,6,7],[16,27,4,7,27,29,6,7]],"descanso":[[16,27,4,7,27,29,6,7],[24,37,4,7,34,39,6,7],[24,37,4,7,34,39,6,7],[16,39,4,7,26,41,6,7],[16,39,4,7,26,41,6,7],[17,41,4,7,27,43,6,7],[17,41,4,7,27,43,6,7],[24,37,4,7,34,39,6,7],[24,26,4,7,34,28,6,7],[24,26,4,7,34,28,6,7],[14,27,4,7,25,29,6,7],[16,27,4,7,27,29,6,7]],"comer":[[16,28,4,6,27,30,6,6],[17,28,4,6,28,30,6,6],[16,28,4,6,28,32,6,6],[16,28,4,6,28,32,6,6],[17,28,4,6,28,30,6,6],[16,28,4,6,28,32,6,6],[18,26,4,6,29,31,6,6],[16,28,4,6,27,30,6,6]],"bano":[[18,23,4,7,29,25,6,7],[18,22,4,7,29,25,6,7],[21,20,4,7,32,23,6,7],[19,23,4,7,30,25,6,7]],"exercise":[[13,38,4,6,24,40,6,6],[17,29,4,6,28,31,6,6],[20,26,4,6,31,28,6,6],[16,38,4,6,27,40,6,6]]}},"adult":{"sheets":["/_cdn/static/66c13474-38e9-462a-b31c-5ff624a46d72-moki-amber-adult-idle.png","/_cdn/static/9dfd9d57-c232-492c-a9d3-b73ace3b12ee-moki-amber-adult-descanso.png","/_cdn/static/17fbb2b6-8c1c-4df6-be89-bf714263cc89-moki-amber-adult-comer.png","/_cdn/static/36265356-e8c9-459d-995d-91a2868bb427-moki-amber-adult-bano.png"],"workout":"/_cdn/static/0b5c44de-8b9d-4fb3-b8b5-20549e30ed5c-moki-amber-adult-exercise.png","anchors":{"idle":[[16,26,5,8,29,28,7,8],[12,26,5,8,25,28,7,8],[13,29,5,8,27,31,7,8],[13,29,5,8,27,31,7,8],[12,26,5,8,25,28,7,8],[15,28,5,8,28,30,7,8],[15,28,5,8,28,30,7,8],[16,26,5,8,29,28,7,8]],"descanso":[[16,26,5,8,29,28,7,8],[20,31,5,8,32,33,7,8],[20,31,5,8,32,33,7,8],[12,37,5,8,25,39,7,8],[12,37,5,8,25,39,7,8],[13,40,5,8,25,42,7,8],[13,40,5,8,25,42,7,8],[20,31,5,8,32,33,7,8],[21,22,5,8,34,24,7,8],[21,22,5,8,34,24,7,8],[12,26,5,8,25,28,7,8],[16,26,5,8,29,28,7,8]],"comer":[[15,27,5,8,28,29,7,8],[16,26,5,8,29,28,7,8],[15,27,5,8,28,29,7,8],[15,27,5,8,28,29,7,8],[16,26,5,8,29,28,7,8],[15,27,5,8,28,29,7,8],[16,25,5,8,29,28,7,8],[15,27,5,8,28,29,7,8]],"bano":[[17,20,5,8,30,22,7,8],[17,20,5,8,30,22,7,8],[9,21,5,8,22,23,7,8],[17,20,5,8,30,22,7,8]],"exercise":[[11,34,5,6,24,36,7,6],[17,22,5,6,30,24,7,6],[21,23,5,6,33,25,7,6],[14,35,5,6,27,37,7,6]]}}}}};
function get(variant:Id) {
 if(variant==='green')return {stageSheets:mokiConfig.stageSheets,egg:{...mokiConfig.egg,scale:40/302},workout:null};
 const art=data[variant];
 return {stageSheets:{baby:art.stages.baby.sheets,teen:art.stages.teen.sheets,adult:art.stages.adult.sheets},
 egg:{src:art.egg,frames:Array.from({length:8},(_,i)=>[i*64,0,64,64]),scale:1},
 workout:{baby:art.stages.baby.workout,teen:art.stages.teen.workout,adult:art.stages.adult.workout}};
}
function animation(variant:Id,phase:Phase) {
 const base=mokiConfig.animations[phase];
 if(variant==='green'||phase==='hatching'||phase==='undressing')return base;
 if(variant==='auri'){
   if(phase==='idle')return {...base,frames:[0,1,0,2,3,0,5,6,0],times:[1200,380,700,100,120,800,300,250,900]};
   if(phase==='eating')return {...base,frames:[0,1,2,3,4,5,6,7],times:[400,260,240,240,220,260,500,260],cycles:2};
   if(phase==='bathing')return {...base,frames:[0,1,2,1,2,3],times:[500,300,260,300,260,650],cycles:2};
   if(phase==='exercising')return {...base,times:[320,260,200,320,200,240,220,400]};
   if(phase==='sleeping')return {...base,times:[1200,1400]};
   return base;
 }
 if(mokiVariants.family(variant)==='robot'){
   const speed=variant==='volt'?.85:variant==='tuerca'?1.12:1;
   if(phase==='idle')return {...base,frames:[0,1,0,2,3,0,5,6,0],times:[1100,300,650,100,100,800,300,240,800].map(t=>Math.round(t*speed))};
   if(phase==='eating')return {...base,sheet:0,frames:[0,0,0,1,2,3,0,1,0,0,0,0],times:[180,180,180,220,300,650,550,220,180,180,180,180],cycles:1};
   if(phase==='bathing')return {...base,frames:[0,1,0,1,2,2,3],times:[450,450,400,400,600,450,600],cycles:1};
   if(phase==='lying')return {...base,frames:[0,0,0,0,0,1,2,2,3,4,4,4],times:[240,200,200,200,200,200,200,320,300,300,300,400],cycles:1};
   if(phase==='sleeping')return {...base,frames:[4,5],times:[1600,1800]};
   if(phase==='waking')return {...base,frames:[5,5,6,6,7,7,8,8,10,10,11,11],times:[300,300,250,250,200,200,200,200,200,200,200,350],cycles:1};
   if(phase==='exercising')return {...base,times:[260,220,200,240,180,200,200,340].map(t=>Math.round(t*speed))};
   return base;
 }
 if(mokiVariants.family(variant)==='alien'){
   const speed=variant==='nova'?.85:variant==='nebula'?1.16:1;
   if(phase==='idle')return {...base,frames:[0,1,0,2,3,0,5,6,0],times:[1050,360,650,90,100,750,280,230,800].map(t=>Math.round(t*speed))};
   if(phase==='eating')return {...base,frames:[0,1,2,3,4,5,6,7],times:[360,240,180,210,180,250,400,220].map(t=>Math.round(t*speed)),cycles:2};
   if(phase==='bathing')return {...base,frames:[0,1,2,1,2,3],times:[400,240,200,210,200,500].map(t=>Math.round(t*speed)),cycles:3};
   if(phase==='exercising')return {...base,times:[280,200,130,200,150,180,160,340].map(t=>Math.round(t*speed))};
   if(phase==='sleeping')return {...base,times:variant==='nebula'?[1150,1250]:[850,1000]};
   return base;
 }
 if(mokiVariants.family(variant)==='bird'){
   const speed=variant==='coral'?.85:variant==='noche'?1.2:1;
   if(phase==='idle')return {...base,frames:[0,1,0,2,3,0,5,6,0],times:[900,240,650,80,90,600,240,170,650].map(t=>Math.round(t*speed))};
   if(phase==='eating')return {...base,frames:[0,1,4,1,2,3,6,7],times:[350,160,120,140,180,200,420,200].map(t=>Math.round(t*speed)),cycles:3};
   if(phase==='bathing')return {...base,frames:[0,1,2,1,2,3],times:[400,180,140,170,150,400].map(t=>Math.round(t*speed)),cycles:3};
   if(phase==='exercising')return {...base,times:[240,150,100,220,100,130,100,320].map(t=>Math.round(t*speed))};
   if(phase==='sleeping')return {...base,times:[850,950]};
   return base;
 }
 if(phase==='idle')return {...base,frames:variant==='lila'?[0,1,2,3,2,1,0,5,0]:[0,1,0,1,2,3,1,6,7],times:variant==='lila'?[1300,550,110,150,110,500,600,420,750]:[700,220,280,180,80,100,250,180,450]};
 if(phase==='exercising')return {...base,times:variant==='lila'?[220,160,110,170,110,150,130,260]:[140,100,70,140,70,80,90,180]};
 if(phase==='eating')return {...base,times:variant==='lila'?[350,180,180,220,160,200,160,200,250,400]:[200,90,90,120,80,110,80,110,180,250]};
 if(phase==='bathing')return {...base,times:variant==='lila'?[350,220,260,220,260,230,220,350]:[230,130,140,120,140,160,130,240]};
 if(phase==='sleeping')return {...base,times:variant==='lila'?[850,900]:[650,700]};
 return base;
}
function offsets(variant:Id) {if(variant==='auri')return [0,0,-2,-5,-2,0,0,0];if(mokiVariants.family(variant)==='robot')return variant==='volt'?[0,0,0,0,0,0,0,0]:[0,0,-1,-2,-1,0,0,0];if(mokiVariants.family(variant)==='alien')return variant==='nebula'?[0,0,-2,-4,-2,0,0,0]:variant==='nova'?[0,0,-3,-6,-3,0,0,0]:[0,0,-2,-5,-2,0,0,0];if(mokiVariants.family(variant)==='bird')return variant==='noche'?[0,0,-3,-6,-3,0,0,0]:[0,0,-4,-8,-4,0,0,0];return variant==='lila'?[0,0,-2,-5,-2,0,0,0]:variant==='amber'?[0,0,-4,-8,-4,0,0,0]:[0,0,-3,-7,-3,0,0,0];}
// Authored anchors for turned heads and closed-eye workout poses.
const workoutFits:Partial<Record<Id,Partial<Record<Stage,Partial<Record<number,Eyes>>>>>>={
 tuerca:{
  baby:{1:[24,40,4,6,33,32,4,6],3:[25,34,5,6,37,34,5,6]},
  teen:{1:[19,31,5,6,27,24,5,6],3:[29,31,5,6,40,32,4,6]},
  adult:{1:[34,21,4,6,43,26,4,6],3:[20,21,5,6,31,22,5,6]}
 },
 volt:{
  baby:{0:[30,37,5,4,39,39,5,4],1:[20,34,5,4,28,30,5,4],2:[27,28,5,4,36,30,5,4],3:[28,35,5,4,36,37,5,4]},
  teen:{0:[32,28,5,4,42,28,5,4],1:[25,21,5,4,35,25,5,4],2:[24,19,5,4,35,20,5,4],3:[28,26,5,4,38,26,5,4]},
  adult:{0:[30,25,5,4,38,25,5,4],1:[27,17,5,4,37,16,5,4],2:[29,17,5,4,37,20,5,4],3:[30,24,5,4,39,25,5,4]}
 }
};
function eyes(variant:Id,stage:Stage,phase:string,frame:number,step=0,reduced=false):Eyes|undefined {
 if(variant==='green')return undefined;
 const anchors=data[variant].stages[stage].anchors;
 const kind=phase==='eating'&&mokiVariants.family(variant)!=='robot'?'comer':phase==='exercising'&&frame<4&&!reduced?'exercise':'idle';
 const index=kind==='idle'&&phase==='exercising'?0:frame;
 const chosen=(kind==='exercise'?workoutFits[variant]?.[stage]?.[index]:undefined)??anchors[kind][index]??anchors[kind][0];
 const result=[...chosen] as Eyes;
 if(phase==='exercising'&&!reduced){const offset=offsets(variant)[step]??0;result[1]+=offset;result[5]+=offset;}
 return result;
}
export const mokiVariantArt={get,animation,offsets,eyes};
