type State={version:1;day:string;feeds:number;games:number;exercise:number;pendingChests:number;claimedToday:boolean;openedChests:number};
type Event='feed'|'game'|'exercise';
const rewards={feed:3,game:3,exercise:5,chest:5};
const minimumCare=10;
function localDay(now=Date.now()){const d=new Date(now);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function create(now=Date.now(),exerciseDay=''):State{return {version:1,day:localDay(now),feeds:0,games:0,exercise:exerciseDay===localDay(now)?1:0,pendingChests:0,claimedToday:false,openedChests:0};}
function count(value:unknown,max:number){return typeof value==='number'&&Number.isSafeInteger(value)&&value>=0?Math.min(max,value):0;}
function restore(value:unknown,now=Date.now(),exerciseDay=''):State{
 if(!value||typeof value!=='object')return create(now,exerciseDay);
 const s=value as State;
 if(s.version!==1||typeof s.day!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s.day)||!Number.isFinite(Date.parse(s.day+'T12:00:00Z'))||new Date(s.day+'T12:00:00Z').toISOString().slice(0,10)!==s.day)return create(now,exerciseDay);
 const state:State={version:1,day:s.day,feeds:count(s.feeds,2),games:count(s.games,1),exercise:count(s.exercise,1),pendingChests:count(s.pendingChests,100000),claimedToday:s.claimedToday===true,openedChests:count(s.openedChests??(s.claimedToday?1:0),100000)};
 if(summary(state).complete<3)state.claimedToday=false;
 return state;
}
function sync(state:State,now=Date.now()):State{
 const day=localDay(now);
 if(!Number.isSafeInteger(state.openedChests))state={...state,openedChests:state.claimedToday?1:0};
 // A clock moving backwards must not open another copy of an already visited day.
 return day>state.day?{...create(now),pendingChests:state.pendingChests,openedChests:state.openedChests}:state;
}
function summary(state:State){const complete=Number(state.feeds>=2)+Number(state.games>=1)+Number(state.exercise>=1);return {complete,percent:Math.round(complete/3*100),pending:state.pendingChests*rewards.chest};}
function record(state:State,event:Event,now=Date.now()){
 const before=sync(state,now);
 if(localDay(now)!==before.day)return {state:before,stars:0};
 const key=event==='feed'?'feeds':event==='game'?'games':'exercise',target=event==='feed'?2:1;
 if(before[key]>=target)return {state:before,stars:0};
 const next={...before,[key]:Math.min(target,before[key]+1)};
 if(summary(next).complete===3)next.pendingChests++;
 // Exercise is already paid by the existing first-session reward in mokiPet.
 const stars=next[key]===target&&event!=='exercise'?rewards[event]:0;
 return {state:next,stars};
}
function claim(state:State,now=Date.now()){
 const next=sync(state,now),stars=summary(next).pending;
 return {state:stars?{...next,pendingChests:0,openedChests:Math.min(100000,next.openedChests+next.pendingChests),claimedToday:summary(next).complete===3}:next,stars};
}
export const mokiChallenges={rewards,minimumCare,localDay,create,restore,sync,summary,record,claim};