import { useCallback, useEffect, useRef, useState } from 'react';
import { mokiSounds } from './mokiSounds';
const KEY = 'moki.sound.enabled.v1';
export function useMokiSound() {
  const [enabled, setState] = useState(() => { try { return localStorage.getItem(KEY) !== 'false'; } catch { return true; } });
  const engine = useRef<ReturnType<typeof mokiSounds.create> | null>(null);
  const enabledRef = useRef(enabled);
  const play = useCallback((effect: Parameters<ReturnType<typeof mokiSounds.create>['play']>[0], strength?: number) => {
    if (!enabledRef.current) return;
    if (!engine.current) engine.current = mokiSounds.create();
    engine.current.play(effect, strength);
  }, []);
  const voice=useCallback((variant:Parameters<ReturnType<typeof mokiSounds.create>['voice']>[0],cue:Parameters<ReturnType<typeof mokiSounds.create>['voice']>[1])=>{
    if(!enabledRef.current)return;
    if(!engine.current)engine.current=mokiSounds.create();
    engine.current.voice(variant,cue);
  },[]);
  const stop = useCallback(() => engine.current?.stop(), []);
  const setEnabled = useCallback((value: boolean) => {
    enabledRef.current = value; setState(value);
    engine.current?.setEnabled(value);
    try { localStorage.setItem(KEY, String(value)); } catch {}
    if (value) play('button');
  }, [play]);
  useEffect(() => {
    const hide = () => { if (document.hidden) stop(); };
    document.addEventListener('visibilitychange',hide);
    window.addEventListener('pagehide',stop);
    return () => {
      document.removeEventListener('visibilitychange',hide);
      window.removeEventListener('pagehide',stop);
      engine.current?.dispose(); engine.current=null;
    };
  }, [stop]);
  return { enabled, setEnabled, play, voice, stop };
}
