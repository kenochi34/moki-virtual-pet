import React from 'react';
import {render,renderHook,fireEvent,cleanup,act} from '@testing-library/react';
import {mokiPet} from './mokiPet';
import {mokiVariants} from './mokiVariants';
import {useMokiPet} from './useMokiPet';
import {MokiWelcome} from '../components/MokiWelcome';
const now=1800000000000;
const families=['moki','bird','alien','robot'] as const;
function funded(coins=45,adoptions=2){
 return mokiPet.create(now,{stars:coins,lastExerciseRewardDay:'',adoptions},0,'robot');
}
describe('First companion and adoption economy',()=>{
 it('keeps a new save unchosen across reloads without recording a received variant',()=>{
  const pending=mokiPet.restore(null,now);
  const restored=mokiPet.restore(JSON.stringify(pending),now+1000);
  expect(restored.player.starterChosen).toBeFalse();
  expect(restored.player.variants).toEqual([]);
  expect(mokiPet.act(restored,'tap',now+1000).eggTaps).toBe(0);
 });
 for(const family of families)it('chooses '+family+' once, without using a free adoption',()=>{
  const pending=mokiPet.begin(now),chosen=mokiPet.chooseStarter(pending,family,now+1,0);
  expect(mokiVariants.family(chosen.variant)).toBe(family);
  expect(chosen.player.variants).toEqual([chosen.variant]);
  expect(chosen.player.stars).toBe(0);expect(chosen.player.adoptions).toBe(0);
  expect(chosen.player.starterChosen).toBeTrue();
  expect(mokiPet.chooseStarter(chosen,'bird',now+2)).toBe(chosen);
  expect(mokiPet.restore(JSON.stringify(chosen),now+2).variant).toBe(chosen.variant);
 });
 it('does not offer the locked legendary as a starter',()=>{
  const pending=mokiPet.begin(now);
  expect(mokiPet.chooseStarter(pending,'divine',now+1)).toBe(pending);
 });
 it('migrates an existing pet without resetting identity, progress or collection',()=>{
  const pet={...funded(),stage:'teen' as const,name:'Pixel',care:25,hunger:18};
  pet.player.raised=['green','cielo'];pet.player.wardrobe.owned=['leafClip'];
  const legacy=JSON.parse(JSON.stringify(pet));delete legacy.player.adoptions;delete legacy.player.starterChosen;
  const restored=mokiPet.restore(JSON.stringify(legacy),now);
  expect(restored.name).toBe('Pixel');expect(restored.stage).toBe('teen');
  expect(restored.variant).toBe('bit');expect(restored.bornAt).toBe(pet.bornAt);
  expect(restored.care).toBe(25);expect(restored.hunger).toBe(18);
  expect(restored.player.stars).toBe(45);expect(restored.player.raised).toEqual(['green','cielo']);
  expect(restored.player.wardrobe.owned).toContain('leafClip');
  expect(restored.player.starterChosen).toBeTrue();expect(restored.player.adoptions).toBe(0);
 });
 it('shares two free changes across families, then charges 20, including egg changes',()=>{
  let pet=funded(45,0);
  for(const [index,family] of ['bird','alien','moki','robot'].entries()){
   pet=mokiPet.renew(pet,now+index+1,0,family as typeof families[number]);
   expect(pet.player.adoptions).toBe(index+1);
   expect(pet.player.stars).toBe([45,45,25,5][index]);
   pet=mokiPet.restore(JSON.stringify(pet),now+index+1);
  }
  expect(mokiPet.adoptionQuote(pet).cost).toBe(20);
  expect(mokiPet.adoptionQuote(pet).freeLeft).toBe(0);
 });
 it('keeps the current pet and coins when the fee cannot be paid',()=>{
  const pet=funded(19),next=mokiPet.renew(pet,now+1,0,'alien');
  expect(next.bornAt).toBe(pet.bornAt);expect(next.variant).toBe('bit');
  expect(next.player.stars).toBe(19);expect(next.player.adoptions).toBe(2);
  expect(mokiPet.adoptionQuote(next).affordable).toBeFalse();
 });
 it('accepts exact funds and rejects a repeated stale confirmation without another charge',()=>{
  const pet=funded(20),next=mokiPet.renew(pet,now+1,0,'alien',pet.bornAt);
  expect(next.variant).toBe('orbita');expect(next.player.stars).toBe(0);expect(next.player.adoptions).toBe(3);
  const duplicate=mokiPet.renew(next,now+2,0,'bird',pet.bornAt);
  expect(duplicate).toBe(next);
 });
 it('makes a new companion after death free without consuming a free change',()=>{
  const pet={...funded(0,3),stage:'baby' as const};
  pet.life={...pet.life,diedAt:now,cause:'hunger'};
  const next=mokiPet.renew(pet,now+1,0,'bird');
  expect(mokiVariants.family(next.variant)).toBe('bird');
  expect(next.life.diedAt).toBeNull();expect(next.player.stars).toBe(0);expect(next.player.adoptions).toBe(3);
 });
 it('never charges while an activity or unclaimed expedition reward blocks adoption',()=>{
  const ready={...funded(),stage:'baby' as const,hunger:20,fatigue:20,dirt:20,mood:90};
  const trip=mokiPet.startExpedition(ready,'garden',now,.5);
  const cases=[trip,mokiPet.advance(trip,now+900000),mokiPet.startGame(ready,now,42),mokiPet.startMemory(ready,now,42),mokiPet.act(ready,'startWorkout',now)];
  for(const pet of cases){
   const next=mokiPet.renew(pet,pet.updatedAt,0,'bird');
   expect(next.bornAt).toBe(pet.bornAt);expect(next.player.stars).toBe(45);expect(next.player.adoptions).toBe(2);
  }
  const locked=mokiPet.renew(ready,now,0,'divine');
  expect(locked.variant).toBe('bit');expect(locked.player.stars).toBe(45);
 });
 it('preserves variant rotation, accessories and the 12-adult legendary requirement',()=>{
  let pet=mokiPet.chooseStarter(mokiPet.begin(now),'moki',now+1,0);
  pet=mokiPet.renew(pet,now+2,0,'moki');expect(pet.variant).toBe('lila');
  pet=mokiPet.renew(pet,now+3,0,'moki');expect(pet.variant).toBe('amber');
  pet.player.raised=mokiVariants.ids.filter(id=>id!=='auri');
  pet.player.wardrobe.owned=['leafClip'];pet.player.stars=20;
  const restored=mokiPet.restore(JSON.stringify(pet),now+4);
  expect(restored.player.divineUnlocked).toBeTrue();
  const legendary=mokiPet.renew(restored,now+5,0,'divine');
  expect(legendary.variant).toBe('auri');expect(legendary.player.stars).toBe(0);
  expect(legendary.player.raised).toEqual(pet.player.raised);expect(legendary.player.wardrobe.owned).toContain('leafClip');
 });
});
describe('Companion replacement storage',()=>{
 afterEach(()=>{cleanup();localStorage.removeItem(mokiPet.key);});
 it('keeps the pet and fee unchanged if storage fails, then commits both together on retry',()=>{
  const initial=funded(40);initial.bornAt=Date.now();initial.updatedAt=initial.bornAt;initial.life.startedAt=initial.bornAt;
  localStorage.setItem(mokiPet.key,JSON.stringify(initial));
  const {result}=renderHook(()=>useMokiPet()),token=result.current.pet.bornAt;
  const storage=spyOn(Storage.prototype,'setItem').and.throwError('Quota exceeded');
  act(()=>{result.current.newEgg('bird',token);});
  expect(result.current.saved).toBeFalse();
  expect(result.current.pet.bornAt).toBe(token);expect(result.current.pet.player.stars).toBe(40);expect(result.current.pet.player.adoptions).toBe(2);
  expect(JSON.parse(localStorage.getItem(mokiPet.key)!).variant).toBe('bit');
  storage.and.callThrough();
  act(()=>{result.current.newEgg('bird',token);});
  expect(result.current.saved).toBeTrue();
  expect(result.current.pet.player.stars).toBe(20);expect(result.current.pet.player.adoptions).toBe(3);
  const stored=JSON.parse(localStorage.getItem(mokiPet.key)!);
  expect(stored.bornAt).toBe(result.current.pet.bornAt);expect(stored.player.stars).toBe(20);expect(stored.player.adoptions).toBe(3);
 });
});
describe('Welcome and egg selection',()=>{
 afterEach(cleanup);
 it('shows four family eggs and waits for an explicit choice and confirmation',()=>{
  const choose=jasmine.createSpy('choose'),view=render(<MokiWelcome pet={mokiPet.begin(now)} language="es" saved onChoose={choose} onContinue={()=>{}} onGuide={()=>{}}/>);
  expect(view.queryByTestId('egg-picker')).toBeNull();
  fireEvent.click(view.getByTestId('welcome-continue'));
  for(const family of families)expect(view.getByTestId('egg-choice-'+family)).toBeTruthy();
  expect(view.queryByTestId('egg-choice-divine')).toBeNull();
  expect((view.getByTestId('confirm-starter') as HTMLButtonElement).disabled).toBeTrue();
  fireEvent.click(view.getByTestId('egg-choice-alien'));
  expect(choose).not.toHaveBeenCalled();
  expect(view.getByTestId('egg-choice-alien').getAttribute('aria-pressed')).toBe('true');
  fireEvent.click(view.getByTestId('confirm-starter'));expect(choose).toHaveBeenCalledOnceWith('alien');
 });
 it('continues with an existing pet and offers no replacement on the opening screen',()=>{
  const resume=jasmine.createSpy('continue'),choose=jasmine.createSpy('choose');
  const view=render(<MokiWelcome pet={funded()} language="en" saved onChoose={choose} onContinue={resume} onGuide={()=>{}}/>);
  expect(view.getByTestId('welcome-continue').textContent).toContain('Continue with Bit');
  fireEvent.click(view.getByTestId('welcome-continue'));
  expect(resume).toHaveBeenCalledTimes(1);expect(choose).not.toHaveBeenCalled();expect(view.queryByTestId('egg-picker')).toBeNull();
 });
 it('does not confirm the first egg while progress cannot be saved',()=>{
  const choose=jasmine.createSpy('choose'),view=render(<MokiWelcome pet={mokiPet.begin(now)} language="en" saved={false} onChoose={choose} onContinue={()=>{}} onGuide={()=>{}}/>);
  fireEvent.click(view.getByTestId('welcome-continue'));fireEvent.click(view.getByTestId('egg-choice-robot'));
  expect((view.getByTestId('confirm-starter') as HTMLButtonElement).disabled).toBeTrue();
  expect(view.getByRole('alert').textContent).toContain('cannot be saved');
  fireEvent.click(view.getByTestId('confirm-starter'));expect(choose).not.toHaveBeenCalled();
 });
});
