import {mokiCanvas} from './mokiCanvas';
type Stage = 'baby' | 'teen' | 'adult';
type Sheets = Record<Stage, HTMLCanvasElement>;

// Authored exercise poses: crouch, launch, open jump, soft landing.
// The source atlas keeps its original transparency; sampling happens once.
const sourceFrames: Record<Stage, number[][]> = {
  baby: [[81,134,246,195],[430,77,250,234],[789,79,251,232],[1133,138,257,192]],
  teen: [[80,424,266,262],[438,371,256,283],[785,373,268,297],[1133,411,274,274]],
  adult: [[55,754,316,286],[429,709,282,319],[760,702,303,320],[1118,746,302,294]]
};
const scale = { baby:40/234, teen:48/283, adult:51/319 };
const palette = ['092b3c','19656a','26978f','47b5a0','80d6b4','eed3a0','fff1ce','baaa85','867152','554b3b','d96319','ff9d19','ffe283','265b35','c5e6e9','ffffff']
  .map(hex => [0,2,4].map(i=>parseInt(hex.slice(i,i+2),16)));
const sequence = {sheet:0,frames:[4,0,1,2,1,3,0,4],times:[160,130,80,110,90,110,90,230],cycles:0};
const heights = [0,0,-3,-7,-3,0,0,0];
const labels = ['ready','crouch','launch','jump','descend','land','recover','ready'];

function prepare(image: HTMLImageElement): Sheets {
  const sheets = {} as Sheets;
  for (const stage of ['baby','teen','adult'] as const) {
    const sheet = document.createElement('canvas');
    sheet.width=256;sheet.height=64;
    const ctx=sheet.getContext('2d');
    if(!ctx)throw new Error('Cannot prepare exercise sprites');
    ctx.imageSmoothingEnabled=false;
    sourceFrames[stage].forEach(([x,y,w,h],i)=>{
      const width=Math.round(w*scale[stage]),height=Math.round(h*scale[stage]);
      ctx.drawImage(image,x,y,w,h,i*64+Math.round((64-width)/2),59-height,width,height);
    });
    // Snap the generated art to the existing 16-color palette, once at load.
    // The animation then only displays whole, unblended pixel frames.
    const pixels=mokiCanvas.readPixels(ctx,0,0,256,64);
    if(!pixels){sheets[stage]=sheet;continue;} // Keep the authored poses if palette sampling is unavailable.
    for(let i=0;i<pixels.data.length;i+=4) {
      if(pixels.data[i+3]<128) { pixels.data[i+3]=0;continue; }
      let nearest=palette[0],distance=Infinity;
      for(const color of palette) {
        const d=(pixels.data[i]-color[0])**2+(pixels.data[i+1]-color[1])**2+(pixels.data[i+2]-color[2])**2;
        if(d<distance) { nearest=color;distance=d; }
      }
      pixels.data[i]=nearest[0];pixels.data[i+1]=nearest[1];pixels.data[i+2]=nearest[2];pixels.data[i+3]=255;
    }
    ctx.putImageData(pixels,0,0);
    sheets[stage]=sheet;
  }
  return sheets;
}

function draw(ctx:CanvasRenderingContext2D,sheet:HTMLCanvasElement,idle:HTMLImageElement,index:number,reducedMotion=false,offsets:readonly number[]=heights,floating=false) {
  const step=reducedMotion ? 0 : index%sequence.frames.length;
  const frame=sequence.frames[step],height=offsets[step]??0;
  ctx.imageSmoothingEnabled=false;
  ctx.drawImage(frame===4 ? idle : sheet,frame===4 ? 0 : frame*64,0,64,64,0,height,64,64);
  if(!floating && !reducedMotion && (step===5 || step===6)) {
    const spread=step===6 ? 4 : 0;
    ctx.save();ctx.globalAlpha=step===6 ? .35 : .75;ctx.fillStyle='#eed3a0';
    ctx.fillRect(14-spread,58,4,2);ctx.fillRect(12-spread,57,2,1);
    ctx.fillRect(46+spread,58,4,2);ctx.fillRect(50+spread,57,2,1);
    ctx.restore();
  }
  return {pose:labels[step],shadowScale:height===0 ? 1 : height===-3 ? .86 : .72,shadowOpacity:height===0 ? .35 : .22};
}

export const mokiWorkoutAnimation = {
  src:'/_cdn/static/42409afb-88b3-40b2-8518-cf7b8fc715b0-moki-green-workout-atlas.png',
  prepare,draw,sequence,offsets:heights
};
