// Configure your own PUBLIC Web Push key for a self-hosted deployment.
// This value is intentionally empty in the source release candidate.
export const VAPID_PUBLIC_KEY = "";
