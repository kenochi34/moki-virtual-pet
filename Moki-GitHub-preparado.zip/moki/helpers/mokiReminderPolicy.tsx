import {mokiLife} from './mokiLife';
import {z} from 'zod';
import {mokiVariants} from './mokiVariants';
const need=z.enum(['hunger','fatigue','dirt']);
const life=z.object({version:z.literal(1),startedAt:z.number().nonnegative(),criticalSince:z.object({hunger:z.number().nonnegative().nullable(),fatigue:z.number().nonnegative().nullable(),dirt:z.number().nonnegative().nullable()}),diedAt:z.number().nonnegative().nullable(),cause:need.nullable()});
const snapshot=z.object({life:life.optional(),variant:z.enum(mokiVariants.ids),stage:z.enum(['egg','baby','teen','adult']),sleeping:z.boolean(),hunger:z.number().min(0).max(100),fatigue:z.number().min(0).max(100),dirt:z.number().min(0).max(100),mood:z.number().min(0).max(100)});
const preferences=z.object({hunger:z.boolean(),sleep:z.boolean(),care:z.boolean()});
const defaults={hunger:true,sleep:true,care:true};
type Snapshot=z.infer<typeof snapshot>;
type Preferences=z.infer<typeof preferences>;
type State={snapshot:unknown;preferences:unknown;timezone:string;lastSeenAt:Date;lastSentAt:Date|null;sentDay:string;sentToday:number};
const HOUR=3600000,MINUTE=60000;
function validZone(zone:string){try{new Intl.DateTimeFormat('en',{timeZone:zone}).format(0);return true;}catch{return false;}}
function local(now:number,zone:string){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'}).formatToParts(now);const get=(key:string)=>parts.find(p=>p.type===key)?.value??'';return {day:`${get('year')}-${get('month')}-${get('day')}`,hour:Number(get('hour'))};}
function quiet(now:number,zone:string){const h=local(now,zone).hour;return h<8||h>=22;}
function quietEnd(now:number,zone:string){let next=now;for(let n=0;n<96&&quiet(next,zone);n++)next+=15*MINUTE;return next;}
function nextDay(now:number,zone:string){const day=local(now,zone).day;let next=now+15*MINUTE;for(let n=0;n<100&&(local(next,zone).day===day||quiet(next,zone));n++)next+=15*MINUTE;return next;}
function project(s:Snapshot,hours:number){const cap=(x:number)=>Math.max(0,Math.min(100,x));const hungerRate=s.sleeping?(mokiVariants.family(s.variant)==='robot'?-40:2):12,dirtRate=s.sleeping?1.5:9,fatigueRate=s.sleeping?-120:10;const discomfort=(start:number,rate:number)=>rate>0?Math.max(0,hours-Math.max(0,(80-start)/rate)):Math.min(hours,Math.max(0,(start-80)/-rate));return {...s,hunger:cap(s.hunger+hungerRate*hours),dirt:cap(s.dirt+dirtRate*hours),fatigue:cap(s.fatigue+fatigueRate*hours),mood:cap(s.mood-hours*(s.sleeping?.6:2)-discomfort(s.hunger,hungerRate)*2-discomfort(s.dirt,dirtRate)-discomfort(s.fatigue,fatigueRate)*1.5)};}
function decision(state:State,now:number){
 const s=snapshot.safeParse(state.snapshot),p=preferences.safeParse(state.preferences),zone=validZone(state.timezone)?state.timezone:'UTC';
 const seen=state.lastSeenAt.getTime(),age=Math.max(0,now-seen),day=local(now,zone).day;
 const skip=(next:number)=>({reason:null as string|null,nextCheckAt:new Date(next),day});
 if(!s.success||!p.success||s.data.stage==='egg'||!Object.values(p.data).some(Boolean)||age>=72*HOUR)return skip(now+24*HOUR);
 const projectedLife=s.data.life?mokiLife.advance({...s.data,life:s.data.life,updatedAt:seen},now):null;
 if(projectedLife?.diedAt!=null)return skip(now+24*HOUR);
 if(age<90*1000)return skip(seen+15*MINUTE);
 if(quiet(now,zone))return skip(quietEnd(now,zone));
 if(state.sentDay===day&&state.sentToday>=2)return skip(nextDay(now,zone));
 if(state.lastSentAt&&now-state.lastSentAt.getTime()<6*HOUR)return skip(quietEnd(state.lastSentAt.getTime()+6*HOUR,zone));
 const pet=project(s.data,age/HOUR),choices:{reason:string;score:number}[]=[];
 if(p.data.hunger&&pet.hunger>=70)choices.push({reason:'hunger',score:pet.hunger});
 if(p.data.sleep&&pet.fatigue>=70)choices.push({reason:'sleep',score:pet.fatigue});
 if(p.data.care&&pet.dirt>=70)choices.push({reason:'bath',score:pet.dirt});
 if(p.data.care&&pet.mood<35)choices.push({reason:'mood',score:100-pet.mood});
 if(projectedLife){const health=mokiLife.status(projectedLife,now);for(const key of health.active){if(key==='hunger'&&p.data.hunger||key==='fatigue'&&p.data.sleep||key==='dirt'&&p.data.care)choices.push({reason:`danger_${key}`,score:200+(48-health.remainingHours)});}}
 if(s.data.sleeping&&!choices.some(c=>c.reason.startsWith('danger_')))return skip(now+15*MINUTE);
 const reason=choices.sort((a,b)=>b.score-a.score)[0]?.reason??null;
 return {reason,nextCheckAt:new Date(now+15*MINUTE),day};
}
function message(reason:string,variant:string,language:string){const robot=mokiVariants.family(variant)==='robot',es=language==='es';const bodies:Record<string,string>={danger_hunger:robot?(es?'Tu robot tiene muy poca energía. Una recarga le ayudará a recuperarse.':'Your robot is very low on energy. A recharge will help it recover.'):(es?'Moki está débil por el hambre. Dale comida para que pueda recuperarse.':'Moki is weak from hunger. A meal will help it recover.'),danger_fatigue:es?'Moki necesita descansar para recuperarse.':'Moki needs some rest to recover.',danger_dirt:robot?(es?'Tu robot necesita mantenimiento para recuperarse.':'Your robot needs maintenance to recover.'):(es?'Moki necesita un baño para recuperarse.':'Moki needs a bath to recover.'),hunger:robot?(es?'Tu robot necesita recargar su energía.':'Your robot could use an energy recharge.'):(es?'Moki tiene hambre. Hay comida en su cuarto.':'Moki is hungry. There is food in the room.'),sleep:robot?(es?'A tu robot le vendría bien un rato de reposo.':'Your robot could use some time on standby.'):(es?'A Moki le vendría bien descansar un rato.':'Moki could use a little rest.'),bath:robot?(es?'Es hora de cuidar las articulaciones de tu robot.':'Time for a little robot maintenance.'):(es?'Un baño dejará a Moki limpio y feliz.':'A bath will leave Moki fresh and happy.'),mood:es?'Moki agradecería unas caricias o un ratito de juego.':'Moki would enjoy some affection or a little playtime.',test:es?'¡Funcionan! Aquí recibirás los recordatorios de tu Moki.':'It works! Your Moki reminders will appear here.'};return {title:reason==='test'?(es?'Moki · Prueba de aviso':'Moki · Test notification'):'Moki',body:bodies[reason]??bodies.mood};}
export const mokiReminderPolicy={snapshot,preferences,defaults,validZone,local,quiet,quietEnd,project,decision,message};