import React from 'react';
import {render,fireEvent,cleanup} from '@testing-library/react';
import {MokiExploration} from '../components/MokiExploration';
import {MokiGames} from '../components/MokiGames';
import {mokiPet} from './mokiPet';
const now=1800000000000;
const pet=()=>({...mokiPet.create(now),stage:'baby' as const,hunger:20,fatigue:20,dirt:20,mood:90,care:100});
const no=()=>{};
describe('Play activity access',()=>{
 let nativeEvent:typeof Event,nativeCustomEvent:typeof CustomEvent;
 beforeEach(()=>{nativeEvent=globalThis.Event;nativeCustomEvent=globalThis.CustomEvent;globalThis.Event=window.Event;globalThis.CustomEvent=window.CustomEvent;});
 afterEach(()=>{cleanup();globalThis.Event=nativeEvent;globalThis.CustomEvent=nativeCustomEvent;});
 it('recovers a failed map thumbnail without blocking exploration and resets it for another family',()=>{
  const explore=jasmine.createSpy('explore');
  const props={pet:pet(),open:true,onOpenChange:no,onReturnFocus:no,language:'en' as const,saved:true,disabled:false,onStart:no,onStop:no,onTick:no,onCatch:()=>false,onMemoryStart:no,onMemoryPause:no,onMemoryFlip:()=>'ignored' as const,onSound:no,onExplore:explore,onExercise:no,exerciseDisabled:false};
  const view=render(<MokiGames {...props}/>);
  const image=view.getByTestId('exploration-thumbnail') as HTMLImageElement;
  expect(image.tagName).toBe('IMG');
  expect(image.getAttribute('src')).toBe('/_cdn/static/4823d2fa-907b-4d65-a811-c157f731285a.png');
  fireEvent.error(image);
  expect(view.getByText('Preview unavailable.')).toBeTruthy();
  fireEvent.click(view.getByTestId('explore-control'));expect(explore).toHaveBeenCalledTimes(1);
  fireEvent.click(view.getByTestId('retry-map-preview'));expect(view.queryByText('Preview unavailable.')).toBeNull();
  fireEvent.error(view.getByTestId('exploration-thumbnail'));
  view.rerender(<MokiGames {...props} pet={{...pet(),variant:'bit'}}/>);
  expect(view.queryByText('Preview unavailable.')).toBeNull();
  expect(view.getByTestId('exploration-thumbnail').getAttribute('src')).toBe('/_cdn/static/c3b3f44d-ef51-4174-978f-fdf384cf6b5b.png');
 });
 for(const state of ['sleeping','away'] as const)it('keeps the map reachable while '+state+', without allowing games or exercise',()=>{
  const p=state==='sleeping'?{...pet(),sleeping:true}:mokiPet.startExpedition(pet(),'garden',now,.5),explore=jasmine.createSpy('explore');
  const view=(()=>{try{return render(<MokiGames pet={p} open onOpenChange={no} onReturnFocus={no} language="en" saved disabled onStart={no} onStop={no} onTick={no} onCatch={()=>false} onMemoryStart={no} onMemoryPause={no} onMemoryFlip={()=>'ignored'} onSound={no} onExplore={explore} onExercise={no} exerciseDisabled/>);}catch(error){throw new Error(error instanceof AggregateError?error.errors.map(String).join("; "):String(error));}})();
  expect((view.getByTestId('choose-game') as HTMLButtonElement).disabled).toBeTrue();
  expect((view.getByTestId('gym-control') as HTMLButtonElement).disabled).toBeTrue();
  expect((view.getByTestId('explore-control') as HTMLButtonElement).disabled).toBeFalse();
  fireEvent.click(view.getByTestId('explore-control'));expect(explore).toHaveBeenCalledTimes(1);
 });
});
describe('Exploration controls',()=>{
 afterEach(cleanup);
 it('changes routes and explains the baby age requirement',()=>{
  const start=jasmine.createSpy('start'),p=pet();
  const view=render(<MokiExploration pet={p} language="es" saved now={now} onBack={no} onStart={start} onRecall={no} onClaim={no} onTick={no}/>);
  const button=view.getByTestId('start-expedition') as HTMLButtonElement;
  expect(button.disabled).toBeFalse();
  fireEvent.click(view.getByTestId('route-stream'));expect(button.disabled).toBeTrue();
  expect(view.getByText('Disponible desde adolescente.')).toBeTruthy();
  fireEvent.click(view.getByTestId('route-garden'));fireEvent.click(button);
  expect(start).toHaveBeenCalledOnceWith('garden');
 });
 it('requires explicit early-return confirmation and shows the active route',()=>{
  const p=mokiPet.startExpedition(pet(),'garden',now,.5),recall=jasmine.createSpy('recall');
  const view=render(<MokiExploration pet={p} language="es" saved now={now+60000} onBack={no} onStart={no} onRecall={recall} onClaim={no} onTick={no}/>);
  expect(view.getByRole('timer').textContent).toBe('14:00');
  fireEvent.click(view.getByTestId('recall-expedition'));expect(recall).not.toHaveBeenCalled();
  fireEvent.click(view.getByTestId('confirm-recall'));expect(recall).toHaveBeenCalledTimes(1);
 });
 it('offers the saved reward by its receipt id and blocks departure when saving fails',()=>{
  const p=mokiPet.advance(mokiPet.startExpedition(pet(),'garden',now,.5),now+900000),claim=jasmine.createSpy('claim');
  const view=render(<MokiExploration pet={p} language="en" saved now={now+900000} onBack={no} onStart={no} onRecall={no} onClaim={claim} onTick={no}/>);
  fireEvent.click(view.getByTestId('claim-expedition'));expect(claim).toHaveBeenCalledOnceWith(p.expeditionReward!.id);
  view.rerender(<MokiExploration pet={pet()} language="en" saved={false} now={now} onBack={no} onStart={no} onRecall={no} onClaim={no} onTick={no}/>);
  expect((view.getByTestId('start-expedition') as HTMLButtonElement).disabled).toBeTrue();
  expect(view.getByRole('alert').textContent).toContain('Could not save');
 });
});
