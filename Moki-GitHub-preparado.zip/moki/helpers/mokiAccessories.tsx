import {mokiCanvas} from './mokiCanvas';
import { mokiAccessoryStyles } from './mokiAccessoryStyles';
import { mokiWardrobe } from './mokiWardrobe';
import { mokiWorkoutAnimation } from './mokiWorkoutAnimation';
type Stage='baby'|'teen'|'adult';
type Outfit=ReturnType<typeof mokiWardrobe.create>['equipped'];
type Rect=[number,number,number,number,string];
type Eyes=[number,number,number,number,number,number,number,number];
const ink='#092b3c',gold='#f3c66d',light='#fff1ce';
const colors:Record<string,string>={D:ink,P:'#9678d1',B:'#674797',H:'#c3aeef',Y:gold,R:'#df776b',T:'#a94853',L:'#ffc3a0'};
const cap=[
'........DDDDDDDDDD........',
'......DDHHHHHHHHPPDD......',
'.....DHHPPPPPPPPPPPPD.....',
'....DHPPPPPPYPPPPPPPPD....',
'....DPPPPPPYYYPPPPPPPD....',
'....DPPPPPPPYPPPPPPPPD....',
'....DPPPPPPPPPPPPPPPPD....',
'...DDPPPPPPPPPPPPPPPPDD...',
'.DDHHHHHHHHHHHHHHHHHHPPDD.',
'DPPPPPPPPPPPPPPPPPPPPPPPPD',
'.DDDBBBBBBBBBBBBBBBBBBDDD.',
'....DDDDDDDDDDDDDDDDDD....'
];
const bandana=[
'DDDDDDDDDDDDDDDDDD',
'DLLLLLLLLLRRRRRRTD',
'.DRRRRRRRRRRRRRTD.',
'..DRRRRRYRRRRRTD..',
'...DRRRYYYRRRTD...',
'....DRRRYRRRTD....',
'.....DRRRRRTD.....',
'......DRRRTD......',
'.......DRTD.......',
'........DD........'
];
function pixels(rows:string[],x:number,y:number):Rect[] {
  return rows.flatMap((row,dy)=>Array.from(row).flatMap((key,dx)=>colors[key] ? [[x+dx,y+dy,1,1,colors[key]] as Rect] : []));
}
function ring(x:number,y:number,w:number,h:number):Rect[] {
  return [
    [x,y+2,1,h-4,ink],[x+w-1,y+2,1,h-4,ink],[x+2,y,w-4,1,ink],[x+2,y+h-1,w-4,1,ink],
    [x+1,y+1,1,h-2,gold],[x+w-2,y+1,1,h-2,gold],[x+1,y+1,w-2,1,gold],[x+1,y+h-2,w-2,1,gold],
    [x+2,y+1,2,1,light]
  ];
}
function glasses(eyes:Eyes):Rect[] {
  const [x,y,w,h,rx,ry,rw,rh]=eyes;
  return [...ring(x-2,y-2,w+4,h+4),...ring(rx-2,ry-2,rw+4,rh+4),
    [x+w+1,y+2,Math.max(1,rx-x-w-2),1,ink],[x+w+1,y+3,Math.max(1,rx-x-w-2),1,gold],
    [x-4,y+1,2,2,gold],[rx+rw+2,ry+1,2,2,gold]];
}
const idle:Record<Stage,Eyes>={
  baby:[18,34,5,7,31,36,6,7],teen:[18,26,4,6,29,28,6,6],adult:[15,25,5,6,28,26,6,7]
};
const eating:Record<Stage,Eyes>={
  baby:[20,33,5,6,32,34,6,7],teen:[18,27,4,5,29,28,6,6],adult:[15,23,4,5,27,24,6,6]
};
const jumping:Record<Stage,Eyes[]>={
  baby:[[20,41,4,5,31,42,5,6],[21,31,4,6,32,33,5,6],[20,31,5,6,31,34,6,6],[20,40,4,6,31,41,5,6]],
  teen:[[19,31,4,5,29,32,5,6],[20,25,4,6,31,27,5,6],[21,23,4,6,31,24,6,6],[19,29,4,6,29,31,5,6]],
  adult:[[17,28,4,6,28,29,6,6],[20,22,4,5,30,23,6,6],[19,22,4,6,29,23,6,6],[18,30,4,5,29,31,6,6]]
};
function icon(id:string):Rect[] {
  if(id==='cap')return pixels(cap,2,3);
  if(id==='bandana')return pixels(bandana,6,5);
  return id==='glasses'?glasses([5,6,4,5,18,7,5,5]):mokiAccessoryStyles.icon(id);
}
function measure(ctx:CanvasRenderingContext2D,initial:Eyes,variant:string,stage:Stage,phase='idle'){
  const data=mokiCanvas.readPixels(ctx,0,0,64,64)?.data,transform=ctx.getTransform(),tx=Math.round(transform.e),ty=Math.round(transform.f);
  const index=(x:number,y:number)=>{x=Math.round(x)+tx;y=Math.round(y)+ty;return x>=0&&x<64&&y>=0&&y<64?(y*64+x)*4:-1;};
  // Authored face anchors still position accessories if pixel sampling is blocked.
  const solid=(x:number,y:number)=>{const i=index(x,y);return i>=0&&(data?data[i+3]>=128:x>=initial[0]-5&&x<=initial[4]+initial[6]+5&&y>=Math.min(initial[1],initial[5])-10&&y<=61);};
  const original=(x:number,y:number):Rect|null=>{const i=index(x,y);return data&&i>=0&&data[i+3]?[x,y,1,1,`rgba(${data[i]},${data[i+1]},${data[i+2]},${data[i+3]/255})`]:null;};
  const robot=['bit','volt','tuerca'].includes(variant),bird=['cielo','coral','noche'].includes(variant),alien=['orbita','nova','nebula'].includes(variant);
  let eyes=[...initial] as Eyes;
  if(data&&variant==='green'){
    const x0=Math.max(1,initial[0]-5),x1=Math.min(62,initial[4]+initial[6]+5),y0=Math.max(1,Math.min(initial[1],initial[5])-4),y1=Math.min(62,Math.max(initial[1]+initial[3],initial[5]+initial[7])+4);
    const seen=new Set<number>(),groups:{x:number;y:number;w:number;h:number;n:number}[]=[];
    const eyePixel=(x:number,y:number)=>{const i=index(x,y);if(i<0||!data[i+3])return false;const r=data[i],g=data[i+1],b=data[i+2];
      return r<45&&g<75&&b<85;
    };
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      const key=y*64+x;if(seen.has(key)||!eyePixel(x,y))continue;
      const queue=[[x,y]];seen.add(key);let left=x,right=x,top=y,bottom=y;
      for(let n=0;n<queue.length;n++){const [px,py]=queue[n];left=Math.min(left,px);right=Math.max(right,px);top=Math.min(top,py);bottom=Math.max(bottom,py);
        for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const nx=px+dx,ny=py+dy,k=ny*64+nx;if(nx<x0||nx>x1||ny<y0||ny>y1||seen.has(k)||!eyePixel(nx,ny))continue;seen.add(k);queue.push([nx,ny]);}
      }
      if(queue.length>=2&&queue.length<95&&right-left<10&&bottom-top<12&&left>x0&&right<x1&&top>y0&&bottom<y1)groups.push({x:left,y:top,w:right-left+1,h:bottom-top+1,n:queue.length});
    }
    for(const base of [0,4]){const cx=initial[base]+initial[base+2]/2,cy=initial[base+1]+initial[base+3]/2;
      const best=groups.map(g=>({g,score:Math.abs(g.x+g.w/2-cx)*1.4+Math.abs(g.y+g.h/2-cy)})).filter(a=>a.score<6).sort((a,b)=>a.score-b.score)[0]?.g;
      if(best){const w=initial[base+2],h=initial[base+3];eyes[base]=Math.round(best.x+best.w/2-w/2);eyes[base+1]=Math.round(best.y+best.h/2-h/2);eyes[base+2]=w;eyes[base+3]=h;}
    }
  }
  const leftEye=eyes[0]+eyes[2]/2,rightEye=eyes[4]+eyes[6]/2,cx=(leftEye+rightEye)/2;
  const tilt=Math.max(-.8,Math.min(.8,(eyes[5]+eyes[7]/2-eyes[1]-eyes[3]/2)/Math.max(7,rightEye-leftEye)));
  function span(y:number,center=cx){let middle=Math.round(center);if(!solid(middle,y))for(let d=1;d<=4;d++){if(solid(middle-d,y)){middle-=d;break;}if(solid(middle+d,y)){middle+=d;break;}}
    if(!solid(middle,y))return {left:middle,right:middle,width:0};let left=middle,right=middle;
    while(left>1&&solid(left-1,y+Math.round((left-1-center)*tilt)))left--;while(right<62&&solid(right+1,y+Math.round((right+1-center)*tilt)))right++;
    return {left,right,width:right-left+1};
  }
  const eyeTop=Math.min(eyes[1],eyes[5]),eyeBottom=Math.max(eyes[1]+eyes[3],eyes[5]+eyes[7]);
  let crown=eyeTop-3;
  const minWidth=Math.max(12,rightEye-leftEye+4);
  for(let y=Math.max(1,Math.floor(eyeTop-17));y<=eyeTop-2;y++){if(span(y).width>=minWidth&&span(y+1).width>=minWidth){crown=y;break;}}
  const forehead=span(Math.round((eyes[1]+eyes[5])/2)-5),headX=(forehead.left+forehead.right)/2*.65+cx*.35;
  const eyeSpan=eyes[4]+eyes[6]-eyes[0];
  const hatWidth=Math.round(Math.max(18,Math.min(30,eyeSpan+6)));
  const seat=Math.round((eyes[1]+eyes[5])/2)-3,hatHeight=Math.max(8,Math.min(12,Math.round(hatWidth*.43)));
  const stageIndex=stage==='baby'?0:stage==='teen'?1:2;
  const neckOffsets:Record<string,number[]>={auri:[2,3,4],bit:[5,5,7],volt:[7,8,10],tuerca:[5,6,6],orbita:[1,2,3],nova:[3,3,3],nebula:[3,3,3]};
  const neckY=(robot?(eyes[1]+eyes[3]+eyes[5]+eyes[7])/2:eyeBottom)+(neckOffsets[variant]?.[stageIndex]??(bird?2:stage==='baby'?4:3))-(variant==='volt'&&phase==='exercising'?4:0);
  const neckSpan=span(neckY),rowCenter=neckSpan.width?(neckSpan.left+neckSpan.right)/2:cx;
  const neckX=robot?rowCenter*.7+cx*.3:rowCenter*.2+cx*.8;
  const maxNeck=variant==='auri'?eyeSpan*(stage==='baby'?1:.8):robot?Math.max(8,Math.min(12,eyeSpan*.6)):bird?eyeSpan*.95:alien?eyeSpan*(variant==='nova'?.65:.95):eyeSpan*(stage==='baby'?1.35:.8);
  const neckWidth=Math.max(6,Math.min(maxNeck,neckSpan.width-2));
  return {eyes,tilt,headX,seat,hatWidth,hatHeight,crown,neckX,neckY,neckWidth,robot,bird,alien,solid,original};
}
function fittedGlasses(eyes:Eyes,tilt:number):Rect[]{
  const result:Rect[]=[];
  const heights=[eyes[3],eyes[7]],sameHeight=Math.max(5,Math.min(8,Math.max(...heights)+2));
  const lenses=[0,4].map(i=>({cx:eyes[i]+eyes[i+2]/2,cy:eyes[i+1]+eyes[i+3]/2,w:Math.max(5,Math.min(9,eyes[i+2]+2)),h:sameHeight}));
  for(const lens of lenses){const x=Math.round(lens.cx-lens.w/2),y=Math.round(lens.cy-lens.h/2);
    for(let dx=1;dx<lens.w-1;dx++)result.push([x+dx,y+lens.h+Math.round((dx-lens.w/2)*tilt*.45),1,1,ink]);
    for(let dy=2;dy<lens.h-1;dy++)result.push([x+lens.w,y+dy+Math.round(lens.w/2*tilt*.45),1,1,ink]);
    for(let dy=0;dy<lens.h;dy++)for(let dx=0;dx<lens.w;dx++){
      if(!(dx===0||dx===lens.w-1||dy===0||dy===lens.h-1))continue;
      if((dx===0||dx===lens.w-1)&&(dy===0||dy===lens.h-1))continue;
      result.push([x+dx,y+dy+Math.round((dx-lens.w/2)*tilt*.45),1,1,dy===0&&dx<lens.w/2?light:dy===lens.h-1?'#bd913d':gold]);
    }
  }
  const l=lenses[0],r=lenses[1],from=Math.round(l.cx+l.w/2)-1,to=Math.round(r.cx-r.w/2);
  for(let x=from;x<=to;x++)result.push([x,Math.round(l.cy+(r.cy-l.cy)*(x-from)/Math.max(1,to-from)),1,1,gold]);
  result.push([Math.round(l.cx-l.w/2)-2,Math.round(l.cy)-1,2,1,gold],[Math.round(r.cx+r.w/2),Math.round(r.cy)-1,2,1,gold]);
  return result;
}
function fittedCap(shape:ReturnType<typeof measure>):Rect[]{
  const rows=cap,width=shape.hatWidth,height=shape.hatHeight,left=Math.round(shape.headX-width/2),bottom=shape.seat,result:Rect[]=[];
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const color=colors[rows[Math.min(rows.length-1,Math.floor(y*rows.length/height))][Math.min(rows[0].length-1,Math.floor(x*rows[0].length/width))]];
    if(color)result.push([left+x,bottom-height+1+y+Math.round((left+x-shape.headX)*shape.tilt),1,1,color]);
  }
  // Crests, ears and antenna tips emerge above the crown of the hat.
  for(let y=0;y<shape.crown-3;y++)for(let x=left;x<left+width;x++){const pixel=shape.original(x,y);if(pixel)result.push(pixel);}
  return result;
}
function fittedBandana(shape:ReturnType<typeof measure>,stage:Stage,phase:string):Rect[]{
  const cx=Math.round(shape.neckX),cy=Math.round(shape.neckY),width=Math.round(shape.neckWidth),half=width/2,left=Math.round(cx-half),right=left+width-1,result:Rect[]=[];
  const curve=shape.robot?1:stage==='baby'||shape.bird||shape.alien?2:1,depth=shape.robot?3:Math.max(3,Math.min(6,Math.round(width*.28)));
  const paint=(x:number,y:number,color:string,loose=false)=>{if(loose||shape.solid(x,y))result.push([x,y,1,1,color]);};
  for(let x=left;x<=right;x++){
    const edge=Math.abs((x-cx)/half),y=cy-Math.round(curve*edge*edge)+Math.round((x-cx)*shape.tilt*.45);
    paint(x,y,edge>.72?colors.T:colors.L);paint(x,y+1,edge>.8?colors.T:colors.R);paint(x,y+2,colors.T);
  }
  if(phase!=='eating')for(let dy=1;dy<=depth;dy++){const w=Math.max(1,Math.round((depth-dy+1)*width/(depth*3)));for(let dx=-w;dx<=w;dx++)paint(cx+dx,cy+dy+1,Math.abs(dx)===w?colors.T:colors.R);}
  if(phase!=='eating'){paint(cx,cy+3,gold);if(depth>4){paint(cx,cy+4,gold);paint(cx-1,cy+3,gold);paint(cx+1,cy+3,gold);}}
  // A small side knot and two tails make the cloth visibly wrap behind the body.
  const knotX=right,ky=cy-curve+Math.round((right-cx)*shape.tilt*.45);
  for(let dy=0;dy<3;dy++)for(let dx=0;dx<3;dx++)paint(knotX+dx,ky+dy,dx===2||dy===2?colors.T:dy===0?colors.L:colors.R,true);
  paint(knotX+3,ky+2,colors.R,true);paint(knotX+3,ky+3,colors.R,true);paint(knotX+4,ky+4,colors.T,true);paint(knotX+3,ky,colors.T,true);
  return result;
}
function draw(ctx:CanvasRenderingContext2D,stage:Stage,phase:string,frame:number,outfit:Outfit,step=0,reducedMotion=false,fit?:Eyes,bird=false,variant='green') {
  if(!['idle','eating','exercising'].includes(phase)||!Object.values(outfit).some(Boolean))return;
  let eyes=phase==='eating'?eating[stage]:idle[stage];
  if(phase==='exercising'&&frame<4&&!reducedMotion){eyes=[...jumping[stage][frame]] as Eyes;const dy=mokiWorkoutAnimation.offsets[step]??0;eyes[1]+=dy;eyes[5]+=dy;}
  if(fit)eyes=fit;
  const shape=measure(ctx,eyes,variant,stage,phase==='exercising'&&(frame>=4||reducedMotion)?'idle':phase),rects:Rect[]=[];
  if(outfit.neck==='bandana'){
    rects.push(...fittedBandana(shape,stage,phase));
    if(variant==='green'&&stage==='baby')for(let y=Math.floor(shape.neckY);y<Math.min(60,shape.neckY+9);y++)for(let x=Math.floor(shape.neckX-shape.neckWidth/2);x<shape.neckX+shape.neckWidth/2;x++){
      const pixel=shape.original(x,y);if(pixel&&/rgba\((134,113,82|186,170,133|85,75,59),/.test(pixel[4]))rects.push(pixel);
    }
  }
  if(outfit.neck&&outfit.neck!=='bandana')rects.push(...mokiAccessoryStyles.neck(outfit.neck,shape,phase));
  if(outfit.head)rects.push(...(outfit.head==='cap'?fittedCap(shape):mokiAccessoryStyles.head(outfit.head,shape)));
  if(outfit.eyes)rects.push(...(outfit.eyes==='glasses'?fittedGlasses(shape.eyes,shape.tilt):mokiAccessoryStyles.eyes(outfit.eyes,shape)));
  ctx.save();for(const [x,y,w,h,color]of rects){ctx.fillStyle=color;ctx.fillRect(x,y,w,h);}ctx.restore();
}

// The accessory pixels dissolve while the underlying Moki stays completely intact.
const removalSequence={sheet:0,frames:[0,0,0,0,0,0,0],times:[70,80,80,80,80,80,130],cycles:1};
function prepareRemoval(idleSheet:HTMLImageElement,stage:Stage,outfit:Outfit,fit?:Eyes,bird=false,variant='green') {
  const canvas=document.createElement('canvas');canvas.width=64;canvas.height=64;
  const ctx=canvas.getContext('2d');
  if(!ctx)throw new Error('Cannot prepare accessory sparkle');
  ctx.imageSmoothingEnabled=false;ctx.drawImage(idleSheet,0,0,64,64,0,0,64,64);
  const base=mokiCanvas.readPixels(ctx,0,0,64,64);
  if(!base)return null; // Care continues without the optional sparkle transition.
  const shape=measure(ctx,fit??idle[stage],variant,stage);
  draw(ctx,stage,'idle',0,outfit,0,false,fit,bird,variant);
  const dressed=mokiCanvas.readPixels(ctx,0,0,64,64);
  if(!dressed)return null;
  const frames=[0,1,4,8,12,16,16].map(threshold=>{
    const layer=document.createElement('canvas');layer.width=64;layer.height=64;
    const lc=layer.getContext('2d')!;
    const pixels=lc.createImageData(64,64);
    for(let y=0;y<64;y++)for(let x=0;x<64;x++) {
      const i=(y*64+x)*4;
      const changed=dressed.data[i]!==base.data[i]||dressed.data[i+1]!==base.data[i+1]||dressed.data[i+2]!==base.data[i+2]||dressed.data[i+3]!==base.data[i+3];
      if(changed && (x*3+y*5)%16>=threshold)for(let c=0;c<4;c++)pixels.data[i+c]=dressed.data[i+c];
    }
    lc.putImageData(pixels,0,0);return layer;
  });
  const [x,y,w,h,rx,ry,rw,rh]=shape.eyes,center=Math.round((x+w/2+rx+rw/2)/2);
  const anchors:number[][]=[];
  if(outfit.head)anchors.push([Math.round(shape.headX),shape.seat-Math.round(shape.hatHeight/2)]);
  if(outfit.eyes)anchors.push([center,Math.round((y+h/2+ry+rh/2)/2)]);
  if(outfit.neck)anchors.push([Math.round(shape.neckX),Math.round(shape.neckY)+2]);
  return {frames,anchors};
}
function drawRemoval(ctx:CanvasRenderingContext2D,removal:NonNullable<ReturnType<typeof prepareRemoval>>,step:number,reducedMotion=false) {
  const frame=Math.min(6,Math.max(0,step));
  ctx.save();
  if(reducedMotion) {
    ctx.globalAlpha=1-frame/6;ctx.drawImage(removal.frames[0],0,0);ctx.restore();return;
  }
  ctx.drawImage(removal.frames[frame],0,0);
  if(frame>0 && frame<6) {
    const opacity=[0,.8,1,.85,.55,.25,0][frame];
    const drift=frame-1;
    for(const [ax,ay] of removal.anchors)for(let i=0;i<3;i++) {
      const x=ax+[-7,7,1][i]+[-1,1,0][i]*drift;
      const y=ay+[-2,1,5][i]-Math.floor(drift*(i===2?1:1.5));
      ctx.globalAlpha=opacity;ctx.fillStyle=i===1?'#ffd76f':'#fff1ce';
      ctx.fillRect(x,y,1,1);
      if(frame<4) {ctx.fillRect(x-1,y,3,1);ctx.fillRect(x,y-1,1,3);}
    }
  }
  ctx.restore();
}

export const mokiAccessories= {measure,draw,icon,removalSequence,prepareRemoval,drawRemoval};