import {sendPushNotifications} from '@floot/push';
import {randomUUID} from 'node:crypto';
import {mokiReminderPolicy} from './mokiReminderPolicy';
import {mokiRelease} from './mokiRelease';
export async function mokiPushDelivery(row:{subscription:unknown;snapshot:unknown;language:string},reason:string){
 const pet=mokiReminderPolicy.snapshot.safeParse(row.snapshot);
 const message=mokiReminderPolicy.message(reason,pet.success?pet.data.variant:'green',row.language);
 const results=await sendPushNotifications([row.subscription as Parameters<typeof sendPushNotifications>[0][number]],{...message,url:'/',icon:mokiRelease.icon,tag:`moki-${reason}-${randomUUID()}`,showWhenFocused:reason==='test',data:{kind:'moki-care',reason}});
 return results[0];
}