// Sprites are read back for accessory fitting, palette conversion and light effects.
// Native builds can serve CDN assets from a different origin than the WebView.
function load(src:string):Promise<HTMLImageElement> {
  return new Promise((resolve,reject)=>{
    const image=new Image();
    // Set before src: a no-CORS image can display but taints every canvas it touches.
    image.crossOrigin='anonymous';
    image.onload=()=>{image.onload=null;image.onerror=null;resolve(image);};
    image.onerror=()=>{image.onload=null;image.onerror=null;reject(new Error(`Could not load Moki sprite: ${src}`));};
    image.src=src;
  });
}
function readPixels(ctx:CanvasRenderingContext2D,x:number,y:number,width:number,height:number):ImageData|null {
  try {return ctx.getImageData(x,y,width,height);}
  catch(error) {
    // Preserve gameplay if an old cached/native image still disallows readback.
    // Other errors must remain visible instead of being mislabelled as CORS failures.
    if(error && typeof error==='object' && 'name' in error && error.name==='SecurityError')return null;
    throw error;
  }
}
export const mokiCanvas={load,readPixels};