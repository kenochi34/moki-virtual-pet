type Run = { id:string; startedAt:number; seed:number; deck:number[]; matched:number[]; revealed:number[]; attempts:number; hideAt:number|null; active:boolean };
type Result = { id:string; endedAt:number; attempts:number; stars:number; bonus:number };
const items = ['food','moon','drop','heart','egg','sparkle'] as const;
const hideDelay = 850;
function reward(attempts:number) { const bonus=attempts<=8?3:attempts<=11?2:attempts<=15?1:0;return {stars:5+bonus,bonus}; }
function create(now=Date.now(),seed=(Math.random()*4294967296)>>>0):Run {
  let random=seed>>>0 || 0x9e3779b9;
  const next=()=>{random^=random<<13;random^=random>>>17;random^=random<<5;return (random>>>0)/4294967296;};
  const deck=Array.from({length:12},(_,i)=>i%6);
  for(let i=deck.length-1;i>0;i--){const j=Math.floor(next()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
  return {id:`${now}-${seed>>>0}`,startedAt:now,seed:seed>>>0,deck,matched:[],revealed:[],attempts:0,hideAt:null,active:true};
}
function advance(run:Run,now=Date.now()):Run {
  return run.hideAt!==null && now>=run.hideAt ? {...run,revealed:[],hideAt:null} : run;
}
function flip(run:Run,index:number,now=Date.now()):{run:Run;changed:boolean;match:boolean} {
  const next=advance(run,now);
  if(!next.active || !Number.isInteger(index) || index<0 || index>=12 || next.revealed.length===2 || next.matched.includes(index) || next.revealed.includes(index))return {run:next,changed:false,match:false};
  if(next.revealed.length===0)return {run:{...next,revealed:[index]},changed:true,match:false};
  const first=next.revealed[0],match=next.deck[first]===next.deck[index];
  return {run:{...next,attempts:next.attempts+1,matched:match?[...next.matched,first,index]:next.matched,revealed:match?[]:[first,index],hideAt:match?null:now+hideDelay},changed:true,match};
}
function finish(run:Run,now=Date.now()):Result|null {
  return run.matched.length===12 ? {id:run.id,endedAt:now,attempts:run.attempts,...reward(run.attempts)} : null;
}
function restore(value:unknown):Run|null {
  if(!value || typeof value!=='object')return null;
  const v=value as Record<string,unknown>;
  const indices=(a:unknown):a is number[]=>Array.isArray(a)&&a.every(n=>Number.isInteger(n)&&n>=0&&n<12)&&new Set(a).size===a.length;
  if(typeof v.id!=='string'||!v.id||typeof v.startedAt!=='number'||!Number.isFinite(v.startedAt)||v.startedAt<0||!Number.isInteger(v.seed)||Number(v.seed)<0||Number(v.seed)>4294967295||typeof v.active!=='boolean')return null;
  if(!Array.isArray(v.deck)||v.deck.length!==12||!v.deck.every(n=>Number.isInteger(n)&&n>=0&&n<6)||items.some((_,id)=>(v.deck as number[]).filter(n=>n===id).length!==2))return null;
  const deck=v.deck as number[];
  if(!indices(v.matched)||v.matched.length>=12||v.matched.length%2!==0||items.some((_,id)=>v.matched instanceof Array && v.matched.filter(index=>deck[index]===id).length%2!==0))return null;
  if(!indices(v.revealed)||v.revealed.length>2||v.revealed.some(index=>(v.matched as number[]).includes(index)))return null;
  if(!Number.isSafeInteger(v.attempts)||Number(v.attempts)<v.matched.length/2+(v.revealed.length===2?1:0))return null;
  if(v.revealed.length===2) {
    if(deck[v.revealed[0]]===deck[v.revealed[1]]||typeof v.hideAt!=='number'||!Number.isFinite(v.hideAt)||v.hideAt<0)return null;
  } else if(v.hideAt!==null)return null;
  return {id:v.id,startedAt:v.startedAt,seed:v.seed as number,deck:[...deck],matched:[...v.matched],revealed:[...v.revealed],attempts:v.attempts as number,hideAt:v.hideAt as number|null,active:v.active};
}
function restoreResult(value:unknown):Result|null {
  if(!value||typeof value!=='object')return null;
  const v=value as Record<string,unknown>;
  if(typeof v.id!=='string'||!v.id||typeof v.endedAt!=='number'||!Number.isFinite(v.endedAt)||v.endedAt<0||!Number.isSafeInteger(v.attempts)||Number(v.attempts)<6)return null;
  const earned=reward(Number(v.attempts));
  return v.stars===earned.stars&&v.bonus===earned.bonus ? {id:v.id,endedAt:v.endedAt,attempts:v.attempts as number,...earned} : null;
}
export const mokiMemory = {items,hideDelay,reward,create,advance,flip,finish,restore,restoreResult};
