import {mokiVoices,type MokiVoiceCue} from './mokiVoices';
import {mokiSounds} from './mokiSounds';
import {mokiVariants} from './mokiVariants';
const cues:MokiVoiceCue[]=['fed','clean','awake','exercise','pet'];
describe('Moki voice design and completion cues',()=>{
 it('gives all 13 variants distinct voices and each action its own short phrase',()=>{
  const identities=mokiVariants.ids.map(id=>JSON.stringify(mokiVoices.phrase(id,'pet')));
  expect(new Set(identities).size).toBe(13);
  for(const id of mokiVariants.ids){
   expect(new Set(cues.map(cue=>JSON.stringify(mokiVoices.phrase(id,cue)))).size).toBe(5);
   for(const cue of cues){
    const notes=mokiVoices.phrase(id,cue);
    expect(notes.length).toBeLessThanOrEqual(6);
    expect(Math.max(...notes.map(n=>n.at+n.length))).toBeLessThan(1);
    for(const n of notes){
     expect(n.volume).toBeGreaterThan(0);expect(n.volume).toBeLessThanOrEqual(.23);
     expect(n.length).toBeGreaterThan(.02);expect(n.at).toBeGreaterThanOrEqual(0);
     expect(n.contour.every(hz=>Number.isFinite(hz)&&hz>=40&&hz<=4000)).toBeTrue();
    }
   }
  }
 });
 it('reacts only to requested completed animations, never idle or each exercise loop',()=>{
  expect(mokiVoices.afterAnimation('eating')).toBe('fed');
  expect(mokiVoices.afterAnimation('bathing')).toBe('clean');
  expect(mokiVoices.afterAnimation('waking')).toBe('awake');
  for(const phase of ['idle','sleeping','lying','exercising','hatching','undressing'])expect(mokiVoices.afterAnimation(phase)).toBeNull();
 });
 it('accepts a just-finished session, but not canceled, old or restored workout results',()=>{
  const result={complete:true,endedAt:31000};
  expect(mokiVoices.completedWorkout(1000,result,31200)).toBeTrue();
  expect(mokiVoices.completedWorkout(null,result,31200)).toBeFalse();
  expect(mokiVoices.completedWorkout(1000,{...result,complete:false},31200)).toBeFalse();
  expect(mokiVoices.completedWorkout(1000,result,40000)).toBeFalse();
  expect(mokiVoices.completedWorkout(32000,result,32200)).toBeFalse();
  expect(mokiVoices.completedWorkout(1000,result,30000)).toBeFalse();
 });
});
describe('Moki audio lifecycle',()=>{
 let originalAudio:PropertyDescriptor|undefined,originalHidden:PropertyDescriptor|undefined;
 let hidden:boolean,engine:ReturnType<typeof mokiSounds.create>,ctx:ReturnType<typeof fakeContext>;
 function parameter(){return {value:0,setValueAtTime:jasmine.createSpy('set'),linearRampToValueAtTime:jasmine.createSpy('linear'),exponentialRampToValueAtTime:jasmine.createSpy('exponential')};}
 function connection(){return {connect:jasmine.createSpy('connect'),disconnect:jasmine.createSpy('disconnect')};}
 function source(){return {...connection(),type:'',frequency:parameter(),start:jasmine.createSpy('start'),stop:jasmine.createSpy('stop'),onended:null as (()=>void)|null};}
 function fakeContext(){
  const sources:ReturnType<typeof source>[]=[];
  const gains:ReturnType<typeof connection>[]=[];
  const context={
   state:'running',currentTime:0,sampleRate:44100,destination:{},sources,gains,
   createGain:()=>{const gain={...connection(),gain:parameter()};gains.push(gain);return gain;},
   createBiquadFilter:()=>({...connection(),type:'',frequency:parameter(),Q:parameter()}),
   createOscillator:()=>{const node=source();sources.push(node);return node;},
   resume:jasmine.createSpy('resume').and.callFake(()=>Promise.resolve()),
   close:jasmine.createSpy('close').and.callFake(()=>Promise.resolve())
  };
  return context;
 }
 beforeEach(()=>{
  originalAudio=Object.getOwnPropertyDescriptor(window,'AudioContext');
  originalHidden=Object.getOwnPropertyDescriptor(document,'hidden');
  hidden=false;ctx=fakeContext();
  Object.defineProperty(window,'AudioContext',{configurable:true,value:function(){return ctx;}});
  Object.defineProperty(document,'hidden',{configurable:true,get:()=>hidden});
  engine=mokiSounds.create();
 });
 afterEach(()=>{
  engine.dispose();
  if(originalAudio)Object.defineProperty(window,'AudioContext',originalAudio);else delete (window as unknown as {AudioContext?:unknown}).AudioContext;
  if(originalHidden)Object.defineProperty(document,'hidden',originalHidden);else delete (document as unknown as {hidden?:unknown}).hidden;
 });
 const stoppedNow=(node:ReturnType<typeof source>)=>node.stop.calls.allArgs().some(args=>args.length===0);
 it('does not create or play audio while muted or in the background',()=>{
  engine.setEnabled(false);engine.voice('green','pet');expect(ctx.sources.length).toBe(0);expect(ctx.gains.length).toBe(0);
  engine.setEnabled(true);hidden=true;engine.voice('green','clean');expect(ctx.sources.length).toBe(0);
  hidden=false;engine.voice('green','pet');expect(ctx.sources.length).toBeGreaterThan(0);
 });
 it('limits rapid petting and does not let it interrupt a completion reaction',()=>{
  engine.voice('green','pet');const first=ctx.sources.length;
  for(let i=0;i<100;i++)engine.voice('green','pet');
  expect(ctx.sources.length).toBe(first);
  ctx.currentTime=.7;engine.voice('bit','exercise');const completed=ctx.sources.length;
  ctx.currentTime=.8;engine.voice('bit','pet');expect(ctx.sources.length).toBe(completed);
  ctx.currentTime=1.5;engine.voice('bit','pet');expect(ctx.sources.length).toBeGreaterThan(completed);
  expect(ctx.sources.slice(0,first).every(stoppedNow)).toBeTrue();
 });
 it('finishes the action sound before the character speaks and does not duplicate a callback',()=>{
  engine.play('charge');const action=ctx.sources.slice();
  ctx.currentTime=.1;engine.voice('bit','fed');
  expect(action.every(stoppedNow)).toBeTrue();
  const count=ctx.sources.length;
  engine.voice('bit','fed');expect(ctx.sources.length).toBe(count);
 });
 it('stops all playing voices on mute and releases nodes when a phrase ends',()=>{
  engine.voice('auri','clean');
  const first=ctx.sources[0];first.onended?.();expect(first.disconnect).toHaveBeenCalled();
  engine.setEnabled(false);
  expect(ctx.sources.slice(1).every(stoppedNow)).toBeTrue();
  const count=ctx.sources.length;ctx.currentTime=1;engine.voice('auri','pet');expect(ctx.sources.length).toBe(count);
 });
 it('cancels a pending audio unlock when the app stops, so no delayed cry is played',async()=>{
  ctx.state='suspended';
  let resolve:()=>void=()=>{};
  const resumed=new Promise<void>(done=>{resolve=done;});
  ctx.resume.and.returnValue(resumed);
  engine.voice('cielo','pet');expect(ctx.sources.length).toBe(0);
  engine.stop();ctx.state='running';resolve();await resumed;await Promise.resolve();
  expect(ctx.sources.length).toBe(0);
 });
 it('plays the first gesture after a prompt audio unlock',async()=>{
  ctx.state='suspended';
  let resolve:()=>void=()=>{};
  const resumed=new Promise<void>(done=>{resolve=done;});
  ctx.resume.and.returnValue(resumed);
  engine.voice('cielo','pet');ctx.state='running';resolve();await resumed;await Promise.resolve();
  expect(ctx.sources.length).toBeGreaterThan(0);
 });
 it('silently ignores missing audio support instead of crashing the app',()=>{
  Object.defineProperty(window,'AudioContext',{configurable:true,value:undefined});
  expect(()=>engine.voice('nova','awake')).not.toThrow();
 });
});
