type Run={id:string;startedAt:number;seed:number;caught:number[]};
type Result={id:string;endedAt:number;score:number;stars:number;seconds:number;complete:boolean};
const duration=30000,spawnEvery=900,lifetime=900,maxStars=10;
const count=Math.ceil(duration/spawnEvery);
const reward=(score:number)=>Math.min(maxStars,Math.floor(Math.max(0,score)/3));
function create(now=Date.now(),seed=Math.floor(Math.random()*0x100000000)):Run {
  seed=seed>>>0;
  return {id:`${now}-${seed}`,startedAt:now,seed,caught:[]};
}
function targets(run:Run,now=Date.now()) {
  const elapsed=Math.max(0,now-run.startedAt);
  if(elapsed>=duration)return [];
  const first=Math.max(0,Math.floor((elapsed-lifetime)/spawnEvery)+1),last=Math.min(count-1,Math.floor(elapsed/spawnEvery));
  const active=[];
  for(let id=first;id<=last;id++) {
    if(run.caught.includes(id))continue;
    const column=((run.seed>>>4)+id*3)%4;
    const row=(Math.imul(run.seed^id,2654435761)>>>0)%5;
    active.push({id,x:[15,38,62,85][column],y:[15,32,49,66,83][row]});
  }
  return active;
}
function catchTarget(run:Run,id:number,now=Date.now()):Run {
  if(!Number.isInteger(id)||id<0||id>=count||now<run.startedAt||!targets(run,now).some(target=>target.id===id))return run;
  return {...run,caught:[...run.caught,id]};
}
function finish(run:Run,now=Date.now()):Result {
  return {id:run.id,endedAt:Math.min(now,run.startedAt+duration),score:run.caught.length,stars:reward(run.caught.length),
    seconds:Math.min(30,Math.max(0,Math.floor((now-run.startedAt)/1000))),complete:now>=run.startedAt+duration};
}
function restore(value:unknown):Run|null {
  if(!value || typeof value!=='object')return null;
  const v=value as Run;
  if(typeof v.id!=='string'||v.id.length>80||!Number.isFinite(v.startedAt)||v.startedAt<0||!Number.isInteger(v.seed)||v.seed<0||v.seed>0xffffffff||!Array.isArray(v.caught))return null;
  const caught=Array.from(new Set(v.caught.filter(id=>Number.isInteger(id)&&id>=0&&id<count)));
  return {id:v.id,startedAt:v.startedAt,seed:v.seed,caught};
}
function restoreResult(value:unknown):Result|null {
  if(!value||typeof value!=='object')return null;
  const v=value as Result;
  if(typeof v.id!=='string'||v.id.length>80||!Number.isFinite(v.endedAt)||v.endedAt<0||!Number.isInteger(v.score)||v.score<0||v.score>count||v.stars!==reward(v.score)||!Number.isInteger(v.seconds)||v.seconds<0||v.seconds>30||typeof v.complete!=='boolean')return null;
  return {id:v.id,endedAt:v.endedAt,score:v.score,stars:v.stars,seconds:v.seconds,complete:v.complete};
}
export const mokiMinigame={duration,spawnEvery,lifetime,maxStars,reward,create,targets,catchTarget,finish,restore,restoreResult};
