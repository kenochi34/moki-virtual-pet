import {mokiCanvas} from './mokiCanvas';
function enabled(variant:string){return ['bit','volt','tuerca'].includes(variant);}
function hash(value:number){let n=value|0;n=Math.imul(n^(n>>>16),0x45d9f3b);n=Math.imul(n^(n>>>16),0x45d9f3b);return ((n^(n>>>16))>>>0)/4294967296;}
function accent(variant:string,r:number,g:number,b:number){
 if(variant==='bit')return r>190&&g>90&&g<235&&b<140&&r>g*1.12;
 if(variant==='volt')return r<110&&g>160&&b>150 || r>170&&b>130&&g<130;
 if(variant==='tuerca')return g>130&&g>r*1.35&&g>b*.75&&b>75;
 return false;
}
// Each LED cluster has independently seeded durations and brightness targets: no chase sequence.
function level(seed:number,zone:number,time:number,resting=false,reduced=false){
 if(reduced)return resting?.35:.8;
 const key=(seed|0)^Math.imul(zone+1,73856093),duration=(resting?4300:1600)+hash(key)*2900;
 const offset=hash(key+41)*duration,position=(time+offset)/duration,slot=Math.floor(position),t=position-slot;
 const target=(n:number)=>{const value=hash(key^Math.imul(n+1,19349663));return value<.28?.14:.3+value*.7;};
 const smooth=t*t*(3-2*t),value=target(slot)*(1-smooth)+target(slot+1)*smooth;
 return Math.round((resting?.2+value*.45:.3+value*.8)*16)/16;
}
function draw(ctx:CanvasRenderingContext2D,variant:string,time:number,phase:string,reduced=false,seed=0){
 if(!enabled(variant))return;
 const image=mokiCanvas.readPixels(ctx,0,0,64,64);if(!image)return;
 const d=image.data,mask=new Uint8Array(4096),seen=new Uint8Array(4096);
 for(let p=0;p<4096;p++)if(d[p*4+3]&&accent(variant,d[p*4],d[p*4+1],d[p*4+2]))mask[p]=1;
 for(let p=0;p<4096;p++){
  if(!mask[p]||seen[p])continue;
  const group=[p];seen[p]=1;let sx=0,sy=0;
  for(let i=0;i<group.length;i++){const a=group[i],x=a%64,y=Math.floor(a/64);sx+=x;sy+=y;
   for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const nx=x+dx,ny=y+dy,b=ny*64+nx;if(nx<0||nx>=64||ny<0||ny>=64||!mask[b]||seen[b])continue;seen[b]=1;group.push(b);}
  }
  const zone=Math.round(sx/group.length/4)+Math.round(sy/group.length/4)*19;
  const light=level(seed,zone,time,phase==='sleeping',reduced);
  for(const pixel of group)for(let channel=0;channel<3;channel++){const i=pixel*4+channel;d[i]=light<=1?Math.round(d[i]*light):Math.round(d[i]+(255-d[i])*(light-1));}
 }
 ctx.putImageData(image,0,0);
}
// The capsule moves; the pet stays centered and clear of Play.
function dock(phase:string,step:number,reduced=false){
 let rise=0,cable=0;
 if(phase==='lying'){
  rise=[0,.2,.4,.65,.85,1,1,1,1,1,1,1][step]??1;
  cable=[0,0,0,0,0,0,.35,.7,1,1,1,1][step]??1;
 }
 if(phase==='sleeping'){rise=1;cable=1;}
 if(phase==='waking'){
  rise=[1,1,1,1,1,.85,.65,.4,.2,0,0,0][step]??0;
  cable=[1,.7,.35,0,0,0,0,0,0,0,0,0][step]??0;
 }
 if(phase==='eating'){
  rise=[0,.35,.7,1,1,1,1,1,1,.7,.35,0][step]??0;
  cable=[0,0,0,0,.5,1,1,.5,0,0,0,0][step]??0;
 }
 if(reduced){rise=['lying','sleeping','eating'].includes(phase)?1:0;cable=rise;}
 const state=phase==='sleeping'?'standby':rise===0?'off':phase==='waking'?(cable>0?'disconnecting':'lowering'):phase==='eating'&&step>=7?(cable>0?'disconnecting':'lowering'):rise<1?'rising':cable===1?'charging':'connecting';
 return {travel:0,left:50,rise,cable,state};
}
export const mokiRobotMotion={enabled,accent,level,draw,dock};