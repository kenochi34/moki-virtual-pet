import {useEffect,useRef,useState} from 'react';
import {toast} from 'sonner';
import {mokiNotificationStatus} from './mokiNotificationStatus';
import {enablePush,disablePush,onPushEnabledChange,listenToPush} from './pushClient';
import {mokiNotificationClient as client} from './mokiNotificationClient';
import {mokiPet} from './mokiPet';
export function useMokiNotifications(pet:ReturnType<typeof mokiPet.create>,language:'es'|'en'){
 const [enabled,setEnabled]=useState(false),[busy,setBusy]=useState(false),[notice,setNotice]=useState('');
 const [preferences,setPreferences]=useState(client.preferences);
 const [deviceStatus,setDeviceStatus]=useState<Awaited<ReturnType<typeof mokiNotificationStatus.inspect>>|null>(null);
 const active=useRef(false),pending=useRef(false);
 client.configure(pet,language);
 const fail=(error:unknown)=>setNotice(error instanceof Error?error.message:'sync_failed');
 useEffect(()=>{
  const off=onPushEnabledChange(value=>{active.current=value;setEnabled(value);});
  const stop=listenToPush();
  const sync=(keepalive=false)=>{if(active.current)void client.sync(keepalive).catch(fail);};
  const visibility=()=>sync(document.visibilityState!=='visible');
  const focus=()=>sync();
  const timer=setInterval(()=>{if(document.visibilityState==='visible')sync();},60000);
  const arrival=(event:Event)=>{
   const payload=(event as CustomEvent<{title:string;body:string}>).detail;
   if(!payload?.title)return;
   setNotice(`${payload.title}: ${payload.body??''}`);
   toast(payload.title,{description:payload.body,duration:8000,position:'top-center',style:{background:'var(--pixel-panel)',color:'var(--foreground)',border:'2px solid var(--pixel-edge)',borderRadius:0,fontFamily:'inherit'}});
  };
  document.addEventListener('visibilitychange',visibility);
  window.addEventListener('focus',focus);
  window.addEventListener('moki:notification-open',focus);
  window.addEventListener('moki:notification',arrival);
  type Messaging={createChannel?:(channel:{id:string;name:string;importance:number;visibility:number})=>Promise<unknown>};
  const native=(globalThis as unknown as {Capacitor?:{Plugins?:{FirebaseMessaging?:Messaging}}}).Capacitor?.Plugins?.FirebaseMessaging;
  void native?.createChannel?.({id:'fcm_fallback_notification_channel',name:language==='es'?'Recordatorios de Moki':'Moki reminders',importance:5,visibility:1}).catch(()=>{});
  return()=>{off();stop();clearInterval(timer);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('focus',focus);window.removeEventListener('moki:notification-open',focus);window.removeEventListener('moki:notification',arrival);};
 },[]);
 // Care actions sync promptly. The engine's ten-second clock is not a network timer.
 const care=pet.sleeping?0:pet.care;
 useEffect(()=>{if(!active.current)return;const timer=setTimeout(()=>void client.sync().catch(fail),400);return()=>clearTimeout(timer);},[pet.variant,pet.bornAt,pet.stage,pet.sleeping,pet.life.diedAt,care,language]);
 async function run(action:()=>Promise<void>){if(pending.current)return;pending.current=true;setBusy(true);setNotice('');try{await action();}catch(error){fail(error);}finally{pending.current=false;setBusy(false);}}
 return {enabled,busy,notice,preferences,deviceStatus,
  check:()=>run(async()=>{setDeviceStatus(await mokiNotificationStatus.inspect());}),
  enable:()=>run(async()=>{await enablePush();if(!active.current)setNotice('permission_help');}),
  disable:()=>run(async()=>{await disablePush();}),
  change:(key:keyof typeof preferences,value:boolean)=>run(async()=>{const next={...preferences,[key]:value};await client.setPreferences(next);setPreferences(next);}),
  test:()=>run(async()=>{await client.test();setNotice('test_accepted');}),
  testBackground:()=>run(async()=>{setNotice('test_background_preparing');const result=await client.test(10);setNotice(result.testScheduled?'test_background_wait':'test_accepted');})
 };
}