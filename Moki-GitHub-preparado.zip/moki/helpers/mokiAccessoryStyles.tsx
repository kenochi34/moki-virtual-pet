type Rect=[number,number,number,number,string];
type Eyes=[number,number,number,number,number,number,number,number];
type Fit={eyes:Eyes;headX:number;seat:number;hatWidth:number;hatHeight:number;tilt:number;crown:number;neckX:number;neckY:number;neckWidth:number;solid:(x:number,y:number)=>boolean;original:(x:number,y:number)=>Rect|null};
const ink='#092b3c';
const palette:Record<string,string>={D:ink,B:'#397bad',C:'#79c8f1',H:'#d0f6ff',P:'#ec5a9c',L:'#ffb4db',S:'#aa3978',Y:'#ffcf59',W:'#fff1b4',O:'#cd843d',G:'#61bd80',V:'#a489e4',T:'#674697',N:'#80f1e9'};
const hats:Record<string,string[]>={
 leafClip:['....DDD.....','...DGGGD....','..DGHGGD....','..DGGGD.....','...DDD.DDD..','....D.DGGGD.','....DDGHGGD.','....D.DGGD..','....D..DD...'],
 witchHat:['..........DDDD.........','.........DVVVD.........','........DVVD...........','........DVTD...........','.......DVVVTD..........','......DVVVVTTD.........','.....DVVVVVTTTD........','....DVVVVVVTTTTD.......','...DVVVVVVVTTTTTD......','..DOOOOOOYYYYOOOOD.....','..DOOOOODYDDYOOOOOD....','.DOOOOOODYYYYOOOOOOD...','DDVVVVVVVVVVVVVVVVVDDD.','DVVVVVVVVVVVVVVVVVVVVD.','.DDDDDDDDDDDDDDDDDDDD..'],
 beanie:['.......DDDD.......','......DHHHHD......','......DHCCCD......','.......DDDD.......','.....DDCCCCDD.....','...DDCCCCCCCBDD...','..DCCCCCCCCCCBBD..','.DCCCBCCCBCCCBBBD.','.DCCCBCCCBCCCBBBD.','DHHHHHHHHHHHHHHHHD','DCCCCCCCCCCCCCCBBD','.DDDDDDDDDDDDDDDD.'],
 bow:['DDDD.........DDDD','DLPPDD.....DDPPLD','DLPPPPDD.DDPPPPLD','DPPPPPPSDSPPPPPPD','.DPPPPPSDSPPPPPD.','..DDPPSDDDSPPDD..','....DD.....DD....','.....PSD.DSP.....','.....PSD.DSP.....'],
 flower:['.....YYY.....','....YWWWY....','.YYYWWWWWYYY.','YWWWWOOOWWWWY','YWWWOYYYOWWWY','.YWOYWYWOWY.','YWWWOYYYOWWWY','YWWWWOOOWWWWY','.YYYWWWWWYYY.','....YWWWY....','.....YYY.GGG.','......D.GGG..'],
 crown:['D.......D.......D','DYD....DYD....DYD','DYWD..DYWYD..DYWD','DYYWDDYYWYYDDWYYD','DYYYWYYYPYYYWYYYD','DYYYWPYPPPYPWYYYD','.DYYYYYYPYYYYYYD.','.DWWWWWWWWWWWWWD.','..DOOOOOOOOOOOD..','...DDDDDDDDDDD...']
};
function stamp(rows:string[],left:number,top:number,width:number,height:number,tilt=0,center=left+width/2):Rect[]{
 const out:Rect[]=[],sourceWidth=Math.max(...rows.map(row=>row.length));
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const key=rows[Math.min(rows.length-1,Math.floor(y*rows.length/height))][Math.min(sourceWidth-1,Math.floor(x*sourceWidth/width))],color=palette[key];
  if(color)out.push([left+x,top+y+Math.round((left+x-center)*tilt),1,1,color]);
 }
 return out;
}
function head(id:string,s:Fit):Rect[]{
 const out:Rect[]=[];
 if(id==='celestialCirclet'){
  const cx=Math.round(s.headX),cy=s.seat-1;for(let dx=-7;dx<=7;dx++){const y=cy+Math.round(dx*s.tilt)+Math.round(Math.abs(dx)/5);out.push([cx+dx,y,1,1,'#caa255']);if(Math.abs(dx)%3===1)out.push([cx+dx,y-1,2,1,'#fff0b2']);}
  out.push([cx,cy-3,1,5,'#f2ca69'],[cx-1,cy-2,3,3,'#ffe4a0'],[cx,cy-1,1,1,'#78ddcc']);return out;
 }
 if(id==='headphones'){
  const [x,y,w,h,rx,ry,rw,rh]=s.eyes,left=x-4,right=rx+rw+3,cy=(y+h/2+ry+rh/2)/2,top=s.seat-8;
  const put=(px:number,py:number,color:string)=>out.push([Math.round(px),Math.round(py+(px-s.headX)*s.tilt),1,1,color]);
  for(let px=left+1;px<=right-1;px++){const arc=Math.round(5*(Math.abs(px-(left+right)/2)/((right-left)/2))**2);put(px,top+arc,ink);put(px,top+arc+1,'#c1a8f5');put(px,top+arc+2,'#654798');}
  for(const side of [left,right]){for(let py=top+6;py<cy;py++){put(side,py,ink);put(side+(side===left?1:-1),py,'#a287d9');}}
  for(const [px,py] of [[left-1,y+Math.round(h/2)-2],[right-2,ry+Math.round(rh/2)-2]])for(let dy=0;dy<6;dy++)for(let dx=0;dx<4;dx++)out.push([Math.round(px+dx),Math.round(py+dy),1,1,dx===0||dx===3||dy===0||dy===5?ink:dx===1?'#d6baff':'#865ac6']);
  return out;
 }
 const rows=hats[id];if(!rows)return out;
 const side=id==='bow'||id==='flower'||id==='leafClip';
 const width=side?Math.max(8,Math.min(12,Math.round(s.hatWidth*.52))):s.hatWidth;
 const height=id==='witchHat'?Math.max(7,Math.min(16,s.seat-2)):side?(id==='flower'?width:Math.round(width*.64)):s.hatHeight+(id==='beanie'?3:2);
 const cx=side?s.headX+s.hatWidth*.27:s.headX,left=Math.round(cx-width/2),top=s.seat-height+(side?1:0);
 out.push(...stamp(rows,left,top,width,height,s.tilt,s.headX));
 if(!side)for(let y=0;y<s.crown-3;y++)for(let x=left;x<left+width;x++){const pixel=s.original(x,y);if(pixel)out.push(pixel);}
 return out;
}
function eyes(id:string,s:Fit):Rect[]{
 const [x,y,w,h,rx,ry,rw,rh]=s.eyes,c1=x+w/2,c2=rx+rw/2,cy1=y+h/2,cy2=ry+rh/2,out:Rect[]=[];
 if(id==='pumpkinGlasses'){
  const width=Math.max(7,Math.min(11,Math.floor(c2-c1)-1,Math.max(w,rw)+4)),height=Math.max(7,Math.min(9,Math.max(h,rh)+2));
  for(const [cx,cy]of [[c1,cy1],[c2,cy2]]){
   const left=Math.round(cx-width/2),top=Math.round(cy-height/2);
   const put=(dx:number,dy:number,color:string)=>out.push([left+dx,top+dy+Math.round((dx-(width-1)/2)*s.tilt*.3),1,1,color]);
   for(let dy=0;dy<height;dy++)for(let dx=0;dx<width;dx++){
    const edge=dy===0||dy===height-1?2:dy===1||dy===height-2?1:0;
    if(dx<edge||dx>=width-edge)continue;
    if(dy===0||dy===height-1||dx===edge||dx===width-edge-1)put(dx,dy,dy<3?'#ffd06e':dx<width/2?'#ff9d43':'#d76734');
    else if((dx===1||dx===width-2)&&dy>2&&dy<height-2)put(dx,dy,'#ffa84f');
   }
   const stem=Math.floor(width/2);put(stem,-2,'#77cf88');put(stem,-1,'#4d926b');put(stem+1,-2,'#b1e4a0');
  }
  for(let px=Math.round(c1+width/2)-1;px<=c2-width/2+1;px++)out.push([px,Math.round(cy1+(cy2-cy1)*(px-c1)/(c2-c1)),1,1,'#aa7046']);
  out.push([Math.round(c1-width/2)-1,Math.round(cy1),2,1,'#d76734'],[Math.round(c2+width/2)-1,Math.round(cy2),2,1,'#d76734']);return out;
 }
 if(id==='prismGlasses'){
  for(const [cx,cy]of [[c1,cy1],[c2,cy2]]){for(const [dx,dy]of [[0,-4],[-1,-3],[1,-3],[-2,-2],[2,-2],[-3,-1],[3,-1],[-3,0],[3,0],[-2,1],[2,1],[-1,2],[1,2],[0,3]])out.push([Math.round(cx+dx),Math.round(cy+dy+dx*s.tilt*.3),1,1,dy<0?'#f4e8ff':'#a9dfdd']);}
  for(let px=Math.round(c1+3);px<c2-2;px++)out.push([px,Math.round(cy1+(cy2-cy1)*(px-c1)/(c2-c1)),1,1,'#e6c76f']);return out;
 }
 if(id==='visor'){
  const left=Math.round(x-2),right=Math.round(rx+rw+2),height=Math.max(6,Math.min(9,Math.max(h,rh)+2));
  for(let px=left;px<=right;px++){
   const mid=cy1+(cy2-cy1)*(px-c1)/Math.max(1,c2-c1),top=Math.round(mid-height/2);
   for(let dy=0;dy<height;dy++){
    if((px===left||px===right)&&(dy===0||dy===height-1))continue;
    const color=dy===0?'#c4ffff':dy===height-1?'#249dbb':px===left||px===right?'#65f4ee':'#65eaf029';
    out.push([px,top+dy,1,1,color]);
   }
   if((px-left)%6===1)out.push([px,top+1,1,1,'#a6fff28c']);
  }
  out.push([left-2,Math.round(cy1)-1,2,2,'#237c9f'],[right+1,Math.round(cy2)-1,2,2,'#237c9f']);
 }else if(id==='starGlasses'){
  const size=c2-c1<10?7:9,mid=(size-1)/2;
  for(const [cx,cy] of [[c1,cy1],[c2,cy2]]){
   const left=Math.round(cx-size/2),top=Math.round(cy-size/2);
   const points=size===7?[[3,0],[2,1],[4,1],[0,2],[1,2],[5,2],[6,2],[1,3],[5,3],[2,4],[4,4],[1,5],[3,5],[5,5],[1,6],[5,6]]:[[4,0],[3,1],[5,1],[3,2],[5,2],[0,3],[1,3],[2,3],[6,3],[7,3],[8,3],[1,4],[7,4],[2,5],[6,5],[2,6],[4,6],[6,6],[1,7],[3,7],[5,7],[7,7],[1,8],[7,8]];
   for(const [dx,dy]of points)out.push([left+dx,top+dy+Math.round((dx-mid)*s.tilt*.4),1,1,dy<3?'#ffd6ed':'#ef70ba']);
  }
  for(let px=Math.round(c1+size/2)-1;px<=c2-size/2+1;px++)out.push([px,Math.round(cy1+(cy2-cy1)*(px-c1)/(c2-c1)),1,1,'#b74391']);
 }
 return out;
}
function neck(id:string,s:Fit,phase:string):Rect[]{
 const out:Rect[]=[],cx=Math.round(s.neckX),cy=Math.round(s.neckY),width=Math.round(s.neckWidth),left=Math.round(cx-width/2),right=left+width-1;
 const put=(x:number,y:number,color:string)=>{x=Math.round(x);y=Math.round(y);if(s.solid(x,y))out.push([x,y,1,1,color]);};
 if(id==='streamScarf'){
  for(let x=left;x<=right;x++){const y=cy-Math.round(2*((x-cx)/(width/2))**2)+Math.round((x-cx)*s.tilt*.4);put(x,y,'#c7f5ef');put(x,y+1,'#65baca');put(x,y+2,'#347d98');}
  if(phase!=='eating')for(let dy=2;dy<7;dy++)for(let dx=-2;dx<=2;dx++){if(Math.abs(dx)>Math.floor((7-dy)/2))continue;put(cx+dx,cy+dy,dy%3===0?'#d5fff4':'#69ced9');}
  return out;
 }
 if(id==='batScarf'){
  for(let x=left;x<=right;x++){const bend=Math.round(2*((x-cx)/(width/2))**2),y=cy-bend+Math.round((x-cx)*s.tilt*.4);put(x,y,'#ceaaef');put(x,y+1,'#9168bd');put(x,y+2,'#63477f');}
  if(phase!=='eating'){
   const bat=['D...D.D...D','DD.DDDDD.DD','DLDDDDDDDLD','.DDDDDDDDD.','..D.DDD.D..','.....D.....'];
   const span=Math.max(7,Math.min(11,width)),top=cy+1;
   for(let y=0;y<bat.length;y++)for(let x=0;x<span;x++){const key=bat[y][Math.min(10,Math.floor(x*11/span))];if(key!=='.')put(cx-Math.floor(span/2)+x,top+y,key==='L'?'#b99ee8':'#322943');}
   put(cx-1,top+2,'#ffc976');put(cx+1,top+2,'#ffc976');
  }
  const knotX=right,ky=cy-1+Math.round((right-cx)*s.tilt*.4);put(knotX,ky,'#ddbaf5');put(knotX,ky+1,'#9168bd');put(knotX-1,ky+3,'#b394df');return out;
 }
 if(id==='auroraRibbon'){
  for(let dx=-Math.min(6,width/2);dx<=Math.min(6,width/2);dx++){const x=cx+Math.round(dx),y=cy-Math.round(Math.abs(dx)/3)+Math.round(dx*s.tilt*.4);put(x,y,'#d6bcf3');put(x,y+1,'#a1e6d3');}
  if(phase!=='eating')for(let dy=0;dy<5;dy++)for(let dx=-3;dx<=3;dx++){if(Math.abs(dx)>1&&dy>2)continue;put(cx+dx,cy+1+dy,dx<0?'#b5a0e7':'#9ae8d9');}
  put(cx,cy+2,'#ffe4a0');return out;
 }
 if(id==='scarf'){
  for(let x=left;x<=right;x++){const bend=Math.round(2*((x-cx)/(width/2))**2),y=cy-bend+Math.round((x-cx)*s.tilt*.4);for(let dy=0;dy<4;dy++)put(x,y+dy,dy===0?'#c7ffe5':dy===3?'#328f8d':x%5===0?'#69c7b5':'#88e0c2');}
  if(phase!=='eating')for(let dy=3;dy<8;dy++)for(let dx=0;dx<3;dx++)put(right-2+dx,cy+dy,dy===6?'#dcffce':dx===2?'#328f8d':'#88e0c2');
 }else if(id==='medal'){
  const span=Math.max(3,Math.min(6,width/2));
  for(let i=0;i<=span;i++)for(const sign of [-1,1]){put(cx+sign*(span-i),cy-1+i*.6,'#4469ac');put(cx+sign*(span-i),cy+i*.6,'#85b8ee');}
  const top=cy+Math.round(span*.6);
  if(phase!=='eating')for(let dy=0;dy<5;dy++)for(let dx=0;dx<5;dx++){if((dx===0||dx===4)&&(dy===0||dy===4))continue;put(cx+dx-2,top+dy,dx===0||dx===4||dy===4?'#bf8439':dy===0?'#fff1b4':'#f2c55e');}
  if(phase!=='eating')put(cx,top+2,'#fff4cf');
 }
 return out;
}
function icon(id:string):Rect[]{
 const s:Fit={eyes:[7,9,4,5,19,9,4,5],headX:15,seat:8,hatWidth:22,hatHeight:9,tilt:0,crown:0,neckX:15,neckY:7,neckWidth:19,solid:()=>true,original:()=>null};
 if(id==='witchHat'){s.seat=16;s.hatHeight=14;}
 const raw=[...head(id,s),...eyes(id,s),...neck(id,s,'idle')];if(!raw.length)return [];
 const x0=Math.min(...raw.map(r=>r[0])),x1=Math.max(...raw.map(r=>r[0]+r[2])),y0=Math.min(...raw.map(r=>r[1])),y1=Math.max(...raw.map(r=>r[1]+r[3]));
 const scale=Math.min(1,26/(x1-x0),16/(y1-y0)),ox=Math.round((30-(x1-x0)*scale)/2),oy=Math.round((20-(y1-y0)*scale)/2);
 return raw.map(([x,y,w,h,c])=>[ox+Math.round((x-x0)*scale),oy+Math.round((y-y0)*scale),Math.max(1,Math.round(w*scale)),Math.max(1,Math.round(h*scale)),c]);
}
export const mokiAccessoryStyles={head,eyes,neck,icon};