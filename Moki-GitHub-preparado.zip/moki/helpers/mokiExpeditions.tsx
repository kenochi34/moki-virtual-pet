export type RouteId='garden'|'stream';
export type Expedition={id:string;route:RouteId;startedAt:number;endsAt:number;bornAt:number;variant:string;seed:number};
export type ExpeditionResult={id:string;route:RouteId;endedAt:number;complete:boolean;coins:number;accessory:'leafClip'|'streamScarf'|null};
type Progress={garden:number;stream:number};
const routes={
 garden:{minutes:15,min:1,max:2,accessory:'leafClip' as const,name:{es:'Jardín cercano',en:'Nearby garden'},description:{es:'Un paseo entre flores y hojas.',en:'A stroll among flowers and leaves.'}},
 stream:{minutes:60,min:3,max:5,accessory:'streamScarf' as const,name:{es:'Sendero del arroyo',en:'Stream trail'},description:{es:'Cruza el puente y sigue el sonido del agua.',en:'Cross the bridge and follow the water.'}}
};
const isRoute=(v:unknown):v is RouteId=>v==='garden'||v==='stream';
const finite=(n:unknown):n is number=>typeof n==='number'&&Number.isFinite(n)&&n>=0;
function progress(raw?:Partial<Progress>|null):Progress{
 const count=(n:unknown)=>Number.isSafeInteger(n)&&Number(n)>=0?Math.min(1000000,Number(n)):0;
 return {garden:count(raw?.garden),stream:count(raw?.stream)};
}
type Subject={stage:string;bornAt:number;variant:string;sleeping:boolean;hunger:number;fatigue:number;dirt:number;mood:number;life:{diedAt:number|null};expedition:Expedition|null;expeditionReward:ExpeditionResult|null;workout:unknown;minigame:unknown;memory:{active:boolean}|null};
function readiness(p:Subject,route:RouteId){
 const hours=routes[route].minutes/60;
 const needs={hunger:p.hunger<=60&&p.hunger+hours*12<=80,fatigue:p.fatigue<=60&&p.fatigue+hours*10<=80,dirt:p.dirt<=60&&p.dirt+hours*9<=80};
 const reason=p.life.diedAt!==null?'dead':p.stage==='egg'?'egg':p.expedition?'away':p.expeditionReward?'reward':p.sleeping?'sleeping':p.workout||p.minigame||p.memory?.active?'busy':p.stage==='baby'&&route==='stream'?'teen':!Object.values(needs).every(Boolean)||p.mood<40?'care':null;
 return {ready:reason===null,reason,needs};
}
function create(p:Subject,route:RouteId,now:number,roll=Math.random()):Expedition{
 const seed=Math.max(0,Math.min(0xffffffff,Math.floor(roll*0x100000000)));
 return {id:route+':'+now+':'+seed,route,startedAt:now,endsAt:now+routes[route].minutes*60000,bornAt:p.bornAt,variant:p.variant,seed};
}
function restore(raw:unknown,p:{bornAt:number;variant:string;stage:string;sleeping:boolean}):Expedition|null{
 const x=raw as Expedition|undefined;
 if(!x||!isRoute(x.route)||typeof x.id!=='string'||x.id.length>120||!finite(x.startedAt)||!finite(x.endsAt)||x.startedAt<p.bornAt||x.endsAt!==x.startedAt+routes[x.route].minutes*60000||x.bornAt!==p.bornAt||x.variant!==p.variant||p.stage==='egg'||p.sleeping||!Number.isInteger(x.seed)||x.seed<0||x.seed>0xffffffff)return null;
 return {id:x.id,route:x.route,startedAt:x.startedAt,endsAt:x.endsAt,bornAt:x.bornAt,variant:x.variant,seed:x.seed};
}
function restoreResult(raw:unknown):ExpeditionResult|null{
 const r=raw as ExpeditionResult|undefined;
 if(!r||!isRoute(r.route)||typeof r.id!=='string'||r.id.length>120||!finite(r.endedAt)||typeof r.complete!=='boolean'||!Number.isInteger(r.coins)||r.coins<0||r.coins>routes[r.route].max||!(r.accessory===null||r.complete&&r.accessory===routes[r.route].accessory))return null;
 return {id:r.id,route:r.route,endedAt:r.endedAt,complete:r.complete,coins:r.coins,accessory:r.accessory};
}
function finish(run:Expedition,at:number,completed:Progress,owned:readonly string[]):ExpeditionResult{
 const route=routes[run.route],complete=at>=run.endsAt;
 let seed=run.seed>>>0;seed=(Math.imul(seed,1664525)+1013904223)>>>0;
 const full=route.min+seed%(route.max-route.min+1);
 seed=(Math.imul(seed,1664525)+1013904223)>>>0;
 const accessory=complete&&!owned.includes(route.accessory)&&(completed[run.route]>=4||seed/0x100000000<.25)?route.accessory:null;
 const fraction=Math.max(0,Math.min(1,(at-run.startedAt)/(run.endsAt-run.startedAt)));
 return {id:run.id,route:run.route,endedAt:Math.max(run.startedAt,Math.min(at,run.endsAt)),complete,coins:complete?full:Math.floor(full*fraction),accessory};
}
function remaining(run:Expedition,now:number){return Math.max(0,Math.ceil((run.endsAt-now)/1000));}
export const mokiExpeditions={routes,isRoute,progress,readiness,create,restore,restoreResult,finish,remaining};
