import {postMokiPush,type InputType} from '../endpoints/moki/push_POST.schema';
import {mokiReminderPolicy as policy} from './mokiReminderPolicy';
import {mokiPet} from './mokiPet';
type Pet=ReturnType<typeof mokiPet.create>;
type Preferences=NonNullable<InputType['preferences']>;
const DEVICE='moki.push.device.v1',PREFS='moki.push.preferences.v1';
let current:{pet:Pet;language:'es'|'en'}|null=null;
let queue:Promise<unknown>=Promise.resolve();
function ordered<T>(run:()=>Promise<T>):Promise<T>{const next=queue.catch(()=>{}).then(run);queue=next;return next;}
function deviceKey(){let key=localStorage.getItem(DEVICE);if(!key||!/^[a-f0-9]{64}$/.test(key)){key=Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');localStorage.setItem(DEVICE,key);}return key;}
function preferences():Preferences{try{const result=policy.preferences.safeParse(JSON.parse(localStorage.getItem(PREFS)??'null'));if(result.success)return result.data;}catch{}return {...policy.defaults};}
function context(){
 const pet=mokiPet.advance(current?.pet??mokiPet.restore(localStorage.getItem(mokiPet.key)));
 const choice=localStorage.getItem('moki.language.v1');
 const language=current?.language??(choice==='en'||choice==='es'?choice:navigator.language.startsWith('es')?'es':'en');
 const zone=Intl.DateTimeFormat().resolvedOptions().timeZone;
 return {deviceKey:deviceKey(),snapshot:policy.snapshot.parse(pet),preferences:preferences(),language,timezone:policy.validZone(zone)?zone:'UTC'};
}
export const mokiNotificationClient={
 configure(pet:Pet,language:'es'|'en'){current={pet,language};},preferences,
 save(subscription:unknown){return ordered(()=>postMokiPush({...context(),action:'subscribe',subscription:subscription as InputType['subscription']}));},
 sync(keepalive=false){return ordered(()=>postMokiPush({...context(),action:'sync'},{keepalive}));},
 remove(){return ordered(()=>postMokiPush({action:'remove',deviceKey:deviceKey()}));},
 test(delaySeconds:0|10=0){return ordered(()=>postMokiPush({action:'test',deviceKey:deviceKey(),delaySeconds},{keepalive:true}));},
 setPreferences(value:Preferences){return ordered(async()=>{const before=preferences();localStorage.setItem(PREFS,JSON.stringify(value));try{await postMokiPush({...context(),action:'sync'});}catch(error){localStorage.setItem(PREFS,JSON.stringify(before));throw error;}});}
};