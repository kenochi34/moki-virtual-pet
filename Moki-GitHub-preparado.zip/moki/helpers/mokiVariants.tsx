const ids=['green','lila','amber','cielo','coral','noche','orbita','nova','nebula','bit','volt','tuerca','auri'] as const;
type Id=typeof ids[number];
const families=['moki','bird','alien','robot','divine'] as const;
type Family=typeof families[number];
const familyNames={moki:{es:'Moki',en:'Moki'},bird:{es:'Aves',en:'Birds'},alien:{es:'Aliens',en:'Aliens'},robot:{es:'Robots',en:'Robots'},divine:{es:'Divino',en:'Divine'}};
const catalog={
 auri:{family:'divine',name:{es:'Auri',en:'Auri'},color:'#edc46c',ink:'#24233d',cream:'#fff2d7',trait:{es:'Guardián de luz, dulce y alado',en:'A gentle, winged guardian of light'}},
 green:{family:'moki',name:{es:'Moki Verde',en:'Green Moki'},color:'#47b5a0',ink:'#092b3c',cream:'#fff1ce',trait:{es:'Curioso y cariñoso',en:'Curious and affectionate'}},
 lila:{family:'moki',name:{es:'Moki Lila',en:'Lilac Moki'},color:'#aa82d7',ink:'#32152f',cream:'#fff1ce',trait:{es:'Tranquilo y soñador',en:'Gentle and dreamy'}},
 amber:{family:'moki',name:{es:'Moki Ámbar',en:'Amber Moki'},color:'#f69f29',ink:'#3a1d14',cream:'#fff1ce',trait:{es:'Inquieto y juguetón',en:'Lively and playful'}},
 cielo:{family:'bird',name:{es:'Ave Cielo',en:'Sky Bird'},color:'#05c7ff',ink:'#141029',cream:'#d8f2ff',trait:{es:'Curiosa y saltarina',en:'Curious and bouncy'}},
 coral:{family:'bird',name:{es:'Ave Coral',en:'Coral Bird'},color:'#ff5064',ink:'#290c27',cream:'#ffd1a1',trait:{es:'Alegre y enérgica',en:'Cheerful and energetic'}},
 noche:{family:'bird',name:{es:'Ave Noche',en:'Night Bird'},color:'#bcf52b',ink:'#140923',cream:'#b283ee',trait:{es:'Serena y observadora',en:'Calm and observant'}},
 orbita:{family:'alien',name:{es:'Órbita',en:'Orbita'},color:'#00e5ff',ink:'#061039',cream:'#319aff',trait:{es:'Curioso, con pulsos de luz azul',en:'Curious, with blue light pulses'}},
 nova:{family:'alien',name:{es:'Nova',en:'Nova'},color:'#ff28bc',ink:'#34112c',cream:'#ffab32',trait:{es:'Ágil, con destellos rosados',en:'Agile, with pink glimmers'}},
 nebula:{family:'alien',name:{es:'Nebula',en:'Nebula'},color:'#ac48ef',ink:'#102c18',cream:'#94ee28',trait:{es:'Flota y ondula sus tentáculos',en:'Floats and ripples its tentacles'}},
 bit:{family:'robot',name:{es:'Bit',en:'Bit'},color:'#ffbe34',ink:'#142839',cream:'#fff0cf',trait:{es:'Curioso y mecánico, con luces ámbar',en:'Curious and mechanical, with amber lights'}},
 volt:{family:'robot',name:{es:'Volt',en:'Volt'},color:'#24ddf0',ink:'#171b2b',cream:'#8a9aa5',trait:{es:'Ágil y eléctrico, con luces cian',en:'Agile and electric, with cyan lights'}},
 tuerca:{family:'robot',name:{es:'Tuerca',en:'Tuerca'},color:'#77e8ba',ink:'#3d241e',cream:'#ffedbd',trait:{es:'Amigable y curioso, con piezas de cobre',en:'Friendly and curious, with copper parts'}}
} as const;
function valid(value:unknown):value is Id {return typeof value==='string'&&(ids as readonly string[]).includes(value);}
function restore(value:unknown):Id {return valid(value)?value:'green';}
function family(value:unknown):Family {return catalog[restore(value)].family;}
function members(value:Family):Id[] {return ids.filter(id=>catalog[id].family===value);}
function history(value:unknown,current?:unknown):Id[] {
 const found:Id[]=Array.isArray(value)?[...new Set(value.filter(valid))]:[];
 if(current!==undefined){const id=restore(current);if(!found.includes(id))found.push(id);}
 return found;
}
function pick(received:unknown,roll=Math.random(),group:Family='moki'):Id {
 const known=history(received),available=members(group),unseen=available.filter(id=>!known.includes(id));
 const pool=unseen.length?unseen:available;
 const index=Math.floor(Math.max(0,Math.min(.999999999,Number.isFinite(roll)?roll:0))*pool.length);
 return pool[index];
}
export const mokiVariants={ids,families,familyNames,catalog,valid,restore,family,members,history,pick};