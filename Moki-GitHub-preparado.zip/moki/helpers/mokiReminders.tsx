import {db} from './db';
import {mokiReminderPolicy} from './mokiReminderPolicy';
import {mokiPushDelivery} from './mokiPushDelivery';
export async function mokiReminders(){
 const now=new Date();
 // Expire inactive subscriptions; the managed client registers them again on return.
 await db.deleteFrom('mokiPushDevices').where('lastSeenAt','<',new Date(now.getTime()-7*86400000)).execute();
 const candidates=await db.selectFrom('mokiPushDevices').select('deviceHash').where('enabled','=',true).where('nextCheckAt','<=',now).orderBy('nextCheckAt').limit(100).execute();
 let sent=0;
 for(const candidate of candidates){
  try{await db.transaction().execute(async trx=>{
   const row=await trx.selectFrom('mokiPushDevices').selectAll().where('deviceHash','=',candidate.deviceHash).where('enabled','=',true).where('nextCheckAt','<=',new Date()).forUpdate().skipLocked().executeTakeFirst();
   if(!row)return;
   const time=Date.now(),decision=mokiReminderPolicy.decision(row,time);
   if(!decision.reason){await trx.updateTable('mokiPushDevices').set({nextCheckAt:decision.nextCheckAt}).where('deviceHash','=',row.deviceHash).execute();return;}
   // Reserve the quota while locked, before calling the provider: retries cannot double-send.
   const count=row.sentDay===decision.day?row.sentToday:0;
   await trx.updateTable('mokiPushDevices').set({lastSentAt:new Date(time),sentDay:decision.day,sentToday:count+1,nextCheckAt:new Date(time+6*3600000)}).where('deviceHash','=',row.deviceHash).execute();
   try{
    const result=await mokiPushDelivery(row,decision.reason);
    if(result?.gone){await trx.deleteFrom('mokiPushDevices').where('deviceHash','=',row.deviceHash).execute();return;}
    if(result?.success)sent++;
    else console.warn('Moki reminder was not accepted',result?.statusCode??0);
   }catch{console.warn('Moki reminder delivery failed; reserved quota retained to prevent duplicate alerts');}
  });}catch(error){console.error('Moki reminder transaction failed',error instanceof Error?error.name:'unknown');}
 }
 console.info('Moki reminders batch',{checked:candidates.length,sent});
}