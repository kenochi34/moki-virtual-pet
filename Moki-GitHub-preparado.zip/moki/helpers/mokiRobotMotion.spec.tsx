import {mokiRobotMotion} from './mokiRobotMotion';
import {mokiVariantArt} from './mokiVariantArt';
import {mokiExplorationThemes} from './mokiExplorationThemes';
import {mokiPet} from './mokiPet';
describe('Robot floor capsule',()=>{
 it('keeps the robot clear of Play and connects only after the capsule has risen',()=>{
  for(const phase of ['lying','sleeping','waking','eating','idle'])for(let step=0;step<12;step++){
   const dock=mokiRobotMotion.dock(phase,step);
   expect(dock.left-46/2).toBeGreaterThan(4.5+19);
   expect(dock.left).toBe(50);
   if(dock.cable>0)expect(dock.rise).toBe(1);
  }
  expect(mokiRobotMotion.dock('sleeping',0).cable).toBe(1);
  expect(mokiRobotMotion.dock('waking',11).rise).toBe(0);
  expect(mokiRobotMotion.dock('eating',11).rise).toBe(0);
  expect(mokiRobotMotion.dock('idle',0).rise).toBe(0);
 });
 it('runs a single quick charge cycle with matching idle-sheet accessory anchors',()=>{
  for(const variant of ['bit','volt','tuerca'] as const){
   const animation=mokiVariantArt.animation(variant,'eating');
   expect(animation.cycles).toBe(1);expect(animation.sheet).toBe(0);
   expect(animation.frames.length).toBe(animation.times.length);
   expect(mokiRobotMotion.dock('eating',animation.frames.length-1).rise).toBe(0);
   for(const stage of ['baby','teen','adult'] as const)for(const frame of animation.frames){
    expect(mokiVariantArt.eyes(variant,stage,'eating',frame)).toEqual(mokiVariantArt.eyes(variant,stage,'idle',frame));
   }
  }
 });
 it('uses static connected and hidden states with reduced motion',()=>{
  for(const phase of ['lying','eating','sleeping'])for(let step=0;step<12;step++)expect(mokiRobotMotion.dock(phase,step,true).cable).toBe(1);
  expect(mokiRobotMotion.dock('waking',0,true).rise).toBe(0);
 });
});
describe('Family exploration continuity',()=>{
 it('keeps both route ids and an existing saved trip through a theme change',()=>{
  const now=1800000000000;
  for(const variant of ['green','bit','orbita','cielo','auri'] as const){
   const pet={...mokiPet.create(now),variant,stage:'adult' as const,hunger:20,fatigue:20,dirt:20,mood:90,care:100};
   const started=mokiPet.startExpedition(pet,'garden',now,.5);
   const es=mokiExplorationThemes.get(variant,'es'),en=mokiExplorationThemes.get(variant,'en');
   expect(Object.keys(es.routes)).toEqual(['garden','stream']);
   expect(es.src).toBe(en.src);
   expect(started.expedition?.endsAt).toBe(now+15*60000);
   const finished=mokiPet.advance(started,now+15*60000);
   expect(finished.expeditionReward?.route).toBe('garden');
   expect(finished.expeditionReward?.complete).toBeTrue();
   expect(mokiPet.claimExpedition(finished,finished.expeditionReward!.id,now+15*60000).player.expeditions.garden).toBe(1);
  }
 });
});
