import {mokiExpeditions, type RouteId, type Expedition} from './mokiExpeditions';
import {mokiLife} from './mokiLife';
import { mokiDivine } from './mokiDivine';
import { mokiChallenges } from './mokiChallenges';
import { mokiMinigame } from './mokiMinigame';
import { mokiMemory } from './mokiMemory';
import { mokiVariants } from './mokiVariants';
import { mokiWardrobe } from './mokiWardrobe';
type Stage = 'egg' | 'baby' | 'teen' | 'adult';
type Action = 'feed' | 'bathe' | 'sleep' | 'wake' | 'affection' | 'tap' | 'hatch' | 'startWorkout' | 'stopWorkout' | 'workoutTick' | 'gameTick';
type Variant=typeof mokiVariants.ids[number];
type Family=typeof mokiVariants.families[number];
type Player = { adoptions:number; starterChosen:boolean; expeditions:ReturnType<typeof mokiExpeditions.progress>; divineUnlocked:boolean; challenges:ReturnType<typeof mokiChallenges.create>; birdTrial:boolean; raised:Variant[]; variants:Variant[]; closetTestCredit:boolean; stars:number; lastExerciseRewardDay:string; wardrobe:ReturnType<typeof mokiWardrobe.create> };
type Workout = { startedAt:number; appliedMs:number; vitalityGained:number };
type WorkoutResult = { endedAt:number; seconds:number; complete:boolean; stars:number; vitalityGained:number };
type Pet = {
  expedition:ReturnType<typeof mokiExpeditions.create>|null;
  expeditionReward:ReturnType<typeof mokiExpeditions.finish>|null;
  life:ReturnType<typeof mokiLife.create>;
  variant:Variant; version: 3; name: string; eggTaps: number; bornAt: number; updatedAt: number; stage: Stage; sleeping: boolean;
  hunger: number; fatigue: number; dirt: number; mood: number; care: number;
  lastAffection: number; vitality:number; player:Player; workout:Workout|null; lastWorkout:WorkoutResult|null;
  minigame:ReturnType<typeof mokiMinigame.create>|null; lastGame:ReturnType<typeof mokiMinigame.finish>|null;
  memory:ReturnType<typeof mokiMemory.create>|null; lastMemory:ReturnType<typeof mokiMemory.finish>;
};
const HOUR = 3600000;
const WORKOUT_MS = 30000;
const FREE_ADOPTIONS=2,ADOPTION_COST=20;
function adoptionCount(value:unknown){return Number.isSafeInteger(value)&&Number(value)>=0?Math.min(Number(value),1000000):0;}
const localDay=mokiChallenges.localDay;
// A fresh test save, as requested. The previous playthrough remains in its original key.
const KEY = 'moki.virtual-pet.tap-hatch.v1';
const clamp = (value: number) => Math.max(0, Math.min(100, value));

function cleanName(value: unknown) {
  return typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 18) : '';
}

function create(now = Date.now(), player:{adoptions?:number;starterChosen?:boolean;expeditions?:Player['expeditions'];divineUnlocked?:boolean;challenges?:Player['challenges'];stars:number;lastExerciseRewardDay:string;wardrobe?:Player['wardrobe'];closetTestCredit?:boolean;variants?:Variant[];raised?:Variant[];birdTrial?:boolean} = {stars:0,lastExerciseRewardDay:''}, roll=Math.random(),group:Family='moki'): Pet {
  const divineUnlocked=player.divineUnlocked===true||mokiDivine.progress(player.raised).unlocked;
  if(group==='divine'&&!divineUnlocked)group='moki';
  const variant=mokiVariants.pick(player.variants,roll,group);
  const starterChosen=player.starterChosen!==false;
  const variants=mokiVariants.history(player.variants,starterChosen?variant:undefined);
  return { expedition:null, expeditionReward:null, life:mokiLife.create(now), variant, version: 3, name: (group==='alien'||group==='robot'||group==='divine')?mokiVariants.catalog[variant].name.es:group==='bird'?variant[0].toUpperCase()+variant.slice(1):'Moki', eggTaps: 0, bornAt: now, updatedAt: now, stage: 'egg', sleeping: false,
    hunger: 45, fatigue: 35, dirt: 30, mood: 70, care: 0, lastAffection: 0,
    vitality:60, player:{...player,adoptions:adoptionCount(player.adoptions),starterChosen,expeditions:mokiExpeditions.progress(player.expeditions),divineUnlocked,challenges:mokiChallenges.sync(mokiChallenges.restore(player.challenges,now,player.lastExerciseRewardDay),now),variants,birdTrial:player.birdTrial??true,raised:mokiVariants.history(player.raised),closetTestCredit:player.closetTestCredit ?? true,wardrobe:mokiWardrobe.equip(mokiWardrobe.restore(player.wardrobe),null)}, workout:null, lastWorkout:null, minigame:null, lastGame:null, memory:null, lastMemory:null };
}

// Only genuinely new saves enter the starter flow. Legacy saves keep their current pet.
function begin(now=Date.now()):Pet {
  return create(now,{stars:0,lastExerciseRewardDay:'',starterChosen:false,adoptions:0},0,'moki');
}
function chooseStarter(pet:Pet,group:Family,now=Date.now(),roll=Math.random()):Pet {
  if(pet.player.starterChosen||pet.stage!=='egg'||group==='divine'||!mokiVariants.families.includes(group))return pet;
  return create(Math.max(now,pet.updatedAt,pet.bornAt+1),{...pet.player,starterChosen:true},roll,group);
}
function adoptionQuote(pet:Pet){
  const used=adoptionCount(pet.player.adoptions),freeLeft=Math.max(0,FREE_ADOPTIONS-used);
  const cost=pet.life.diedAt!==null||!pet.player.starterChosen||freeLeft>0?0:ADOPTION_COST;
  return {used,freeLeft,cost,affordable:pet.player.stars>=cost};
}

function evolve(pet: Pet, now: number): Pet {
  if (pet.stage === 'egg' || pet.life.diedAt!==null) return pet;
  const age = Math.max(0, (pet.life.diedAt??now) - pet.bornAt) / HOUR;
  let stage = pet.stage;
  if (stage === 'baby' && age >= 24 && pet.care >= 20 && pet.mood >= 50) stage = 'teen';
  if (stage === 'teen' && age >= 72 && pet.care >= 60 && pet.mood >= 50) stage = 'adult';
  const raised=stage==='adult'?mokiVariants.history(pet.player.raised,pet.variant):pet.player.raised;
  return {...pet,stage,player:{...pet.player,raised,divineUnlocked:pet.player.divineUnlocked||mokiDivine.progress(raised).unlocked}};
}

// Exact time above the discomfort threshold; independent of refresh frequency.
function discomfort(start: number, rate: number, hours: number) {
  if (rate > 0) return Math.max(0, hours - Math.max(0, (80 - start) / rate));
  if (rate < 0) return Math.min(hours, Math.max(0, (start - 80) / -rate));
  return start > 80 ? hours : 0;
}

function advance(pet: Pet, now = Date.now()): Pet {
  if(pet.expedition && now>=pet.expedition.endsAt){
    const run=pet.expedition;
    const atEnd=advance({...pet,expedition:null},run.endsAt);
    return advance(settleExpedition(atEnd,run,run.endsAt),now);
  }
  if(pet.life.diedAt!==null)return pet;
  if(pet.workout && now>pet.workout.startedAt+WORKOUT_MS) {
    // Finish at its real deadline before advancing the rest of the offline time.
    return advance(advance(pet,pet.workout.startedAt+WORKOUT_MS),now);
  }
  if(pet.minigame && now>pet.minigame.startedAt+mokiMinigame.duration) {
    return advance(advance(pet,pet.minigame.startedAt+mokiMinigame.duration),now);
  }
  pet={...pet,player:{...pet.player,divineUnlocked:pet.player.divineUnlocked||mokiDivine.progress(pet.player.raised).unlocked,challenges:mokiChallenges.sync(pet.player.challenges,now)}};
  pet.player.wardrobe=mokiWardrobe.unlock(pet.player.wardrobe,pet.player.challenges.openedChests);
  if (pet.stage === 'egg') return { ...pet, updatedAt: Math.max(pet.updatedAt, now) };
  const life=mokiLife.advance(pet,now);
  now=Math.min(now,life.diedAt??now);
  const hours = Math.max(0, now - pet.updatedAt) / HOUR;
  // Robots recover battery energy while connected; hunger stores the energy deficit.
  const hungerRate = pet.sleeping ? (mokiVariants.family(pet.variant)==='robot'?-40:2) : 12;
  const dirtRate = pet.sleeping ? 1.5 : 9;
  const fatigueRate = pet.sleeping ? -120 : 10;
  const fatigue = clamp(pet.fatigue + fatigueRate * hours);
  const recovered = pet.sleeping ? pet.fatigue - fatigue : 0;
  const moodLoss = hours * (pet.sleeping ? .6 : 2)
    + discomfort(pet.hunger, hungerRate, hours) * 2
    + discomfort(pet.dirt, dirtRate, hours)
    + discomfort(pet.fatigue, fatigueRate, hours) * 1.5;
  const next:Pet = { ...pet, life,
    updatedAt: Math.max(pet.updatedAt, now),
    hunger: clamp(pet.hunger + hours * hungerRate), dirt: clamp(pet.dirt + hours * dirtRate),
    fatigue, mood: clamp(pet.mood - moodLoss), care: pet.care + recovered / 10,
    vitality:clamp(pet.vitality - hours * (pet.sleeping ? .5 : 1))
  };
  if(life.diedAt!==null)return {...next,sleeping:false,workout:null,minigame:null,memory:null};
  if(next.workout) {
    const elapsed=Math.min(WORKOUT_MS,Math.max(next.workout.appliedMs,now-next.workout.startedAt));
    const fraction=(elapsed-next.workout.appliedMs)/WORKOUT_MS;
    const gain=Math.min(100-next.vitality,12*fraction);
    next.vitality=clamp(next.vitality+gain);
    next.mood=clamp(next.mood+5*fraction);
    next.hunger=clamp(next.hunger+6*fraction);
    next.fatigue=clamp(next.fatigue+8*fraction);
    next.dirt=clamp(next.dirt+4*fraction);
    next.care+=2*fraction;
    next.workout={...next.workout,appliedMs:elapsed,vitalityGained:next.workout.vitalityGained+gain};
    if(elapsed===WORKOUT_MS) {
      const endedAt=next.workout.startedAt+WORKOUT_MS;
      const day=localDay(endedAt);
      const reward=day>next.player.lastExerciseRewardDay ? 5 : 0;
      next.player={...next.player,stars:next.player.stars+reward,lastExerciseRewardDay:reward ? day : next.player.lastExerciseRewardDay};
      const challenge=mokiChallenges.record(next.player.challenges,'exercise',endedAt);
      next.player={...next.player,challenges:challenge.state};
      next.lastWorkout={endedAt,seconds:30,complete:true,stars:reward,vitalityGained:next.workout.vitalityGained};
      next.workout=null;
    }
  }
  if(next.memory)next.memory=mokiMemory.advance(next.memory,now);
  if(next.minigame && now>=next.minigame.startedAt+mokiMinigame.duration)return settleGame(evolve(next,now),now);
  return evolve(next,now);
}

function act(pet: Pet, action: Action, now = Date.now()): Pet {
  const next = advance(pet, now);
  if(!next.player.starterChosen||next.life.diedAt!==null)return next;
  if (next.stage === 'egg') {
    if (action === 'tap') return { ...next, eggTaps: Math.min(5, next.eggTaps + 1) };
    if (action === 'hatch' && next.eggTaps === 5) return { ...next, stage: 'baby', bornAt: now, updatedAt: now,
      player:{...next.player,wardrobe:mokiWardrobe.equip(next.player.wardrobe,null)} };
    return next;
  }
  if(action==='stopWorkout') {
    if(!next.workout)return next;
    return {...next,lastWorkout:{endedAt:now,seconds:Math.floor(next.workout.appliedMs/1000),complete:false,stars:0,vitalityGained:next.workout.vitalityGained},workout:null};
  }
  if(next.expedition || next.workout || next.minigame || next.memory?.active)return next;
  if(action==='startWorkout') {
    if(next.sleeping || next.hunger>=80 || next.fatigue>=80)return next;
    return {...next,workout:{startedAt:now,appliedMs:0,vitalityGained:0},lastWorkout:null};
  }
  if (action === 'sleep') {const resting={...next,sleeping:true};return {...resting,life:mokiLife.advance(resting,now)};}
  if (action === 'wake') return { ...next, sleeping: false };
  if (next.sleeping) return next;
  if (action === 'feed') {
    const relief = Math.min(30, next.hunger);
    next.hunger -= relief;
    next.mood = clamp(next.mood + relief / 5);
    next.care += relief / 5;
    if(relief>=mokiChallenges.minimumCare){const challenge=mokiChallenges.record(next.player.challenges,'feed',now);next.player={...next.player,challenges:challenge.state,stars:next.player.stars+challenge.stars};}
  }
  if (action === 'bathe') {
    const relief = Math.min(60, next.dirt);
    next.dirt -= relief;
    next.mood = clamp(next.mood + relief / 6);
    next.care += relief / 5;
  }
  if (action === 'affection' && now - next.lastAffection >= 5 * 60000) {
    const lift = Math.min(8, 100 - next.mood);
    next.mood += lift;
    next.care += lift / 4;
    next.lastAffection = now;
  }
  next.life=mokiLife.advance(next,now);
  return evolve(next, now);
}

function restore(raw: string | null, now = Date.now()): Pet {
  if (!raw) return begin(now);
  try {
    const value = JSON.parse(raw);
    const numbers = ['bornAt','updatedAt','hunger','fatigue','dirt','mood','care','lastAffection'];
    numbers.push('eggTaps');
    if (value.version !== 3 || !Number.isInteger(value.eggTaps) || value.eggTaps < 0 || value.eggTaps > 5 || !['egg','baby','teen','adult'].includes(value.stage)
      || typeof value.sleeping !== 'boolean'
      || numbers.some(key => typeof value[key] !== 'number' || !Number.isFinite(value[key]))
      || value.bornAt < 0 || value.updatedAt < value.bornAt || value.care < 0) return begin(now);
    const finite=(v:unknown):v is number=>typeof v==='number' && Number.isFinite(v);
    const variant=mokiVariants.restore(value.variant);
    const starterChosen=value.player?.starterChosen!==false||value.stage!=='egg'||value.eggTaps>0;
    const player:Player={
      adoptions:adoptionCount(value.player?.adoptions),starterChosen,
      expeditions:mokiExpeditions.progress(value.player?.expeditions),
      divineUnlocked:value.player?.divineUnlocked===true||variant==='auri',
      challenges:mokiChallenges.restore(value.player?.challenges,now,value.player?.lastExerciseRewardDay),
      birdTrial:value.player?.birdTrial===true,
      raised:mokiVariants.history(value.player?.raised,value.stage==='adult'?variant:undefined),
      variants:mokiVariants.history(value.player?.variants,starterChosen?variant:undefined),
      closetTestCredit:value.player?.closetTestCredit===true,
      wardrobe:mokiWardrobe.restore(value.player?.wardrobe),
      stars:Number.isSafeInteger(value.player?.stars) && value.player.stars>=0 ? value.player.stars : 0,
      lastExerciseRewardDay:typeof value.player?.lastExerciseRewardDay==='string' && /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value.player.lastExerciseRewardDay) ? value.player.lastExerciseRewardDay : ''
    };
    player.wardrobe=mokiWardrobe.unlock(player.wardrobe,player.challenges.openedChests);
    player.wardrobe=mokiWardrobe.forVariant(player.wardrobe,variant);
    if(value.stage==='egg')player.wardrobe=mokiWardrobe.equip(player.wardrobe,null);
    const w=value.workout;
    const workout:Workout|null=w && value.stage!=='egg' && !value.sleeping &&
      finite(w.startedAt) && w.startedAt>=value.bornAt && finite(w.appliedMs) && w.appliedMs>=0 && w.appliedMs<=WORKOUT_MS &&
      finite(w.vitalityGained) && w.vitalityGained>=0 && w.vitalityGained<=12.001
      ? {startedAt:w.startedAt,appliedMs:w.appliedMs,vitalityGained:w.vitalityGained} : null;
    const r=value.lastWorkout;
    const lastWorkout:WorkoutResult|null=r && finite(r.endedAt) && finite(r.seconds) && r.seconds>=0 && r.seconds<=30 &&
      typeof r.complete==='boolean' && (r.stars===0 || r.stars===5) && finite(r.vitalityGained) && r.vitalityGained>=0 && r.vitalityGained<=12.001
      ? {endedAt:r.endedAt,seconds:r.seconds,complete:r.complete,stars:r.stars,vitalityGained:r.vitalityGained} : null;
    const minigame=value.stage!=='egg' && !value.sleeping && !workout ? mokiMinigame.restore(value.minigame) : null;
    const lastGame=mokiMinigame.restoreResult(value.lastGame);
    let memory=value.stage!=='egg' ? mokiMemory.restore(value.memory) : null;
    if(memory && (value.sleeping||workout||minigame))memory={...memory,active:false};
    const lastMemory=mokiMemory.restoreResult(value.lastMemory);
    const expeditionReward=mokiExpeditions.restoreResult(value.expeditionReward);
    const expedition=!expeditionReward&&!workout&&!minigame&&!memory?.active?mokiExpeditions.restore(value.expedition,{...value,variant}):null;
    return advance({ ...value, expedition, expeditionReward, life:mokiLife.restore(value.life,now), variant, minigame,lastGame,memory,lastMemory, vitality:finite(value.vitality) ? clamp(value.vitality) : 60, player,workout,lastWorkout, name: cleanName(value.name) || 'Moki', hunger: clamp(value.hunger), fatigue: clamp(value.fatigue),
      dirt: clamp(value.dirt), mood: clamp(value.mood) }, now);
  } catch { return begin(now); }
}

function progress(pet: Pet, now = Date.now()) {
  if (pet.stage === 'egg') return {
    percent: pet.eggTaps * 20,
    next: 'baby', targetHours: 0, targetCare: 0, ageHours: 0, care: 0, moodReady: true, day: 1
  };
  const age = Math.max(0, (pet.life.diedAt??now) - pet.bornAt) / HOUR;
  const adult = pet.stage === 'adult';
  const targetHours = pet.stage === 'baby' ? 24 : 72;
  const targetCare = pet.stage === 'baby' ? 20 : 60;
  const startHours = pet.stage === 'baby' ? 0 : 24;
  const startCare = pet.stage === 'baby' ? 0 : 20;
  const agePart = Math.max(0, Math.min(1, (age - startHours) / (targetHours - startHours)));
  const carePart = Math.max(0, Math.min(1, (pet.care - startCare) / (targetCare - startCare)));
  return { percent: adult ? 100 : Math.min(99, Math.floor((agePart + carePart) * 50)),
    next: pet.stage === 'baby' ? 'teen' : 'adult', targetHours, targetCare,
    ageHours: Math.floor(age), care: Math.floor(pet.care), moodReady: pet.mood >= 50,
    day: Math.floor(age / 24) + 1 };
}

function renew(pet:Pet,now=Date.now(),roll=Math.random(),group:Family=mokiVariants.family(pet.variant),expectedBornAt=pet.bornAt) {
  if(pet.bornAt!==expectedBornAt)return pet;
  const next=advance(pet,now),quote=adoptionQuote(next);
  if(!next.player.starterChosen||!mokiVariants.families.includes(group)||next.expedition||next.expeditionReward||next.workout||next.minigame||next.memory?.active||group==='divine'&&!next.player.divineUnlocked||!quote.affordable)return next;
  const player={...next.player,stars:next.player.stars-quote.cost,adoptions:quote.used+(next.life.diedAt===null?1:0),variants:mokiVariants.history(next.player.variants,mokiVariants.restore(next.variant))};
  return create(Math.max(now,next.updatedAt,next.bornAt+1),player,roll,group);
}
function buyAccessory(pet:Pet,id:string,now=Date.now()) {
  const next=advance(pet,now);
  const result=mokiWardrobe.buy(next.player.wardrobe,next.player.stars,id,next.variant,next.player.divineUnlocked);
  return {pet:{...next,player:{...next.player,stars:result.stars,wardrobe:result.wardrobe}},status:result.status};
}
function equipAccessory(pet:Pet,id:string|null,now=Date.now()):Pet {
  const next=advance(pet,now);
  return {...next,player:{...next.player,wardrobe:mokiWardrobe.equip(next.player.wardrobe,id,next.variant)}};
}
function settleGame(pet:Pet,now:number):Pet {
  if(!pet.minigame)return pet;
  const result=mokiMinigame.finish(pet.minigame,now);
  const challenge=result.complete&&result.score>0?mokiChallenges.record(pet.player.challenges,'game',result.endedAt):{state:pet.player.challenges,stars:0};
  return {...pet,minigame:null,lastGame:result,player:{...pet.player,challenges:challenge.state,stars:pet.player.stars+result.stars+challenge.stars}};
}
function startGame(pet:Pet,now=Date.now(),seed?:number):Pet {
  const next=advance(pet,now);
  if(next.expedition||next.life.diedAt!==null||next.stage==='egg'||next.sleeping||next.workout||next.minigame||next.memory?.active)return next;
  return {...next,minigame:mokiMinigame.create(now,seed),lastGame:null};
}
function catchFirefly(pet:Pet,id:number,now=Date.now()) {
  const next=advance(pet,now);
  if(!next.minigame)return {pet:next,caught:false};
  const run=mokiMinigame.catchTarget(next.minigame,id,now);
  return {pet:{...next,minigame:run},caught:run!==next.minigame};
}
function stopGame(pet:Pet,now=Date.now()):Pet {return settleGame(advance(pet,now),now);}
function startMemory(pet:Pet,now=Date.now(),seed?:number):Pet {
  const next=advance(pet,now);
  if(next.expedition||next.life.diedAt!==null||next.stage==='egg'||next.sleeping||next.workout||next.minigame)return next;
  return {...next,memory:next.memory?{...next.memory,active:true}:mokiMemory.create(now,seed),lastMemory:null};
}
function pauseMemory(pet:Pet,now=Date.now()):Pet {
  const next=advance(pet,now);
  return next.memory ? {...next,memory:{...next.memory,active:false}} : next;
}
function flipMemory(pet:Pet,index:number,now=Date.now()):{pet:Pet;outcome:'ignored'|'flip'|'match'|'complete'} {
  const next=advance(pet,now);
  if(!next.memory?.active)return {pet:next,outcome:'ignored'};
  const move=mokiMemory.flip(next.memory,index,now);
  if(!move.changed)return {pet:{...next,memory:move.run},outcome:'ignored'};
  const result=mokiMemory.finish(move.run,now);
  if(result){const challenge=mokiChallenges.record(next.player.challenges,'game',now);return {pet:{...next,memory:null,lastMemory:result,player:{...next.player,challenges:challenge.state,stars:next.player.stars+result.stars+challenge.stars}},outcome:'complete'};}
  return {pet:{...next,memory:move.run},outcome:move.match?'match':'flip'};
}
function claimChallenges(pet:Pet,now=Date.now()){
  const next=advance(pet,now),reward=mokiChallenges.claim(next.player.challenges,now);
  return {pet:{...next,player:{...next.player,challenges:reward.state,stars:next.player.stars+reward.stars,wardrobe:mokiWardrobe.unlock(next.player.wardrobe,reward.state.openedChests)}},stars:reward.stars};
}
function settleExpedition(pet:Pet,run:Expedition,at:number):Pet{
  const reward=mokiExpeditions.finish(run,at,pet.player.expeditions,pet.player.wardrobe.owned);
  const counts=pet.player.expeditions;
  return {...pet,expedition:null,expeditionReward:reward,player:{...pet.player,expeditions:reward.complete?{...counts,[run.route]:counts[run.route]+1}:counts}};
}
function startExpedition(pet:Pet,route:RouteId,now=Date.now(),roll=Math.random()):Pet{
  const next=advance(pet,now);
  if(!mokiExpeditions.isRoute(route)||!mokiExpeditions.readiness(next,route).ready)return next;
  return {...next,expedition:mokiExpeditions.create(next,route,Math.max(now,next.updatedAt),roll)};
}
function recallExpedition(pet:Pet,now=Date.now()):Pet{
  const next=advance(pet,now);
  return next.expedition?settleExpedition(next,next.expedition,Math.max(next.updatedAt,now)):next;
}
function claimExpedition(pet:Pet,id:string,now=Date.now()):Pet{
  const next=advance(pet,now),reward=next.expeditionReward;
  if(!reward||reward.id!==id)return next;
  const wardrobe=next.player.wardrobe;
  return {...next,expeditionReward:null,player:{...next.player,stars:next.player.stars+reward.coins,wardrobe:reward.accessory&&!wardrobe.owned.includes(reward.accessory)?{...wardrobe,owned:[...wardrobe.owned,reward.accessory]}:wardrobe}};
}
export const mokiPet = { begin, chooseStarter, adoptionQuote, adoptionCost:ADOPTION_COST, freeAdoptions:FREE_ADOPTIONS, startExpedition, recallExpedition, claimExpedition, claimChallenges, key: KEY, create, advance, act, restore, progress, cleanName, localDay, workoutMs:WORKOUT_MS, renew, buyAccessory, equipAccessory, startGame, catchFirefly, stopGame, startMemory, pauseMemory, flipMemory };

