import { useCallback, useEffect, useRef, useState } from 'react';
import { mokiPet } from './mokiPet';
import {mokiVariants} from './mokiVariants';
type Pet = ReturnType<typeof mokiPet.create>;
type Action = Parameters<typeof mokiPet.act>[1];
function readSavedPet() {
  return mokiPet.restore(localStorage.getItem(mokiPet.key));
}

export function useMokiPet() {
  const storageKey = mokiPet.key;
  const [pet, setPet] = useState<Pet>(() => {
    try { return readSavedPet(); }
    catch { return mokiPet.begin(); }
  });
  const current = useRef(pet);
  const [saved, setSaved] = useState(true);
  const store = useCallback((next: Pet) => {
    current.current = next;
    setPet(next);
    try { localStorage.setItem(storageKey, JSON.stringify(next)); setSaved(true); }
    catch { setSaved(false); }
    return next;
  }, [storageKey]);
  const commit = useCallback((action: Action) => store(mokiPet.act(current.current, action)), [store]);

  useEffect(() => {
    // Restore progress on reload without applying prototype-only grants or pet replacements.
    try { store(readSavedPet()); }
    catch { store(current.current); }
    const tick = () => store(mokiPet.advance(current.current));
    const fromOtherTab = (event: StorageEvent) => {
      if (event.key !== storageKey || !event.newValue) return;
      const incoming = mokiPet.restore(event.newValue);
      current.current = incoming; setPet(incoming);
    };
    const interval = setInterval(tick, 10000);
    window.addEventListener('focus', tick);
    window.addEventListener('pagehide', tick);
    window.addEventListener('storage', fromOtherTab);
    document.addEventListener('visibilitychange', tick);
    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', tick);
      window.removeEventListener('pagehide', tick);
      window.removeEventListener('storage', fromOtherTab);
      document.removeEventListener('visibilitychange', tick);
    };
  }, [store, storageKey]);
  const rename = useCallback((name: string) => {
    const clean = mokiPet.cleanName(name);
    if (clean) store({ ...current.current, name: clean });
  }, [store]);
  // Replacement is committed only after its pet, fee and counter are saved together.
  const saveReplacement=useCallback((next:Pet)=>{
    try {localStorage.setItem(storageKey,JSON.stringify(next));}
    catch {setSaved(false);return current.current;}
    current.current=next;setPet(next);setSaved(true);return next;
  },[storageKey]);
  const chooseStarter=useCallback((group:typeof mokiVariants.families[number])=>saveReplacement(mokiPet.chooseStarter(current.current,group)),[saveReplacement]);
  const newEgg = useCallback((group:typeof mokiVariants.families[number]=mokiVariants.family(current.current.variant),expectedBornAt=current.current.bornAt) => saveReplacement(mokiPet.renew(current.current,Date.now(),Math.random(),group,expectedBornAt)), [saveReplacement]);
  const buyAccessory=useCallback((id:string)=>{
    const result=mokiPet.buyAccessory(current.current,id);
    store(result.pet);
    return result.status;
  },[store]);
  const equipAccessory=useCallback((id:string|null)=>store(mokiPet.equipAccessory(current.current,id)),[store]);
  const startGame=useCallback(()=>store(mokiPet.startGame(current.current)),[store]);
  const catchFirefly=useCallback((id:number)=>{
    const result=mokiPet.catchFirefly(current.current,id);store(result.pet);return result.caught;
  },[store]);
  const stopGame=useCallback(()=>store(mokiPet.stopGame(current.current)),[store]);
  const startMemory=useCallback(()=>store(mokiPet.startMemory(current.current)),[store]);
  const pauseMemory=useCallback(()=>store(mokiPet.pauseMemory(current.current)),[store]);
  const flipMemory=useCallback((index:number)=>{
    const result=mokiPet.flipMemory(current.current,index);store(result.pet);return result.outcome;
  },[store]);
  const claimChallenges=useCallback(()=>{const result=mokiPet.claimChallenges(current.current);store(result.pet);return result.stars;},[store]);
  const startExpedition=useCallback((route:Parameters<typeof mokiPet.startExpedition>[1])=>store(mokiPet.startExpedition(current.current,route)),[store]);
  const recallExpedition=useCallback(()=>store(mokiPet.recallExpedition(current.current)),[store]);
  const claimExpedition=useCallback((id:string)=>store(mokiPet.claimExpedition(current.current,id)),[store]);
  return { chooseStarter, startExpedition, recallExpedition, claimExpedition, claimChallenges, pet, commit, saved, rename, newEgg, buyAccessory, equipAccessory, startGame, catchFirefly, stopGame, startMemory, pauseMemory, flipMemory };
}

