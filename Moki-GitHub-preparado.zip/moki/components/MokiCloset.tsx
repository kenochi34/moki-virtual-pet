import {mokiDivineMotion} from '../helpers/mokiDivineMotion';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from './Button';
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogClose } from './Dialog';
import { PixelIcon } from './PixelIcon';
import { mokiWardrobe } from '../helpers/mokiWardrobe';
import { mokiAccessories } from '../helpers/mokiAccessories';
import { mokiPet } from '../helpers/mokiPet';
import { mokiConfig } from '../helpers/mokiConfig';
import {mokiRobotMotion} from '../helpers/mokiRobotMotion';
import { mokiAlienMotion } from '../helpers/mokiAlienMotion';
import { mokiVariantArt } from '../helpers/mokiVariantArt';
import { mokiVariants } from '../helpers/mokiVariants';
import styles from './MokiCloset.module.css';
type Id=ReturnType<typeof mokiWardrobe.create>['owned'][number];
const copy={
  es:{title:'El clóset',intro:'Un toque tuyo para tu Moki.',choose:'Elige un accesorio para probarlo.',trying:'Probando · no gasta estrellas',wearing:'Su look actual',owned:'Tuyo',equipped:'Puesto',buy:'Comprar y equipar',equip:'Equipar',remove:'Quitar',clear:'Quitar todos',back:'Volver al cuarto',short:'Te faltan',stars:'estrellas',bought:'¡Comprado y puesto!',changed:'Look guardado.',insufficient:'No tienes suficientes estrellas.',already:'Este accesorio ya es tuyo.',error:'No se pudo guardar. El cambio durará solo esta sesión.',earn:'Primera sesión de ejercicio del día: +5 estrellas.',keep:'Tus accesorios se conservan al cambiar de Moki.',care:'Moki se los quita para bañarse y descansar.',collected:'Colección',saved:'Guardado en este dispositivo',shop:'Tienda',rewards:'Premios',mine:'Mis accesorios',reward:'Premio exclusivo',locked:'Se desbloquea con retos',chests:'cofres diarios abiertos',rewardHint:'Abre cofres en Retos para ganar accesorios. El progreso se acumula, aunque no juegues todos los días.',empty:'Aún no tienes accesorios. Prueba uno en la tienda.',filters:'Mostrar accesorios',available:'Desbloqueado',exclusive:'Exclusivo de Auri',divineOnly:'Disponible cuando cuidas a Auri',halloween:'Colección Halloween',halloweenHint:'Pequeños sustos, mucho estilo. Para todas las familias.',halloweenBadge:'Halloween'},
  en:{title:'The closet',intro:'A little style, all your own.',choose:'Choose an accessory to try it on.',trying:'Trying on · no stars spent',wearing:'Current outfit',owned:'Yours',equipped:'Wearing',buy:'Buy & wear',equip:'Wear',remove:'Remove',clear:'Remove all',back:'Back to the room',short:'You need',stars:'more stars',bought:'Bought and wearing it!',changed:'Outfit saved.',insufficient:'Not enough stars.',already:'You already own this accessory.',error:'Could not save. This change will last only for this session.',earn:'First exercise session each day: +5 stars.',keep:'Your accessories stay when you change Moki.',care:'Moki takes them off for baths and rest.',collected:'Collection',saved:'Saved on this device',shop:'Shop',rewards:'Rewards',mine:'My accessories',reward:'Exclusive reward',locked:'Unlock through challenges',chests:'daily chests opened',rewardHint:'Open chests in Challenges to earn accessories. Progress adds up, even if you skip days.',empty:'No accessories yet. Try one on in the shop.',filters:'Show accessories',available:'Unlocked',exclusive:'Auri exclusive',divineOnly:'Available while caring for Auri',halloween:'Halloween collection',halloweenHint:'Little frights, lots of style. For every family.',halloweenBadge:'Halloween'}
};
type Props={
  open:boolean;onOpenChange:(open:boolean)=>void;onReturnFocus:()=>void;
  pet:ReturnType<typeof mokiPet.create>;language:'es'|'en';saved:boolean;idleImage:HTMLImageElement|null;
  onBuy:(id:string)=>ReturnType<typeof mokiPet.buyAccessory>['status'];onEquip:(id:string|null)=>void;
  onClickSound:()=>void;onBuySound:()=>void;
};
function AccessoryIcon({id}:{id:string}) {
  return <svg viewBox="0 0 30 20" width={60} height={40} shapeRendering="crispEdges" aria-hidden="true">{mokiAccessories.icon(id).map(([x,y,width,height,fill],i)=><rect key={i} x={x} y={y} width={width} height={height} fill={fill}/>)}</svg>;
}
function ClosetPreview({variant,stage,image,outfit,label}:{variant:ReturnType<typeof mokiPet.create>['variant'];stage:ReturnType<typeof mokiPet.create>['stage'];image:HTMLImageElement|null;outfit:ReturnType<typeof mokiWardrobe.create>['equipped'];label:string}) {
  const canvas=useRef<HTMLCanvasElement>(null);
  const seed=useRef(Math.floor(Math.random()*4294967296));
  useEffect(()=>{
    if(!image || stage==='egg' || !canvas.current)return;
    const ctx=canvas.current.getContext('2d');if(!ctx)return;
    const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const {frames,times}=mokiVariantArt.animation(variant,'idle');
    let i=0,timer:ReturnType<typeof setTimeout>;
    const paint=()=>{
      const now=performance.now();
      ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,64,64);
      ctx.save();ctx.translate(0,mokiAlienMotion.hover(variant,'idle',now,reduced)+mokiDivineMotion.hover(variant,'idle',now,reduced));
      ctx.drawImage(image,frames[i]*64,0,64,64,0,0,64,64);
      mokiAlienMotion.draw(ctx,variant,now,'idle',reduced);
      mokiDivineMotion.draw(ctx,variant,now,'idle',reduced);
      mokiRobotMotion.draw(ctx,variant,now,'idle',reduced,seed.current);
      mokiAccessories.draw(ctx,stage,'idle',frames[i],outfit,0,reduced,mokiVariantArt.eyes(variant,stage,'idle',frames[i]),mokiVariants.family(variant)!=='moki',variant);
      ctx.restore();
    };
    const draw=()=>{paint();if(!reduced)timer=setTimeout(()=>{i=(i+1)%frames.length;draw();},times[i]);};
    draw();
    const lightTimer=(mokiAlienMotion.enabled(variant)||mokiRobotMotion.enabled(variant)||mokiDivineMotion.enabled(variant))&&!reduced?setInterval(paint,140):undefined;
    return()=>{clearTimeout(timer);clearInterval(lightTimer);};
  },[image,variant,stage,outfit]);
  return <canvas ref={canvas} width={64} height={64} className={styles.sprite} role="img" aria-label={label} data-testid="closet-preview"/>;
}
export function MokiCloset({open,onOpenChange,onReturnFocus,pet,language,saved,idleImage,onBuy,onEquip,onClickSound,onBuySound}:Props) {
  const t=copy[language],wardrobe=pet.player.wardrobe;
  const [filter,setFilter]=useState<'shop'|'rewards'|'mine'|'halloween'>('shop');
  const openedChests=pet.player.challenges.openedChests;
  const visible=mokiWardrobe.catalog.filter(item=>filter==='halloween'?item.collection==='halloween':filter==='mine'?wardrobe.owned.includes(item.id):(filter==='shop'?item.source==='shop':item.source!=='shop'));
  const [selected,setSelected]=useState<Id|null>(null);
  const [notice,setNotice]=useState<'bought'|'changed'|'insufficient'|'already'|'locked'|null>(null);
  const item=mokiWardrobe.catalog.find(item=>item.id===selected);
  const owned=!!item && wardrobe.owned.includes(item.id);
  const wearing=!!item && wardrobe.equipped[item.slot]===item.id;
  const eligible=!item||mokiWardrobe.compatible(item.id,pet.variant)&&(!item.family||pet.player.divineUnlocked);
  const affordable=!!item && eligible && item.source==='shop' && pet.player.stars>=item.price;
  const hasOutfit=Object.values(wardrobe.equipped).some(Boolean);
  const outfit=useMemo(()=>mokiWardrobe.preview(wardrobe,selected,pet.variant),[wardrobe,selected,pet.variant]);
  useEffect(()=>{if(open){setSelected(null);setNotice(null);setFilter('shop');}},[open]);
  function act() {
    if(!item||!eligible)return;
    if(owned) {onEquip(item.id);setSelected(null);setNotice('changed');return;}
    if(item.source!=='shop'){setNotice('locked');return;}
    const status=onBuy(item.id);
    setNotice(status==='bought' ? 'bought' : status==='owned' ? 'already' : status==='locked' ? 'locked' : 'insufficient');
    if(status==='bought'){onBuySound();setSelected(null);}
  }
  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className={styles.panel} closeLabel={t.back} lang={language} data-testid="moki-closet" onCloseAutoFocus={event=>{event.preventDefault();onReturnFocus();}} onClickCapture={event=>{
      const button=(event.target as Element).closest('button');if(button && !button.disabled)onClickSound();
    }}>
      <div className={styles.heading}><div><DialogTitle className={styles.title}>{t.title}</DialogTitle><DialogDescription className={styles.subtitle}>{t.intro}</DialogDescription></div><span className={styles.balance}><PixelIcon name="coin" size={18}/><output data-testid="closet-balance" aria-label={mokiConfig.copy[language].stars}>{pet.player.stars}</output></span></div>
      <div className={styles.mirror}>
        <span className={styles.name}>{pet.name} <small>{mokiConfig.copy[language][pet.stage]}</small></span>
        <div className={styles.shadow}/>
        <ClosetPreview variant={mokiVariants.restore(pet.variant)} stage={pet.stage} image={idleImage} outfit={outfit} label={item ? `${pet.name}: ${item.name[language]}` : pet.name}/>
        <span className={styles.previewLabel}>{!eligible ? t.divineOnly : selected ? t.trying : t.wearing}</span>
      </div>
      <div className={styles.collection}><span>{t.collected}</span><strong>{wardrobe.owned.length} / {mokiWardrobe.catalog.length}</strong></div>
      <div className={styles.filters} aria-label={t.filters}>{(['shop','rewards','mine'] as const).map(value=><Button key={value} variant="ghost" className={styles.filter} aria-pressed={filter===value||value==='shop'&&filter==='halloween'} data-testid={`closet-${value}`} onClick={()=>{setFilter(value);setSelected(null);setNotice(null);}}>{t[value]}</Button>)}</div>
      {(filter==='shop'||filter==='halloween')&&<Button variant="ghost" className={styles.halloween} aria-pressed={filter==='halloween'} data-testid="closet-halloween" onClick={()=>{setFilter(filter==='halloween'?'shop':'halloween');setSelected(null);setNotice(null);}}><AccessoryIcon id="witchHat"/><span><strong>{t.halloween}</strong><small>{t.halloweenHint}</small></span></Button>}
      {filter==='rewards'&&<p className={styles.rewardHint}>{t.rewardHint} {language==='es'?'También hay accesorios de exploración.':'You can also find exploration accessories.'}</p>}
      <div className={styles.rack} data-testid="accessory-catalog">{visible.map(accessory=>{
        const has=wardrobe.owned.includes(accessory.id),on=wardrobe.equipped[accessory.slot]===accessory.id;
        return <Button key={accessory.id} variant="ghost" className={styles.card} aria-pressed={selected===accessory.id} aria-label={`${accessory.name[language]} · ${has ? on ? t.equipped : t.owned : accessory.source==='expedition'?(language==='es'?'Hallazgo de exploración':'Exploration discovery'):accessory.source==='reward'?`${t.reward} · ${Math.min(openedChests,accessory.chests)}/${accessory.chests} ${t.chests}`:accessory.price+' '+mokiConfig.copy[language].stars}`} data-collection={accessory.collection} data-testid={`try-${accessory.id}`} onClick={()=>{setSelected(accessory.id);setNotice(null);}}>
          <AccessoryIcon id={accessory.id}/><span className={styles.itemName}>{accessory.name[language]}</span>{accessory.family&&<span className={styles.exclusive}>{t.exclusive}</span>}
          <span className={styles.price}>{has ? on ? t.equipped : t.owned : accessory.source==='expedition'?(language==='es'?'Exploración':'Exploration'):accessory.source==='reward'?<>{Math.min(openedChests,accessory.chests)}/{accessory.chests} {language==='es'?'cofres':'chests'}</>:<><PixelIcon name="coin" size={12}/>{accessory.price}</>}</span>
          {accessory.collection==='halloween'&&<span className={styles.halloweenBadge}>{t.halloweenBadge}</span>}
          {accessory.source==='reward'&&<span className={styles.unlockBar} aria-hidden="true"><i style={{width:`${Math.min(100,openedChests/accessory.chests*100)}%`}}/></span>}
        </Button>;
      })}{!visible.length&&<p className={styles.empty}>{t.empty}</p>}</div>
      <div className={styles.actions}>
        {item ? <Button className={styles.button} data-testid={owned ? 'equip-accessory' : item.source!=='shop'?'locked-accessory':'buy-accessory'} disabled={!eligible||!owned && !affordable} onClick={act}>{!eligible ? t.divineOnly : owned ? wearing ? t.remove : t.equip : item.source==='expedition'?(language==='es'?'Se encuentra al explorar':'Found on expeditions'):item.source==='reward'?`${t.locked} · ${Math.min(openedChests,item.chests)}/${item.chests}` : affordable ? <>{t.buy}<PixelIcon name="coin" size={14}/>{item.price}</> : `${t.short} ${item.price-pet.player.stars} ${t.stars}`}</Button> : <p className={styles.choose}>{t.choose}</p>}
        <Button variant="ghost" className={styles.clear} disabled={!hasOutfit} data-testid="clear-outfit" onClick={()=>{onEquip(null);setSelected(null);setNotice('changed');}}>{t.clear}</Button>
      </div>
      <p className={styles.notice} role="status">{!saved ? t.error : notice ? t[notice] : t.saved}</p>
      <p className={styles.hint}><PixelIcon name="coin" size={14}/>{language==='es'?'Gana monedas con minijuegos, ejercicio y retos diarios.':'Earn coins through minigames, exercise and daily challenges.'}</p>
      <p className={styles.hint}>{t.keep} {mokiVariants.family(pet.variant)==='robot'?(language==='es'?'Se quita los accesorios para mantenimiento y reposo.':'Accessories come off for maintenance and standby.'):t.care}</p>
      <DialogClose asChild><Button variant="ghost" className={styles.button}>{t.back}</Button></DialogClose>
    </DialogContent>
  </Dialog>;
}
