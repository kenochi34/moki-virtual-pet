import React from 'react';
import {Button} from './Button';
import {Switch} from './Switch';
import type {useMokiNotifications} from '../helpers/useMokiNotifications';
import styles from './MokiNotifications.module.css';
type Controller=ReturnType<typeof useMokiNotifications>;
export function MokiNotifications({notifications:n,language}:{notifications:Controller;language:'es'|'en'}){
 const es=language==='es';
 const deviceMessages:Record<string,string>=es?{
  granted:'Permitido',denied:'Bloqueado','prompt':'Pendiente de permiso','prompt-with-rationale':'Pendiente de permiso',unknown:'No se pudo comprobar',
  blocked:'Canal bloqueado',silent:'Sin sonido',standard:'Sin aviso emergente',heads_up:'Avisos emergentes permitidos',missing:'No aparece el canal de Moki',not_applicable:'No aplica'
 }:{granted:'Allowed',denied:'Blocked',prompt:'Permission needed','prompt-with-rationale':'Permission needed',unknown:'Could not check',
  blocked:'Channel blocked',silent:'Silent',standard:'No pop-up alert',heads_up:'Pop-up alerts allowed',missing:'Moki channel not found',not_applicable:'Not applicable'};
 const messages:Record<string,string>=es?{
  permission_help:'No se pudieron activar. Permite las notificaciones de Moki en los ajustes del teléfono o navegador y vuelve a intentarlo.',
  test_accepted:'El servicio aceptó la prueba. Esto todavía no confirma que tu teléfono la haya mostrado.',test_background_preparing:'Preparando la prueba. Espera la confirmación antes de salir.',test_background_wait:'Prueba programada. Sal ahora al inicio del teléfono y espera unos 10 segundos.',test_cooldown:'Espera un minuto antes de enviar otra prueba.',
  not_subscribed:'Activa de nuevo los avisos para reconectar este dispositivo.',subscription_expired:'La suscripción caducó. Vuelve a activar los avisos.',
  notification_service_unavailable:'No hay conexión con el servicio. Inténtalo de nuevo.',push_not_accepted:'El servicio no aceptó la prueba. Inténtalo de nuevo.'
 }:{permission_help:'Could not enable reminders. Allow Moki notifications in your phone or browser settings and try again.',test_accepted:'The service accepted the test. This does not yet confirm that your phone displayed it.',test_background_preparing:'Preparing the test. Wait for confirmation before leaving.',test_background_wait:'Test scheduled. Go to your phone’s home screen now and wait about 10 seconds.',test_cooldown:'Wait one minute before sending another test.',not_subscribed:'Enable reminders again to reconnect this device.',subscription_expired:'The subscription expired. Enable reminders again.',notification_service_unavailable:'Cannot reach the service. Please try again.',push_not_accepted:'The service did not accept the test. Please try again.'};
 const notice=messages[n.notice]??(n.notice.startsWith('Moki')?n.notice:es?'No se pudo guardar el cambio. Comprueba tu conexión e inténtalo de nuevo.':'Could not save the change. Check your connection and try again.');
 return <section className={styles.card} data-testid="moki-notifications" aria-label={es?'Recordatorios':'Reminders'}>
  <div className={styles.heading}><strong>{es?'Recordatorios':'Reminders'}</strong><span>{n.enabled?(es?'Activos':'On'):(es?'Desactivados':'Off')}</span></div>
  <p>{es?'Avisos de cuidado con la app cerrada. Máximo 2 al día, separados por al menos 6 horas. Silencio de 22:00 a 08:00, según la hora del dispositivo.':'Care reminders while the app is closed. Up to 2 per day, at least 6 hours apart. Quiet from 10 p.m. to 8 a.m. in your device’s time zone.'}</p>
  <Button className={styles.button} disabled={n.busy} data-testid="notifications-toggle" onClick={n.enabled?n.disable:n.enable}>{n.busy?(es?'Guardando…':'Saving…'):n.enabled?(es?'Desactivar avisos':'Turn off reminders'):(es?'Activar avisos':'Enable reminders')}</Button>
  {n.enabled&&<>
   {(['hunger','sleep','care'] as const).map((key,i)=><div className={styles.row} key={key}><label htmlFor={`moki-notify-${key}`}>{(es?['Comida o energía','Sueño o reposo','Limpieza y alegría']:['Food or energy','Sleep or standby','Cleanliness and happiness'])[i]}</label><Switch id={`moki-notify-${key}`} checked={n.preferences[key]} disabled={n.busy} onCheckedChange={value=>n.change(key,value)}/></div>)}
   <Button className={styles.button} disabled={n.busy} data-testid="notifications-test" onClick={n.test}>{es?'Enviar aviso de prueba':'Send test notification'}</Button>
   <Button className={styles.button} disabled={n.busy} data-testid="notifications-background-test" onClick={n.testBackground}>{es?'Probar fuera del juego · 10 s':'Test outside the game · 10 s'}</Button>
   <p>{es?'Las pruebas funcionan también durante el horario de silencio. Pulsa la prueba de 10 s, espera «Prueba programada» y sal al inicio del teléfono.':'Tests also work during quiet hours. Tap the 10-second test, wait for “Test scheduled”, then go to your phone’s home screen.'}</p>
  </>}
  <Button className={styles.button} disabled={n.busy} data-testid="notifications-check-device" onClick={n.check}>{es?'Comprobar este dispositivo':'Check this device'}</Button>
  {n.deviceStatus&&<div className={styles.notice} role="status" data-testid="notifications-device-status">
   {n.deviceStatus.platform==='web'?<p>{es?'Esta comprobación se completa desde la app instalada.':'Complete this check in the installed app.'}</p>:<>
    <p>{es?'Permiso del teléfono: ':'Phone permission: '}{deviceMessages[n.deviceStatus.permission]??deviceMessages.unknown}</p>
    {n.deviceStatus.platform==='android'&&<p>{es?'Canal de Moki: ':'Moki channel: '}{deviceMessages[n.deviceStatus.channel]??deviceMessages.unknown}</p>}
    <p>{es?'Avisos actualmente en la bandeja: ':'Notifications currently in the tray: '}{n.deviceStatus.visible??deviceMessages.unknown}</p>
    {(n.deviceStatus.permission==='denied'||n.deviceStatus.channel==='blocked')&&<p>{es?'Activa las notificaciones en Ajustes del teléfono → Apps → Moki → Notificaciones.':'Enable notifications in phone Settings → Apps → Moki → Notifications.'}</p>}
   </>}
  </div>}
  {n.notice&&<p className={styles.notice} role="status">{notice}</p>}
  <details className={styles.help}><summary>{es?'Batería y segundo plano':'Battery and background use'}</summary><p>{es?'Moki actualiza sus necesidades por el tiempo transcurrido al volver. No necesita mantener el juego ejecutándose para recibir avisos push. Se necesita conexión y Android puede retrasar avisos al ahorrar batería.':'Moki updates its needs using elapsed time when you return. The game does not need to keep running to receive push reminders. An internet connection is required, and Android may delay reminders to save battery.'}</p><p>{es?'Si los avisos no llegan en el APK, revisa Ajustes del teléfono → Apps → Moki → Notificaciones y Batería. Según tu teléfono, comprueba que se permita el uso en segundo plano. Los nombres pueden variar.':'If reminders do not arrive in the APK, check phone Settings → Apps → Moki → Notifications and Battery. Depending on your phone, check that background use is allowed. Setting names may vary.'}</p></details>
  <p className={styles.privacy}>{es?'Al activarlos, guardamos la suscripción de este dispositivo y un resumen de las necesidades para enviar avisos. Al desactivarlos, se eliminan. Tu partida sigue guardada en este dispositivo.':'Enabling reminders stores this device’s subscription and a summary of needs to send notifications. Turning them off deletes both. Your game stays saved on this device.'}</p>
 </section>;
}