import React,{useEffect,useRef} from 'react';
import {Button} from './Button';
import {Dialog,DialogContent,DialogTitle,DialogDescription,DialogClose} from './Dialog';
import {PixelIcon} from './PixelIcon';
import {mokiPet} from '../helpers/mokiPet';
import {mokiMemory} from '../helpers/mokiMemory';
import styles from './MokiMemoryGame.module.css';
const copy={
 es:{title:'Parejas mágicas',intro:'Pequeños tesoros del mundo de Moki.',pairs:'Parejas',attempts:'Intentos',reward:'Premio',instruction:'Destapa dos cartas y encuentra sus parejas.',rule:'5 estrellas al completar + hasta 3 de bonus.',bonus:'Bonus: +3 con 6–8 intentos · +2 con 9–11 · +1 con 12–15.',saved:'Puedes salir: tu tablero queda guardado.',error:'No se pudo guardar. La partida durará solo esta sesión.',finish:'¡Encontraste todos los tesoros!',credited:'Estrellas añadidas a tu saldo.',base:'Por completar',extra:'Bonus de memoria',again:'Otra partida',resume:'Continuar',start:'Comenzar',choose:'Elegir juego',back:'Volver al cuarto',card:'Carta',hidden:'oculta',found:'pareja encontrada',ready:'6 parejas · Sin límite de tiempo',paused:'Tu tablero está guardado.',blocked:'Despierta a Moki y espera a que termine su acción.',match:'¡Pareja encontrada!',miss:'No coinciden. Recuerda dónde están.',first:'Elige otra carta.',objects:['Manzana','Luna','Gota','Corazón','Huevo','Estrella']},
 en:{title:'Magic pairs',intro:"Little treasures from Moki's world.",pairs:'Pairs',attempts:'Attempts',reward:'Reward',instruction:'Turn over two cards and find their pairs.',rule:'5 stars for finishing + up to 3 bonus stars.',bonus:'Bonus: +3 for 6–8 attempts · +2 for 9–11 · +1 for 12–15.',saved:'You can leave: your board is saved.',error:'Could not save. This round will last only for this session.',finish:'You found every treasure!',credited:'Stars added to your balance.',base:'For finishing',extra:'Memory bonus',again:'Play again',resume:'Continue',start:'Start',choose:'Choose a game',back:'Back to the room',card:'Card',hidden:'hidden',found:'pair found',ready:'6 pairs · No time limit',paused:'Your board is saved.',blocked:'Wake Moki and wait for its current action to finish.',match:'Pair found!',miss:'No match. Remember their places.',first:'Choose another card.',objects:['Apple','Moon','Drop','Heart','Egg','Star']}
};
type Props={pet:ReturnType<typeof mokiPet.create>;open:boolean;onOpenChange:(open:boolean)=>void;onReturnFocus:()=>void;onChooseGame:()=>void;language:'es'|'en';saved:boolean;disabled:boolean;onStart:()=>void;onPause:()=>void;onTick:()=>void;onFlip:(index:number)=>'ignored'|'flip'|'match'|'complete';onSound:(effect:'button'|'catch'|'heart')=>void};
export function MokiMemoryGame({pet,open,onOpenChange,onReturnFocus,onChooseGame,language,saved,disabled,onStart,onPause,onTick,onFlip,onSound}:Props) {
 const t=copy[language],run=pet.memory,result=pet.lastMemory;
 const cards=useRef<Array<HTMLButtonElement|null>>([]);
 const resultHeading=useRef<HTMLHeadingElement>(null);
 const lastRun=useRef(run?.id);
 const [message,setMessage]=React.useState('');
 useEffect(()=>{
   if(!open||!run?.active||run.hideAt===null||!run)return;
   const timer=setTimeout(onTick,Math.max(0,run.hideAt-Date.now())+10);
   return()=>clearTimeout(timer);
 },[open,run?.active,run?.hideAt,onTick]);
 useEffect(()=>{
   if(run?.id!==lastRun.current){setMessage('');lastRun.current=run?.id;}
   if(open&&result&&!run)resultHeading.current?.focus({preventScroll:true});
 },[open,run?.id,result?.id]);
 function changeOpen(value:boolean){if(!value)onPause();onOpenChange(value);}
 function flip(index:number,keyboard:boolean) {
   const outcome=onFlip(index);
   if(outcome==='ignored')return;
   onSound(outcome==='flip'?'button':outcome==='match'?'catch':'heart');
   setMessage(outcome==='match'?t.match:outcome==='complete'?'':run?.revealed.length?t.miss:t.first);
   if(keyboard&&outcome==='match')requestAnimationFrame(()=>cards.current.find(el=>el&&!el.disabled)?.focus());
 }
 return <Dialog open={open} onOpenChange={changeOpen}>
  <DialogContent className={styles.panel} closeLabel={t.back} lang={language} data-testid="memory-game" onCloseAutoFocus={event=>{event.preventDefault();onReturnFocus();}} onClickCapture={event=>{
    const button=(event.target as Element).closest('button');if(button&&!button.disabled&&!button.hasAttribute('data-memory-card'))onSound('button');
  }}>
   <div className={styles.heading}><div><DialogTitle className={styles.title}>{t.title}</DialogTitle><DialogDescription className={styles.subtitle}>{t.intro}</DialogDescription></div><span className={styles.wallet}><PixelIcon name="coin" size={17}/><output>{pet.player.stars}</output></span></div>
   <div className={styles.stats}>
    <div><span>{t.pairs}</span><output data-testid="memory-pairs">{result?6:(run?.matched.length??0)/2}/6</output></div>
    <div><span>{t.attempts}</span><output data-testid="memory-attempts">{run?.attempts??result?.attempts??0}</output></div>
    <div><span>{t.reward}</span><strong><PixelIcon name="coin" size={14}/>{result?result.stars:'5–8'}</strong></div>
   </div>
   <div className={styles.garden}>
    {run?.active ? <div className={styles.grid} role="group" aria-label={t.title} aria-describedby="memory-instructions" data-testid="memory-board">
      {run.deck.map((item,index)=>{
       const matched=run.matched.includes(index),visible=matched||run.revealed.includes(index);
       return <Button key={index} ref={el=>{cards.current[index]=el;}} variant="ghost" className={`${styles.card} ${visible?styles.face:''} ${matched?styles.matched:''}`} disabled={matched||run.revealed.includes(index)||run.revealed.length===2} data-memory-card={index} data-state={matched?'matched':visible?'revealed':'hidden'} aria-label={`${t.card} ${index+1}, ${visible?t.objects[item]:t.hidden}${matched?', '+t.found:''}`} onClick={event=>flip(index,event.detail===0)}>
        {visible?<PixelIcon name={mokiMemory.items[item]} size={32}/>:<span className={styles.cardBack} aria-hidden="true"><PixelIcon name="sparkle" size={22}/></span>}
        {matched&&<span className={styles.check} aria-hidden="true">✓</span>}
       </Button>;
      })}
     </div> : <div className={styles.cover} data-testid={result?'memory-result':undefined}>
      {result ? <><PixelIcon name="coin" size={40}/><h3 ref={resultHeading} tabIndex={-1}>{t.finish}</h3><strong className={styles.reward}>+{result.stars} ★</strong><div className={styles.breakdown}><span>{t.base}<b>5</b></span><span>{t.extra}<b>+{result.bonus}</b></span></div><p>{t.credited}</p></> :
       <><div className={styles.treasures}>{mokiMemory.items.map(item=><PixelIcon key={item} name={item} size={29}/>)}</div><h3>{run?t.paused:t.ready}</h3><p>{t.instruction}</p></>}
     </div>}
   </div>
   <p id="memory-instructions" className={styles.instructions}>{run?.active?t.instruction:t.rule}</p>
   <p className={styles.message} role="status" aria-live="polite">{message||'\u00a0'}</p>
   {!run?.active&&<Button className={styles.button} disabled={disabled} data-testid="start-memory" onClick={()=>{setMessage('');onStart();}}>{run?t.resume:result?t.again:t.start}</Button>}
   <p className={styles.hint}>{disabled&&!run?.active?t.blocked:t.bonus}</p>
   <Button variant="ghost" className={styles.choose} data-testid="memory-choose-game" onClick={()=>{onPause();onChooseGame();}}><PixelIcon name="back" size={14}/>{t.choose}</Button>
   <p className={styles.save} role={!saved?'alert':undefined}>{saved?t.saved:t.error}</p>
   <DialogClose asChild><Button variant="ghost" className={styles.back}>{t.back}</Button></DialogClose>
  </DialogContent>
 </Dialog>;
}
