import React,{useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {Dialog,DialogContent,DialogTitle,DialogDescription,DialogClose} from './Dialog';
import {PixelIcon} from './PixelIcon';
import {mokiPet} from '../helpers/mokiPet';
import {mokiMinigame} from '../helpers/mokiMinigame';
import styles from './MokiFireflyGame.module.css';
const copy={
 es:{title:'Luciérnagas',intro:'Un paseo por el bosque de Moki.',instruction:'Toca las luciérnagas antes de que se escondan.',keyboard:'Teclado: Tab y Enter, o Espacio dentro del bosque.',rule:'Cada 3 atrapadas = 1 estrella · Máximo 10',duration:'Partidas de 30 segundos',start:'Comenzar',again:'Otra partida',stop:'Terminar y cobrar',back:'Volver al cuarto',time:'Tiempo',caught:'Atrapadas',earned:'Estrellas',finish:'¡Buen paseo!',stopped:'Paseo terminado',keep:'Tu recompensa ya está en el saldo.',zero:'Atrapa al menos 3 para ganar tu primera estrella.',forest:'Bosque de luciérnagas',catch:'Atrapar luciérnaga',ready:'¿Listo para explorar?',saved:'Las estrellas se guardan en este dispositivo.',error:'No se pudo guardar. El progreso durará solo esta sesión.',early:'Puedes terminar antes y conservar lo ganado.',blocked:'Despierta a Moki y espera a que termine su acción.'},
 en:{title:'Fireflies',intro:"A walk through Moki's forest.",instruction:'Tap the fireflies before they hide.',keyboard:'Keyboard: Tab and Enter, or Space inside the forest.',rule:'Every 3 caught = 1 star · Up to 10',duration:'30-second rounds',start:'Start',again:'Play again',stop:'Finish & collect',back:'Back to the room',time:'Time',caught:'Caught',earned:'Stars',finish:'Lovely exploring!',stopped:'Walk finished',keep:'Your reward is already in your balance.',zero:'Catch at least 3 to earn your first star.',forest:'Firefly forest',catch:'Catch firefly',ready:'Ready to explore?',saved:'Stars are saved on this device.',error:'Could not save. Progress will last only for this session.',early:'Finish early and keep what you earned.',blocked:'Wake Moki and wait for its current action to finish.'}
};
type Pet=ReturnType<typeof mokiPet.create>;
type Props={onChooseGame?:()=>void;pet:Pet;open:boolean;onOpenChange:(open:boolean)=>void;onReturnFocus:()=>void;language:'es'|'en';saved:boolean;disabled:boolean;onStart:()=>void;onStop:()=>void;onTick:()=>void;onCatch:(id:number)=>boolean;onSound:(effect:'button'|'catch'|'heart')=>void};
function Firefly() {
 return <svg viewBox="0 0 16 16" width={32} height={32} shapeRendering="crispEdges" aria-hidden="true"><path d="M3 2h3v2h4V2h3v4h-2v2h2v4h-3v2H6v-2H3V8h2V6H3z" fill="#092b3c"/><path d="M2 4h3v3H2zM11 4h3v3h-3zM3 9h3v3H3zM10 9h3v3h-3z" fill="#9adebf"/><path d="M6 4h4v6H6z" fill="#47755b"/><path d="M6 9h4v4H6z" fill="#ffd76f"/><path d="M7 9h2v2H7z" fill="#fff1ce"/></svg>;
}
export function MokiFireflyGame({onChooseGame,pet,open,onOpenChange,onReturnFocus,language,saved,disabled,onStart,onStop,onTick,onCatch,onSound}:Props) {
 const t=copy[language],run=pet.minigame,result=pet.lastGame;
 const [now,setNow]=useState(Date.now);
 const [burst,setBurst]=useState<{x:number;y:number;star:boolean}|null>(null);
 const burstTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
 const board=useRef<HTMLDivElement>(null),previousRun=useRef<string|null>(run?.id??null);
 const active=run ? mokiMinigame.targets(run,now) : [];
 const seconds=run ? Math.max(0,Math.ceil((run.startedAt+mokiMinigame.duration-now)/1000)) : 30;
 const score=run?.caught.length??result?.score??0;
 const stars=run ? mokiMinigame.reward(score) : result?.stars??0;
 useEffect(()=>{
   if(!run)return;
   const deadline=run.startedAt+mokiMinigame.duration;
   const tick=()=>{const time=Date.now();setNow(time);if(time>=deadline)onTick();};
   tick();const timer=setInterval(tick,50);return()=>clearInterval(timer);
 },[run?.id,onTick]);
 useEffect(()=>{
   if(run)previousRun.current=run.id;
   else if(previousRun.current) {previousRun.current=null;if(open&&result?.complete)onSound('heart');}
 },[run?.id,result?.id,open,onSound]);
 useEffect(()=>()=>{if(burstTimer.current)clearTimeout(burstTimer.current);},[]);
 function changeOpen(value:boolean) {if(!value&&run)onStop();setBurst(null);onOpenChange(value);}
 function catchOne(target:{id:number;x:number;y:number}) {
   if(!onCatch(target.id))return;
   const star=mokiMinigame.reward(score+1)>mokiMinigame.reward(score);
   onSound(star ? 'heart' : 'catch');setBurst({x:target.x,y:target.y,star});
   if(burstTimer.current)clearTimeout(burstTimer.current);
   burstTimer.current=setTimeout(()=>setBurst(null),600);
   board.current?.focus({preventScroll:true});
 }
 return <Dialog open={open} onOpenChange={changeOpen}>
  <DialogContent className={styles.panel} closeLabel={t.back} lang={language} data-testid="firefly-game" onCloseAutoFocus={event=>{event.preventDefault();onReturnFocus();}} onClickCapture={event=>{
   const button=(event.target as Element).closest('button');if(button&&!button.disabled&&!button.hasAttribute('data-firefly'))onSound('button');
  }}>
   <div className={styles.heading}><div><DialogTitle className={styles.title}>{t.title}</DialogTitle><DialogDescription className={styles.subtitle}>{t.intro}</DialogDescription></div><span className={styles.wallet}><PixelIcon name="coin" size={17}/><output data-testid="game-balance">{pet.player.stars}</output></span></div>
   <div className={styles.stats}><div><span>{t.time}</span><strong data-testid="game-time">0:{String(run?seconds:result?result.seconds:30).padStart(2,'0')}</strong></div><div><span>{t.caught}</span><output data-testid="game-score" aria-live="polite">{score}</output></div><div><span>{t.earned}</span><strong><PixelIcon name="coin" size={14}/><output data-testid="game-stars">{stars}</output></strong></div></div>
   <div ref={board} className={styles.forest} role="group" tabIndex={0} aria-label={t.forest} aria-describedby="firefly-instructions" data-testid="firefly-board" onKeyDown={event=>{
    if(event.target===event.currentTarget&&(event.key===' '||event.key==='Enter')){event.preventDefault();if(!event.repeat&&active[0])catchOne(active[0]);}
   }}>
    <svg className={styles.scenery} viewBox="0 0 100 100" preserveAspectRatio="none" shapeRendering="crispEdges" aria-hidden="true">
     <path d="M0 0h100v100H0z" fill="#162f35"/><path d="M0 42h8V25h7v55h11V33h8v50h32V29h8v53h11V22h8v28h7v50H0z" fill="#29494a"/>
     <path d="M4 0h7v10h3v20h-4v40H5V31H1V17H0V0zM85 0h8v20h7v8h-9v42h-5V26h-8v-9h7z" fill="#504435"/>
     <path d="M0 0h35v5H25v6H13v7H0zM68 0h32v18H89v-6H80V6H68z" fill="#3d6551"/>
     <path d="M0 83h8v-5h8v9h9v-4h12v7h25v-8h10v5h12v-8h9v6h7v15H0z" fill="#356148"/>
     <path d="M0 93h16v-3h7v5h11v-3h7v4h15v-3h12v3h12v-5h8v3h12v6H0z" fill="#6f9360"/>
     <path d="M17 85h2v7h-2zM78 84h2v10h-2zM12 96h2v4h-2zM87 96h2v4h-2z" fill="#bad589"/><path d="M30 16h1v1h-1zM61 9h1v1h-1zM48 30h1v1h-1zM73 44h1v1h-1z" fill="#719786"/>
    </svg>
    {run ? active.map(target=><Button key={target.id} variant="ghost" className={styles.firefly} style={{left:target.x+'%',top:target.y+'%'}} data-firefly={target.id} aria-label={`${t.catch} ${target.id+1}`} onClick={()=>catchOne(target)}><Firefly/></Button>) : <div className={styles.overlay}>
      {result ? <><PixelIcon name="coin" size={30}/><strong>{result.complete?t.finish:t.stopped}</strong><span className={styles.reward}>+{result.stars} ★</span><p>{result.stars?t.keep:t.zero}</p></> : <><Firefly/><strong>{t.ready}</strong><p>{t.instruction}</p><span>{t.duration}</span></>}
    </div>}
    {run&&burst&&<span key={score} className={styles.burst} style={{left:burst.x+'%',top:burst.y+'%'}} aria-hidden="true">{burst.star?'+1 ★':'+1'}</span>}
   </div>
   <p id="firefly-instructions" className={styles.instructions}>{run?t.instruction:t.rule}</p>
   <p className={styles.keyboard}>{t.keyboard}</p>
   {run ? <Button className={styles.button} data-testid="stop-game" onClick={onStop}>{t.stop}</Button> : <Button className={styles.button} data-testid="start-game" disabled={disabled} onClick={()=>{setNow(Date.now());setBurst(null);onStart();}}>{result?t.again:t.start}</Button>}
   <p className={styles.hint}>{disabled&&!run?t.blocked:run?t.rule:t.early}</p>
   {!run&&onChooseGame&&<Button variant="ghost" className={styles.back} data-testid="firefly-choose-game" onClick={onChooseGame}><PixelIcon name="back" size={14}/>{language==='es'?'Elegir juego':'Choose a game'}</Button>}
   <p className={styles.save} role={!saved?'alert':undefined}>{saved?t.saved:t.error}</p>
   <DialogClose asChild><Button variant="ghost" className={styles.back}>{t.back}</Button></DialogClose>
  </DialogContent>
 </Dialog>;
}
