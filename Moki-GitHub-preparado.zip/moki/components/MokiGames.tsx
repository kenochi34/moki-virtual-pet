import React,{useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {Dialog,DialogContent,DialogTitle,DialogDescription,DialogClose} from './Dialog';
import {PixelIcon} from './PixelIcon';
import {MokiFireflyGame} from './MokiFireflyGame';
import {MokiMemoryGame} from './MokiMemoryGame';
import {mokiExplorationThemes} from '../helpers/mokiExplorationThemes';
import styles from './MokiGames.module.css';
type Props=React.ComponentProps<typeof MokiFireflyGame>&{
 onMemoryStart:()=>void;onMemoryPause:()=>void;
 onExplore:()=>void;onExercise:()=>void;exerciseDisabled:boolean;
 onMemoryFlip:React.ComponentProps<typeof MokiMemoryGame>['onFlip'];
};
const copy={
 es:{title:'Jugar y explorar',intro:'Juegos, paseos y ejercicio.',more:'Desliza hacia abajo para explorar y ejercitar ↓',explore:'Explorar',exploreHelp:'Sal a buscar monedas y accesorios.',routes:'Jardín · 15 min / Arroyo · 1 h',openMap:'Abrir mapa',viewTrip:'Ver expedición',collect:'Recoger hallazgos',away:'Moki está de expedición.',returned:'Moki ha vuelto con sus hallazgos.',exercise:'Ejercicio',exerciseHelp:'Saltitos · 30 s · hasta +12 de vitalidad',openGym:'Ir al gimnasio',egg:'Primero ayuda a Moki a nacer.',dead:'Recibe un nuevo huevo para jugar.',busy:'Espera a que termine la actividad actual.',swipe:'Desliza para elegir un juego',previous:'Juego anterior',next:'Juego siguiente',start:'Comenzar',resume:'Continuar partida',back:'Volver al cuarto',blocked:'Despierta a Moki para jugar.',names:['Luciérnagas','Parejas mágicas'],descriptions:['Atrápalas antes de que se escondan.','Recuerda los tesoros y encuentra sus parejas.'],details:['30 segundos · Reflejos','6 parejas · Memoria'],rewards:['Hasta 10 estrellas','5 estrellas + hasta 3 de bonus'],saved:'Tu tablero te está esperando.',position:'Juego'},
 en:{title:'Play & explore',intro:'Games, trips and exercise.',more:'Swipe up for exploration and exercise ↓',explore:'Explore',exploreHelp:'Head out to find coins and accessories.',routes:'Garden · 15 min / Stream · 1 h',openMap:'Open map',viewTrip:'View expedition',collect:'Collect discoveries',away:'Moki is on an expedition.',returned:'Moki is back with discoveries.',exercise:'Exercise',exerciseHelp:'Little hops · 30 s · up to +12 vitality',openGym:'Go to the gym',egg:'Help Moki hatch first.',dead:'Receive a new egg to play.',busy:'Wait for the current activity to finish.',swipe:'Swipe to choose a game',previous:'Previous game',next:'Next game',start:'Start',resume:'Continue round',back:'Back to the room',blocked:'Wake Moki to play.',names:['Fireflies','Magic pairs'],descriptions:['Catch them before they hide.','Remember the treasures and find their pairs.'],details:['30 seconds · Reflexes','6 pairs · Memory'],rewards:['Up to 10 stars','5 stars + up to 3 bonus'],saved:'Your board is waiting for you.',position:'Game'}
};
function ForestPreview() {
 return <svg className={styles.forest} viewBox="0 0 160 104" shapeRendering="crispEdges" aria-hidden="true">
  <path fill="#162f35" d="M0 0h160v104H0z"/><path fill="#29494a" d="M8 0h9v90H8zM32 18h8v70h-8zM123 10h8v80h-8zM145 0h9v90h-9z"/>
  <path fill="#504435" d="M13 0h7v76h-7zM140 0h7v78h-7z"/><path fill="#3d6551" d="M0 0h56v6H43v8H26v9H0zM106 0h54v24h-20v-9h-20V7h-14zM0 88h12v-8h17v12h20v-6h15v10h36V84h16v7h19v-9h17v8h8v14H0z"/>
  <path fill="#6f9360" d="M0 99h33v-4h12v5h73v-5h15v4h27v5H0z"/><path fill="#88a589" d="M75 14h2v2h-2zM112 24h2v2h-2zM25 47h2v2h-2zM126 65h2v2h-2z"/>
  {[{x:46,y:39},{x:79,y:68},{x:111,y:42}].map(({x,y},i)=><g key={x} className={styles.fly} style={{animationDelay:i*180+'ms'}} transform={`translate(${x},${y})`}><path fill="#aed9b4" d="M-5-4h4v4h-4zM2-4h4v4H2zM-4 2h3v3h-3zM2 2h3v3H2z"/><path fill="#467256" d="M-1-3h3v5h-3z"/><path fill="#ffda79" d="M-2 1h5v5h-5z"/><path fill="#fff3c2" d="M-1 1h2v2h-2z"/></g>)}
 </svg>;
}
function MemoryPreview(){
 const items=['heart','sparkle','moon','food','egg','drop'] as const;
 return <div className={styles.memoryPreview} aria-hidden="true">{items.map((item,i)=><span key={item} className={i===1||i===4?styles.previewBack:styles.previewFace}><PixelIcon name={i===1||i===4?'sparkle':item} size={26}/></span>)}</div>;
}
// Floot's native CDN resolver handles image src attributes, not inline CSS URLs.
function MapPreview({src,language}:{src:string;language:'es'|'en'}){
 const [failed,setFailed]=useState(false);
 return <div className={styles.mapPreview}>
  {!failed?<img className={styles.mapImage} src={src} alt="" draggable={false} decoding="async" data-testid="exploration-thumbnail" onError={()=>setFailed(true)}/>:
   <div className={styles.mapError} role="status"><span>{language==='es'?'Vista previa no disponible.':'Preview unavailable.'}</span><Button variant="ghost" className={styles.button} data-testid="retry-map-preview" onClick={()=>setFailed(false)}>{language==='es'?'Reintentar':'Retry'}</Button></div>}
 </div>;
}
export function MokiGames(props:Props) {
 const {pet,open,onOpenChange,onReturnFocus,language,disabled,onSound}=props,t=copy[language];
 const theme=mokiExplorationThemes.get(pet.variant,language);
 const panel=useRef<HTMLDivElement>(null),scrollTop=useRef(0),exploreButton=useRef<HTMLButtonElement>(null);
 const blockedLabel=pet.expedition?t.away:pet.life.diedAt!==null?t.dead:pet.stage==='egg'?t.egg:pet.sleeping?t.blocked:t.busy;
 const [selected,setSelected]=useState(pet.memory?.active?1:0);
 const [screen,setScreen]=useState<'select'|'fireflies'|'memory'>(pet.minigame?'fireflies':pet.memory?.active?'memory':'select');
 const wasOpen=useRef(open),isOpen=useRef(open);
 isOpen.current=open;
 const pointer=useRef<{id:number;x:number;y:number}|null>(null),swiped=useRef(false);
 useEffect(()=>{
  if(open&&!wasOpen.current){setScreen(pet.minigame?'fireflies':pet.memory?.active?'memory':'select');}
  wasOpen.current=open;
 },[open,pet.minigame?.id,pet.memory?.active]);
 function returnFocus(){if(!isOpen.current)onReturnFocus();}
 function changeOpen(value:boolean){if(!value)pointer.current=null;onOpenChange(value);}
 function select(index:number){setSelected((index+2)%2);}
 function choose(){setScreen('select');}
 function start(){
  if(disabled)return;
  if(selected===0){setScreen('fireflies');props.onStart();}
  else {setScreen('memory');props.onMemoryStart();}
 }
 return <>
  <Dialog open={open&&screen==='select'} onOpenChange={changeOpen}>
   <DialogContent ref={panel} className={styles.panel} closeLabel={t.back} onScroll={event=>{scrollTop.current=event.currentTarget.scrollTop;}} onOpenAutoFocus={event=>{event.preventDefault();const target=scrollTop.current>0?exploreButton.current:panel.current?.querySelector<HTMLElement>('[data-testid="game-selector"]');target?.focus({preventScroll:true});if(panel.current)panel.current.scrollTop=scrollTop.current;}} lang={language} data-testid="moki-games" onCloseAutoFocus={event=>{event.preventDefault();returnFocus();}} onClickCapture={event=>{
    const button=(event.target as Element).closest('button');if(button&&!button.disabled)onSound('button');
   }}>
    <div className={styles.heading}><div><DialogTitle className={styles.title}>{t.title}</DialogTitle><DialogDescription className={styles.subtitle}>{t.intro}</DialogDescription></div><span className={styles.wallet}><PixelIcon name="coin" size={17}/><output>{pet.player.stars}</output></span></div>
    <p className={styles.moreHint}>{t.more}</p>
    <div className={styles.carousel} role="region" aria-roledescription={language==='es'?'carrusel':'carousel'} aria-label={t.title} tabIndex={0} data-testid="game-selector"
     onKeyDown={event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();select(selected+(event.key==='ArrowRight'?1:-1));onSound('button');}}}
     onPointerDown={event=>{swiped.current=false;if(event.isPrimary&&event.button===0)pointer.current={id:event.pointerId,x:event.clientX,y:event.clientY};}}
     onPointerCancel={()=>{pointer.current=null;}}
     onPointerUp={event=>{
      const p=pointer.current;pointer.current=null;if(!p||p.id!==event.pointerId)return;
      const dx=event.clientX-p.x,dy=event.clientY-p.y;
      if(Math.abs(dx)>=45&&Math.abs(dx)>Math.abs(dy)*1.3){swiped.current=true;select(selected+(dx<0?1:-1));onSound('button');}
     }}
     onClickCapture={event=>{if(swiped.current){event.preventDefault();event.stopPropagation();}}}>
     <div key={selected} className={styles.slide} role="group" aria-roledescription={language==='es'?'diapositiva':'slide'} aria-label={`${selected+1} / 2`}>
      <div className={styles.preview}>{selected===0?<ForestPreview/>:<MemoryPreview/>}<span className={styles.number}>{selected+1} / 2</span></div>
      <div className={styles.gameInfo} aria-live="polite" aria-atomic="true">
       <span className={styles.tag}>{t.details[selected]}</span><h3>{t.names[selected]}</h3><p>{t.descriptions[selected]}</p>
       <span className={styles.reward}><PixelIcon name="coin" size={16}/>{t.rewards[selected]}</span>
       {selected===1&&pet.memory&&<span className={styles.resume}>{t.saved}</span>}
      </div>
     </div>
    </div>
    <div className={styles.navigation}>
     <Button variant="ghost" className={styles.arrow} aria-label={t.previous} onClick={()=>select(selected-1)}>‹</Button>
     <div className={styles.dots}>{t.names.map((name,index)=><Button key={name} variant="ghost" className={styles.dot} aria-label={name} aria-pressed={selected===index} onClick={()=>select(index)}><span/></Button>)}</div>
     <Button variant="ghost" className={styles.arrow} aria-label={t.next} onClick={()=>select(selected+1)}>›</Button>
    </div>
    <p className={styles.hint}>{t.swipe}</p>
    <Button className={styles.button} data-testid="choose-game" disabled={disabled} onClick={start}>{selected===1&&pet.memory?t.resume:t.start}</Button>
    {disabled&&<p className={styles.hint}>{blockedLabel}</p>}
    <section className={styles.activity} aria-labelledby="moki-explore-heading" data-testid="play-exploration">
     <MapPreview key={theme.src} src={theme.src} language={language}/>
     <div className={styles.activityBody}><h2 id="moki-explore-heading"><PixelIcon name="sparkle" size={20}/>{t.explore}</h2><p>{pet.expedition?t.away:pet.expeditionReward?t.returned:t.exploreHelp}</p><small>{theme.routes.garden.name} · 15 min / {theme.routes.stream.name} · 1 h</small><Button ref={exploreButton} className={styles.button} data-testid="explore-control" onClick={props.onExplore}>{pet.expedition?t.viewTrip:pet.expeditionReward?t.collect:t.openMap}</Button></div>
    </section>
    <section className={styles.activity+' '+styles.exerciseCard} aria-labelledby="moki-exercise-heading" data-testid="play-exercise"><div className={styles.activityBody}><h2 id="moki-exercise-heading"><PixelIcon name="exercise" size={20}/>{t.exercise}</h2><p>{t.exerciseHelp}</p><Button className={styles.button} data-testid="gym-control" disabled={props.exerciseDisabled} onClick={props.onExercise}>{t.openGym}</Button>{props.exerciseDisabled&&<p className={styles.hint}>{blockedLabel}</p>}</div></section>
    <DialogClose asChild><Button variant="ghost" className={styles.back}>{t.back}</Button></DialogClose>
   </DialogContent>
  </Dialog>
  <MokiFireflyGame {...props} open={open&&screen==='fireflies'} onOpenChange={changeOpen} onReturnFocus={returnFocus} onChooseGame={choose}/>
  <MokiMemoryGame pet={pet} open={open&&screen==='memory'} onOpenChange={changeOpen} onReturnFocus={returnFocus} onChooseGame={choose} language={language} saved={props.saved} disabled={disabled} onStart={props.onMemoryStart} onPause={props.onMemoryPause} onTick={props.onTick} onFlip={props.onMemoryFlip} onSound={onSound}/>
 </>;
}
