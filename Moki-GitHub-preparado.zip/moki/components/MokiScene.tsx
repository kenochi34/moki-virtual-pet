import React,{useEffect,useRef,useState} from 'react';
import {mokiHabitat} from '../helpers/mokiHabitat';
import styles from './MokiScene.module.css';
export function MokiScene({family,place,night,alt,onReady,onError}:{family:string;place:'room'|'bath'|'gym';night:boolean;alt:string;onReady:(ready:boolean)=>void;onError:()=>void}){
 const src=mokiHabitat.get(family,night)[place];
 const [view,setView]=useState({src,previous:null as string|null,id:0});
 const errors=useRef(onError);errors.current=onError;
 useEffect(()=>{
  let active=true;let timer:ReturnType<typeof setTimeout>;onReady(false);
  const image=new Image();
  image.onload=()=>{
   if(!active)return;
   const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
   setView(last=>({src,previous:!reduced&&last.src!==src?last.src:null,id:last.id+1}));onReady(true);
   timer=setTimeout(()=>{if(active)setView(last=>({...last,previous:null}));},1000);
  };
  image.onerror=()=>{if(active){onReady(false);errors.current();}};image.src=src;
  return()=>{active=false;clearTimeout(timer);image.onload=null;image.onerror=null;};
 },[src,onReady]);
 return <div className={styles.scene} data-testid="family-scene" data-family={family} data-place={place} data-night={night} data-transitioning={!!view.previous}>
  <img className={styles.art} src={view.src} alt={alt} draggable={false}/>
  {view.previous&&<img key={view.id} className={`${styles.art} ${styles.previous}`} src={view.previous} alt="" aria-hidden="true" draggable={false}/>}
 </div>;
}