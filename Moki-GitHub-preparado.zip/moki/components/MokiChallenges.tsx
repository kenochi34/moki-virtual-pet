import {mokiWardrobe} from '../helpers/mokiWardrobe';
import {mokiAccessories} from '../helpers/mokiAccessories';
import React,{useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {Dialog,DialogTrigger,DialogContent,DialogTitle,DialogDescription,DialogClose} from './Dialog';
import {Progress} from './Progress';
import {PixelIcon} from './PixelIcon';
import {mokiChallenges} from '../helpers/mokiChallenges';
import {mokiPet} from '../helpers/mokiPet';
import {mokiVariants} from '../helpers/mokiVariants';
import styles from './MokiChallenges.module.css';
const copy={
 es:{short:'Retos',title:'Retos de hoy',intro:'Tres pequeños objetivos. Un cofre para celebrar.',complete:'completados',feed:'Alimentar dos veces',charge:'Recargar dos veces',feedHelp:'Cuenta al alimentar con 10% de hambre o más.',chargeHelp:'Cuenta al recargar con 90% de energía o menos.',game:'Completar un minijuego',gameHelp:'Completa Memoria o termina Luciérnagas atrapando al menos una.',exercise:'Completar una sesión de ejercicio',exerciseHelp:'Incluye las 5 monedas de la primera sesión del día.',received:'Recibidas',coins:'monedas',chest:'Cofre del día',locked:'Completa los tres retos para abrirlo.',ready:'¡Tu recompensa está lista!',claimed:'¡Cofre abierto!',savedBonus:'Tienes recompensas guardadas.',open:'Abrir cofre',collect:'Recoger',back:'Volver al cuarto',reset:'Nuevos retos a las 00:00, según tu hora local.',keep:'Los cofres ganados se guardan hasta que los abras.',automatic:'Las monedas de cada reto se suman al completarlo.',egg:'Ayuda a tu huevo a nacer para comenzar los retos.',error:'No se pudo guardar. El progreso durará solo esta sesión.',earned:'¡Monedas añadidas!',progress:'Progreso de los retos diarios',close:'Cerrar retos',accessories:'Premios de accesorios',unlockHelp:'Abre cofres diarios. El progreso se acumula y no requiere días consecutivos.',inCloset:'Ya está en tu clóset',chestsOpened:'cofres abiertos',newAccessory:'¡Nuevo accesorio en tu clóset!'},
 en:{short:'Challenges',title:"Today's challenges",intro:'Three little goals. One chest to celebrate.',complete:'completed',feed:'Feed twice',charge:'Charge twice',feedHelp:'Counts when feeding with hunger at 10% or higher.',chargeHelp:'Counts when charging with energy at 90% or lower.',game:'Complete a minigame',gameHelp:'Finish Memory, or finish Fireflies while catching at least one.',exercise:'Complete an exercise session',exerciseHelp:'Includes the 5 coins from your first session today.',received:'Received',coins:'coins',chest:'Daily chest',locked:'Complete all three challenges to open it.',ready:'Your reward is ready!',claimed:'Chest opened!',savedBonus:'You have saved rewards.',open:'Open chest',collect:'Collect',back:'Back to the room',reset:'New challenges at midnight in your local time.',keep:'Earned chests stay saved until you open them.',automatic:'Each challenge adds its coins when completed.',egg:'Help your egg hatch to begin the challenges.',error:'Could not save. Progress will last only for this session.',earned:'Coins added!',progress:'Daily challenge progress',close:'Close challenges',accessories:'Accessory rewards',unlockHelp:'Open daily chests. Progress adds up; consecutive days are not required.',inCloset:'In your closet',chestsOpened:'chests opened',newAccessory:'New accessory in your closet!'}
};
function Chest({open=false,ready=false,large=false}:{open?:boolean;ready?:boolean;large?:boolean}){
 return <svg className={`${styles.chest} ${large?styles.large:''} ${open?styles.opened:''} ${ready?styles.ready:''}`} viewBox="0 0 32 32" width={32} height={32} shapeRendering="crispEdges" aria-hidden="true">
  <path d="M4 17h24v12H4z" fill="#263b32"/><path d="M6 18h20v9H6z" fill="#9d632b"/><path d="M8 19h16v6H8z" fill="#c6893b"/><path d="M7 18h3v9H7zM22 18h3v9h-3zM5 26h22v2H5z" fill="#f4ce69"/>
  <path d="M6 17h20v3H6z" fill="#382922"/>
  <g className={styles.lid}><path d="M6 10h20v2h2v7H4v-7h2z" fill="#263b32"/><path d="M7 12h18v2h1v3H6v-3h1z" fill="#d09545"/><path d="M8 12h3v5H8zM21 12h3v5h-3zM6 16h20v2H6z" fill="#ffe59a"/></g>
  <path d="M14 16h4v2h1v4h-6v-4h1z" fill="#f4ce69"/><path d="M15 18h2v2h-2z" fill="#735130"/>
  {(ready||open)&&<g className={styles.glints} fill="#ffeaa7"><path d="M3 5h2v2h2v2H5v2H3V9H1V7h2zM27 3h2v2h2v2h-2v2h-2V7h-2V5h2z"/></g>}
 </svg>;
}
type Props={pet:ReturnType<typeof mokiPet.create>;language:'es'|'en';saved:boolean;onClaim:()=>number;onClickSound:()=>void;onRewardSound:()=>void};
export function MokiChallenges({pet,language,saved,onClaim,onClickSound,onRewardSound}:Props){
 const t=copy[language],state=pet.player.challenges,progress=mokiChallenges.summary(state),family=mokiVariants.family(pet.variant),robot=family==='robot';
 const accessoryRewards=mokiWardrobe.catalog.filter(item=>item.source==='reward');
 const upcoming=accessoryRewards.filter(item=>!pet.player.wardrobe.owned.includes(item.id)&&item.chests<=state.openedChests+state.pendingChests);
 const [unlocked,setUnlocked]=useState<string[]>([]);
 const [open,setOpen]=useState(false),[reward,setReward]=useState(0);
 const timer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
 useEffect(()=>()=>clearTimeout(timer.current),[]);
 useEffect(()=>{setReward(0);},[state.day]);
 const rows:[string,React.ComponentProps<typeof PixelIcon>['name'],string,string,number,number,number][]=[
  ['feed',robot?'battery':'food',robot?t.charge:t.feed,robot?t.chargeHelp:t.feedHelp,state.feeds,2,mokiChallenges.rewards.feed],
  ['game','game',t.game,t.gameHelp,state.games,1,mokiChallenges.rewards.game],
  ['exercise','exercise',t.exercise,t.exerciseHelp,state.exercise,1,mokiChallenges.rewards.exercise]
 ];
 function claim(){const amount=onClaim();if(!amount)return;clearTimeout(timer.current);setReward(amount);setUnlocked(upcoming.map(item=>item.name[language]));onRewardSound();timer.current=setTimeout(()=>setReward(0),2800);}
 function changeOpen(value:boolean){setOpen(value);if(value){onClickSound();setReward(0);setUnlocked([]);}}
 return <Dialog open={open} onOpenChange={changeOpen}>
  <DialogTrigger asChild><Button variant="ghost" className={styles.trigger} data-testid="challenges-control" data-ready={progress.pending>0} aria-label={`${t.title}: ${progress.complete}/3, ${progress.percent}%. ${progress.pending?t.ready:''}`}>
   <span className={styles.compact}><span className={styles.caption}><span>{t.short}</span><b>{progress.complete}/3</b></span><span className={styles.pixels} aria-hidden="true">{Array.from({length:12},(_,i)=><i key={i} data-lit={i<progress.complete*4}/>)}</span></span>
   <Chest open={state.claimedToday} ready={progress.pending>0}/>
  </Button></DialogTrigger>
  <DialogContent className={styles.panel} lang={language} data-family={family} data-testid="moki-challenges" closeLabel={t.close}>
   <DialogTitle className={styles.title}>{t.title}</DialogTitle><DialogDescription className={styles.intro}>{t.intro}</DialogDescription>
   <div className={styles.summary}><span>{progress.complete}/3 {t.complete}</span><strong data-testid="challenge-percent">{progress.percent}%</strong></div>
   <Progress className={styles.totalBar} value={progress.percent} aria-label={t.progress}/>
   <p className={styles.date}>{new Date(state.day+'T12:00:00').toLocaleDateString(language,{month:'long',day:'numeric'})}</p>
   {pet.stage==='egg'&&<p className={styles.egg}><PixelIcon name="egg"/>{t.egg}</p>}
   <div className={styles.list}>{rows.map(([id,icon,title,help,value,target,coins])=><div className={styles.card} key={id} data-testid={`challenge-${id}`} data-complete={value===target}>
    <div className={styles.row}><span className={styles.icon}><PixelIcon name={icon} size={22}/></span><div className={styles.rowText}><strong>{title}</strong><span className={styles.reward}><PixelIcon name="coin" size={13}/>{value===target?t.received+' · ': '+'}{coins}</span></div><span className={styles.count}>{value===target&&<span aria-hidden="true">✓ </span>}{value}/{target}</span></div>
    <Progress className={styles.taskBar} value={value/target*100} aria-label={`${title}: ${value}/${target}`}/><p>{help}</p>
   </div>)}</div>
   <div className={styles.prize} data-ready={progress.pending>0} data-open={state.claimedToday} data-testid="daily-chest">
    <div className={styles.chestScene}><Chest large open={state.claimedToday||reward>0} ready={progress.pending>0}/>{reward>0&&<span key={reward} className={styles.coinBurst} aria-hidden="true"><PixelIcon name="coin" size={22}/><b>+{reward}</b><i/><i/><i/><i/></span>}</div>
    <div className={styles.prizeText}><strong>{t.chest}</strong><p>{progress.pending?(progress.complete===3?t.ready:t.savedBonus):state.claimedToday?t.claimed:t.locked}</p><span className={styles.reward}><PixelIcon name="coin" size={16}/>+{progress.pending||mokiChallenges.rewards.chest} {t.coins}</span></div>
    <Button className={styles.claim} data-testid="claim-chest" disabled={!progress.pending} onClick={claim}>{progress.pending?(progress.complete===3?t.open:t.collect):state.claimedToday?t.received:'3/3'}</Button>
   </div>
   <p className={styles.notice} role="status" aria-live="polite">{!saved?t.error:reward?`${t.earned} +${reward}`:t.automatic}</p>
   {unlocked.length>0&&<p className={styles.unlocked} role="status">{t.newAccessory} {unlocked.join(' · ')}</p>}
   <section className={styles.accessories} aria-labelledby="accessory-rewards-title">
    <h3 id="accessory-rewards-title">{t.accessories}</h3><p>{t.unlockHelp}</p>
    {accessoryRewards.map(item=>{const has=pet.player.wardrobe.owned.includes(item.id),value=Math.min(state.openedChests,item.chests);return <div key={item.id} className={styles.accessoryReward} data-testid={`reward-${item.id}`} data-unlocked={has}>
     <svg viewBox="0 0 30 20" width={54} height={36} shapeRendering="crispEdges" aria-hidden="true">{mokiAccessories.icon(item.id).map(([x,y,w,h,fill],i)=><rect key={i} x={x} y={y} width={w} height={h} fill={fill}/>)}</svg>
     <div><strong>{item.name[language]}</strong><span>{has?t.inCloset:`${value}/${item.chests} ${t.chestsOpened}`}</span><Progress className={styles.taskBar} value={has?100:value/item.chests*100} aria-label={`${item.name[language]}: ${value}/${item.chests}`}/></div>{has&&<b aria-hidden="true">✓</b>}
    </div>;})}
   </section>
   <p className={styles.footnote}>{t.reset}<br/>{t.keep}</p>
   <DialogClose asChild><Button variant="ghost" className={styles.back} onClick={onClickSound}><PixelIcon name="back" size={16}/>{t.back}</Button></DialogClose>
  </DialogContent>
 </Dialog>;
}