import React,{useId} from 'react';
import {mokiRobotMotion} from '../helpers/mokiRobotMotion';
import styles from './MokiDock.module.css';
export function MokiDock({phase,step,stage,reduced}:{phase:string;step:number;stage:string;reduced:boolean}){
 const clip=useId().replace(/:/g,''),dock=mokiRobotMotion.dock(phase,step,reduced);
 const width=stage==='baby'?28:stage==='teen'?32:36,height=stage==='baby'?24:stage==='teen'?30:36;
 const left=50-width/2,right=50+width/2,floor=81.5,top=floor-height,offset=height*(1-dock.rise);
 // Fit the same 46%-wide room sprite; the connector never crosses the room controls.
 const portX=50+6*46/38,portY=46.2+((stage==='baby'?74:stage==='teen'?72:70)-49.6)*46/38;
 const endX=right-2+(portX-(right-2))*dock.cable;
 return <>
  <svg viewBox="0 0 100 100" preserveAspectRatio="none" className={styles.dock} shapeRendering="crispEdges" aria-hidden="true" data-testid="robot-dock" data-state={dock.state} data-connected={dock.cable===1} data-rise={dock.rise}>
   <defs><clipPath id={clip}><rect x={left-2} y={top-2} width={width+4} height={height+2}/></clipPath></defs>
   <path d={`M${left-1} ${floor}h${width+2}v1.5H${left-1}z`} fill="#142b3a" opacity=".7"/>
   <path d={`M${left+2} ${floor+.4}h${width-4}`} stroke="#93c8c8" strokeWidth=".35" opacity=".7"/>
   <g clipPath={`url(#${clip})`}>
    <g transform={`translate(0 ${offset})`}>
     <path d={`M${left} ${floor}V${top+5}h2v-3h3v-2h${width-10}v2h3v3h2v${height-5}z`} fill="#122e40"/>
     <path d={`M${left+2} ${floor}V${top+5}h3v-3h${width-10}v3h3v${height-5}z`} fill="#bad4ca"/>
     <path d={`M${left+4} ${floor}V${top+6}h3v-2h${width-14}v2h3v${height-6}z`} fill="#6be2e1" opacity=".26"/>
     <path d={`M${left+4} ${top+7}v${height-8}M${right-4} ${top+7}v${height-8}`} stroke="#95eeec" strokeWidth=".7"/>
     <path d={`M${left+7} ${top+5}h${width-14}`} stroke="#f6efd0" strokeWidth="1"/>
     <path d={`M${left+6} ${top+8}v${Math.max(3,height/3)}`} stroke="#d7fff1" strokeWidth=".5" opacity=".7"/>
     <rect x={48} y={top+1} width={4} height={1} fill="#e7c479"/>
     <rect x={right-3} y={portY-2} width={2} height={4} fill="#173b4c"/>
    </g>
   </g>
  </svg>
  {dock.rise>0&&<svg viewBox="0 0 100 100" preserveAspectRatio="none" className={styles.connector} shapeRendering="crispEdges" aria-hidden="true">
   <path d={`M${left} ${floor-.5}h${width}v2H${left}z`} fill="#173344"/>
   <path d={`M${left+2} ${floor}h${width-4}`} stroke="#d1e6d8" strokeWidth=".6"/>
   <rect x={46} y={floor+.5} width={8} height={.6} fill={dock.cable===1?'#90efc6':'#79c8d5'} className={dock.cable===1?styles.status:undefined}/>
   {dock.cable>0&&<g><path d={`M${right-2} ${portY}H${endX}`} stroke="#122b3e" strokeWidth="1.7"/><path d={`M${right-2} ${portY}H${endX}`} stroke="#b8d4ce" strokeWidth=".7"/><rect x={endX-.7} y={portY-1.1} width={1.5} height={2.2} fill={dock.cable===1?'#a1f3dc':'#e5dfb6'}/></g>}
  </svg>}
 </>;
}
