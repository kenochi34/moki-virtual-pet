import React, { useEffect, useState } from 'react';
import styles from './EggShellBurst.module.css';
const shapes = ['M1 1h4v1h2v3H6v2H3V6H1z', 'M3 0h3v2h1v3H5v2H2V5H1V2h2z', 'M0 2h3V1h3v2h2v2H6v2H3V6H1V4H0z'];

export function EggShellBurst({ id, strength, onComplete }: { id: number; strength: number; onComplete: (id: number) => void }) {
  const [particles] = useState(() => Array.from({ length: 4 + Math.min(5, strength) * 2 }, (_, index) => {
    const side = index % 2 === 0 ? -1 : 1;
    const endX = side * (45 + Math.round(Math.random() * 65));
    return {
      startX: side * (6 + Math.round(Math.random() * 12)), startY: Math.round(Math.random() * 20) - 12,
      endX, endY: 12 + Math.round(Math.random() * 24),
      peakX: Math.round(endX * .55), peakY: -24 - Math.round(Math.random() * 38),
      size: 10 + Math.floor(Math.random() * 4) * 2, delay: Math.round(Math.random() * 90),
      shape: Math.floor(Math.random() * shapes.length), cream: Math.random() > .55
    };
  }));
  useEffect(() => {
    const timer = setTimeout(() => onComplete(id), 1900);
    return () => clearTimeout(timer);
  }, [id, onComplete]);
  return <div className={styles.burst} aria-hidden="true" data-testid="egg-shell-burst" data-burst={id}>
    {particles.map((p, i) => <span key={i} className={styles.fragment} style={{
      '--start-x': p.startX+'px', '--start-y': p.startY+'px',
      '--peak-x': p.peakX+'px', '--peak-y': p.peakY+'px',
      '--end-x': p.endX+'px', '--end-y': p.endY+'px', '--delay': p.delay+'ms'
    } as React.CSSProperties}>
      <svg viewBox="0 0 8 8" width={p.size} height={p.size} shapeRendering="crispEdges">
        <path d={shapes[p.shape]} fill="var(--shell-outline)" />
        <path d="M2 2h3v1h1v2H4v1H3V4H2z" fill={p.cream ? 'var(--shell-cream)' : 'var(--shell-mint)'} />
        <path d="M3 2h2v1H3z" fill={p.cream ? 'var(--shell-mint)' : 'var(--shell-cream)'} />
      </svg>
    </span>)}
  </div>;
}
