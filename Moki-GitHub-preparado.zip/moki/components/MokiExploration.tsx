import React,{useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {PixelIcon} from './PixelIcon';
import {mokiExpeditions,type RouteId} from '../helpers/mokiExpeditions';
import {mokiPet} from '../helpers/mokiPet';
import {mokiWardrobe} from '../helpers/mokiWardrobe';
import {mokiAccessories} from '../helpers/mokiAccessories';
import {mokiVariantArt} from '../helpers/mokiVariantArt';
import {mokiVariants} from '../helpers/mokiVariants';
import {mokiExplorationThemes} from '../helpers/mokiExplorationThemes';
import {mokiCanvas} from '../helpers/mokiCanvas';
import styles from './MokiExploration.module.css';
type Pet=ReturnType<typeof mokiPet.create>;
type Props={pet:Pet;language:'es'|'en';saved:boolean;busy?:boolean;now?:number;onBack:()=>void;onStart:(route:RouteId)=>void;onRecall:()=>void;onClaim:(id:string)=>void;onTick:()=>void};
const copy={
 es:{title:'EXPLORAR',choose:'Elige una expedición',back:'Volver',home:'Casa de Moki',forest:'Bosque antiguo',ruins:'Ruinas del eclipse',soon:'Próximamente',send:'Enviar a explorar',outside:'El viaje continúa con la app cerrada.',coins:'monedas',food:'Comida',rest:'Descanso',clean:'Limpieza',away:'En exploración',returns:'Regresa en',recall:'Regresar antes',cancel:'Seguir explorando',recallHelp:'Volverá con monedas proporcionales al tiempo recorrido, sin accesorio ni avance del destino.',confirm:'Sí, regresar',returned:'¡Moki ha vuelto!',recalled:'De vuelta en casa',claim:'Recoger hallazgos',saved:'Guardado en este dispositivo',saveError:'No se pudo guardar. No cierres la app; este progreso podría perderse.',discovery:'Encontró un sendero entre las hojas.',shortTrip:'Un paseo corto también cuenta.',accessory:'Accesorio descubierto',chance:'25% de encontrarlo. Garantizado al completar 5 viajes a este destino.',complete:'Viajes completos',allFound:'Ya tienes el accesorio de este destino.',imageError:'El paisaje no cargó. Puedes usar los destinos.',retry:'Reintentar paisaje',care:'Prepara sus cuidados: hambre, sueño y suciedad hasta 60%; ánimo de 40% o más.',sleeping:'Despiértalo antes de salir.',egg:'Primero ayuda a tu Moki a nacer.',teen:'Disponible desde adolescente.',busy:'Termina la actividad actual antes de salir.',dead:'Recibe un nuevo huevo para explorar.',reward:'Recoge los hallazgos antes de otro viaje.',blocked:'Tu Moki ya está explorando.',mood:'Ánimo',bag:'Tus hallazgos te esperan, sin caducar.',settling:'Llegando a casa…'},
 en:{title:'EXPLORE',choose:'Choose an expedition',back:'Back',home:"Moki’s home",forest:'Ancient forest',ruins:'Eclipse ruins',soon:'Coming soon',send:'Send exploring',outside:'The trip continues with the app closed.',coins:'coins',food:'Food',rest:'Rest',clean:'Cleanliness',away:'Exploring',returns:'Returns in',recall:'Return early',cancel:'Keep exploring',recallHelp:'Returns with coins for the time travelled, without an accessory or destination progress.',confirm:'Yes, return',returned:'Moki is back!',recalled:'Back home',claim:'Collect discoveries',saved:'Saved on this device',saveError:'Could not save. Keep the app open; this progress could be lost.',discovery:'Found a little trail among the leaves.',shortTrip:'Even a short walk has its moments.',accessory:'Accessory discovered',chance:'25% chance. Guaranteed within 5 completed trips to this destination.',complete:'Completed trips',allFound:'You already have this destination’s accessory.',imageError:'The scenery did not load. Destinations still work.',retry:'Retry scenery',care:'Prepare care: hunger, sleepiness and dirt at 60% or less; mood at least 40%.',sleeping:'Wake up before leaving.',egg:'Help your Moki hatch first.',teen:'Available from teen stage.',busy:'Finish the current activity before leaving.',dead:'Receive a new egg to explore.',reward:'Collect discoveries before another trip.',blocked:'Your Moki is already exploring.',mood:'Mood',bag:'Your discoveries wait for you and never expire.',settling:'Arriving home…'}
};
function MapPet({pet}:{pet:Pet}){
 const ref=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  if(pet.stage==='egg')return;
  let active=true;const stage=pet.stage;
  void mokiCanvas.load(mokiVariantArt.get(pet.variant).stageSheets[stage][0]).then(image=>{
   if(!active||!ref.current)return;const ctx=ref.current.getContext('2d');if(!ctx)return;
   ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,64,64);ctx.drawImage(image,0,0,64,64,0,0,64,64);
   mokiAccessories.draw(ctx,stage,'idle',0,pet.player.wardrobe.equipped,0,true,mokiVariantArt.eyes(pet.variant,stage,'idle',0),mokiVariants.family(pet.variant)!=='moki',pet.variant);
  }).catch(()=>{});
  return()=>{active=false;};
 },[pet.variant,pet.stage,pet.player.wardrobe.equipped]);
 return <canvas ref={ref} width={64} height={64} className={styles.pet} aria-label={pet.name} role="img"/>;
}
export function MokiExploration({pet,language,saved,busy=false,now:controlledNow,onBack,onStart,onRecall,onClaim,onTick}:Props){
 const theme=mokiExplorationThemes.get(pet.variant,language),t={...copy[language],...theme.labels},[selected,setSelected]=useState<RouteId>(pet.expedition?.route??pet.expeditionReward?.route??'garden');
 const [clock,setClock]=useState(Date.now),[confirm,setConfirm]=useState(false),[imageError,setImageError]=useState(false),[retry,setRetry]=useState(0);
 const title=useRef<HTMLHeadingElement>(null);
 useEffect(()=>{title.current?.focus({preventScroll:true});},[]);
 useEffect(()=>{setConfirm(false);if(pet.expedition)setSelected(pet.expedition.route);else if(pet.expeditionReward)setSelected(pet.expeditionReward.route);},[pet.expedition?.id,pet.expeditionReward?.id]);
 useEffect(()=>{if(controlledNow!==undefined)return;const tick=()=>{const n=Date.now();setClock(n);if(pet.expedition&&n>=pet.expedition.endsAt)onTick();};tick();const timer=setInterval(tick,1000);return()=>clearInterval(timer);},[pet.expedition?.id,controlledNow,onTick]);
 const now=controlledNow??clock,run=pet.expedition,reward=pet.expeditionReward,route=mokiExpeditions.routes[selected];
 const readiness=mokiExpeditions.readiness(pet,selected),reason=busy&&!run?'busy':readiness.reason;
 const seconds=run?mokiExpeditions.remaining(run,now):0;
 const time=Math.floor(seconds/3600)>0?Math.floor(seconds/3600)+'h '+Math.floor(seconds%3600/60)+'m':Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');
 const progress=run?Math.max(0,Math.min(100,(now-run.startedAt)/(run.endsAt-run.startedAt)*100)):0;
 const routeInfo=theme.routes[selected];
 const needs=theme.family==='robot'?([['hunger','battery',t.food],['fatigue','power',t.rest],['dirt','tool',t.clean]] as const):([['hunger','food',t.food],['fatigue','moon',t.rest],['dirt','drop',t.clean]] as const);
 const owns=pet.player.wardrobe.owned.includes(route.accessory);
 const item=mokiWardrobe.catalog.find(i=>i.id===(reward?.accessory??route.accessory))!;
 const reasonText=reason==='away'?t.blocked:reason?t[reason as 'care'|'egg'|'sleeping'|'teen'|'busy'|'dead'|'reward']:null;
 return <section className={styles.screen} lang={language} data-testid="exploration-map" data-family={theme.family}>
  <header className={styles.header}><Button variant="ghost" className={styles.back} onClick={onBack} aria-label={t.back}><PixelIcon name="back"/></Button><div><h1 ref={title} tabIndex={-1}>{t.title}</h1><p>{run?t.away:reward?t.returned:t.choose}</p></div><span className={styles.wallet}><PixelIcon name="coin" size={17}/><output aria-label={t.coins}>{pet.player.stars}</output></span></header>
  <div className={styles.map}>
   <img key={theme.src+retry} className={styles.landscape} src={theme.src} alt="" onError={()=>setImageError(true)} onLoad={()=>setImageError(false)}/>
   <div className={styles.mist} aria-hidden="true"/><div className={styles.sparkles} aria-hidden="true"><i/><i/><i/><i/></div>
   <div className={styles.home} style={theme.positions.home}>{!run&&pet.stage!=='egg'&&pet.life.diedAt===null&&<MapPet pet={pet}/>}<span>{t.home}</span></div>
   {(['garden','stream'] as const).map(id=><Button key={id} variant="ghost" className={styles.node+' '+styles[id]} style={theme.positions[id]} aria-pressed={selected===id} onClick={()=>{setSelected(id);setConfirm(false);}} data-testid={'route-'+id} data-selected={selected===id}><i className={styles.marker} aria-hidden="true"/><span>{theme.routes[id].name}<small>{id==='garden'?'15 min':'1 h'}{run?.route===id?' · '+t.away:''}</small></span></Button>)}
   <div className={styles.locked+' '+styles.forest} style={theme.positions.forest}><span aria-hidden="true">▣</span><strong>{t.forest}</strong><small>{t.soon}</small></div>
   <div className={styles.locked+' '+styles.ruins} style={theme.positions.ruins}><span aria-hidden="true">▣</span><strong>{t.ruins}</strong><small>{t.soon}</small></div>
   {run&&<div className={styles.traveller+' '+styles[run.route+'Travel']} style={theme.positions[run.route==='garden'?'gardenTravel':'streamTravel']}><MapPet pet={pet}/></div>}
  </div>
  {imageError&&<div className={styles.imageError} role="status">{t.imageError}<Button variant="ghost" className={styles.button} onClick={()=>setRetry(n=>n+1)}>{t.retry}</Button></div>}
  <div className={styles.card}>
   {reward?<div className={styles.reward} data-testid="expedition-reward" role="status">
    <PixelIcon name="sparkle" size={28}/><h2>{reward.complete?t.returned:t.recalled}</h2><p>{theme.routes[reward.route].name}</p><strong className={styles.earned}><PixelIcon name="coin" size={24}/>+{reward.coins} {t.coins}</strong>
    {reward.accessory&&<div className={styles.find}><svg viewBox="0 0 30 20" width={60} height={40} shapeRendering="crispEdges" aria-hidden="true">{mokiAccessories.icon(reward.accessory).map(([x,y,width,height,fill],i)=><rect key={i} {...{x,y,width,height,fill}}/>)}</svg><span>{t.accessory}<strong>{item.name[language]}</strong></span></div>}
    <p>{reward.complete?t.discovery:t.shortTrip}</p><Button className={styles.button+' '+styles.primary} data-testid="claim-expedition" onClick={()=>onClaim(reward.id)}>{t.claim}</Button><small>{t.bag}</small>
   </div>:run?<div data-testid="expedition-active"><div className={styles.titleRow}><h2>{theme.routes[run.route].name}</h2><span>{Math.floor(progress)}%</span></div><p>{seconds>0?t.returns:t.settling} <strong className={styles.timer} role="timer">{seconds>0?time:''}</strong></p><div className={styles.progress} role="progressbar" aria-label={t.away} aria-valuenow={Math.floor(progress)} aria-valuemin={0} aria-valuemax={100}><i style={{width:progress+'%'}}/></div><p className={styles.hint}>{t.outside}</p>
    {confirm?<div className={styles.confirm}><p>{t.recallHelp}</p><Button className={styles.button} onClick={onRecall} data-testid="confirm-recall">{t.confirm}</Button><Button variant="ghost" className={styles.button} onClick={()=>setConfirm(false)}>{t.cancel}</Button></div>:<Button variant="ghost" className={styles.button} data-testid="recall-expedition" onClick={()=>setConfirm(true)}>{t.recall}</Button>}
   </div>:<><div className={styles.titleRow}><h2>{routeInfo.name}</h2><span>{route.minutes===60?'1 h':'15 min'}</span></div><p className={styles.prize}><PixelIcon name="coin" size={17}/>{route.min}–{route.max} {t.coins}</p><p>{routeInfo.description}</p>
    <div className={styles.needs}>{needs.map(([key,icon,label])=><span key={key} data-ready={readiness.needs[key]}><PixelIcon name={icon} size={16}/>{label}<b>{readiness.needs[key]?'✓':'!'}</b></span>)}</div>
    <div className={styles.accessory}><span>{item.name[language]}</span><small>{owns?t.allFound:t.chance}</small><small>{t.complete}: {pet.player.expeditions[selected]}</small></div>
    {reasonText&&<p className={styles.reason} role="status">{reasonText}</p>}<Button className={styles.button+' '+styles.primary} disabled={!readiness.ready||busy||!saved} data-testid="start-expedition" onClick={()=>onStart(selected)}>{t.send}</Button><p className={styles.hint}>{t.outside}</p>
   </>}
  </div><footer className={styles.footer} role={saved?undefined:'alert'}>{saved?t.saved:t.saveError}</footer>
 </section>;
}
