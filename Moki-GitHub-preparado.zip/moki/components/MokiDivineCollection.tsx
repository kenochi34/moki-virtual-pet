import {mokiCanvas} from '../helpers/mokiCanvas';
import React, {useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {Progress} from './Progress';
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem} from './Select';
import {mokiDivine} from '../helpers/mokiDivine';
import {mokiDivineMotion} from '../helpers/mokiDivineMotion';
import {mokiVariantArt} from '../helpers/mokiVariantArt';
import {mokiVariants} from '../helpers/mokiVariants';
import {mokiWorkoutAnimation} from '../helpers/mokiWorkoutAnimation';
import styles from './MokiDivineCollection.module.css';
type Stage='baby'|'teen'|'adult';
type Phase='idle'|'eating'|'bathing'|'sleeping'|'exercising';
const copy={
 es:{title:'Auri · El divino',subtitle:'Un compañero único al final de tu colección.',baby:'Bebé',teen:'Joven',adult:'Adulto',idle:'En calma',eating:'Comiendo',bathing:'Bañándose',sleeping:'Durmiendo',exercising:'Ejercitándose',preview:'Vista previa',action:'Animación',hint:'Cría hasta adultas a todas las variantes de las familias normales para recibir su huevo.',progress:'Criadas hasta adultas',collection:'Ver colección',hide:'Ocultar colección',locked:'Completa la colección para desbloquear',unlocked:'¡Auri está desbloqueado para siempre!',receive:'Recibir huevo de Auri',set:'Incluye un set exclusivo en la tienda: Diadema Alba, Lazo Aurora y Gafas Prisma.',error:'No se pudo cargar la vista previa.',retry:'Reintentar',ready:'Adulta',pending:'Pendiente',loading:'Cargando…'},
 en:{title:'Auri · The divine',subtitle:'One unique companion at the end of your collection.',baby:'Baby',teen:'Teen',adult:'Adult',idle:'At ease',eating:'Eating',bathing:'Bathing',sleeping:'Sleeping',exercising:'Exercising',preview:'Preview',action:'Animation',hint:'Raise every variant in the regular families to adulthood to receive this egg.',progress:'Raised to adulthood',collection:'View collection',hide:'Hide collection',locked:'Complete the collection to unlock',unlocked:'Auri is permanently unlocked!',receive:'Receive Auri’s egg',set:'An exclusive shop set: Dawn circlet, Aurora ribbon and Prism glasses.',error:'The preview could not load.',retry:'Retry',ready:'Adult',pending:'Pending',loading:'Loading…'}
};
type Props={raised:unknown;unlocked:boolean;language:'es'|'en';busy:boolean;onRequest:()=>void};
export function MokiDivineCollection({raised,unlocked,language,busy,onRequest}:Props){
 const t=copy[language],progress=mokiDivine.progress(raised,unlocked);
 const [stage,setStage]=useState<Stage>('adult'),[phase,setPhase]=useState<Phase>('idle'),[expanded,setExpanded]=useState(false);
 const [state,setState]=useState<'loading'|'ready'|'error'>('loading'),[retry,setRetry]=useState(0);
 const canvas=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  let cancelled=false,timer:ReturnType<typeof setTimeout>|undefined,lightTimer:ReturnType<typeof setInterval>|undefined;
  const ctx=canvas.current?.getContext('2d');if(!ctx)return;
  ctx.clearRect(0,0,64,64);setState('loading');
  const art=mokiVariantArt.get('auri'),animation=mokiVariantArt.animation('auri',phase),reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const sources=phase==='exercising'?[art.workout![stage],art.stageSheets[stage][0]]:[art.stageSheets[stage][animation.sheet]];
  Promise.all(sources.map(mokiCanvas.load)).then(images=>{
   if(cancelled)return;setState('ready');let index=0;
   const exerciseSheet=document.createElement('canvas');exerciseSheet.width=images[0].width;exerciseSheet.height=images[0].height;
   if(phase==='exercising')exerciseSheet.getContext('2d')?.drawImage(images[0],0,0);
   const paint=()=>{
    const now=performance.now();ctx.clearRect(0,0,64,64);ctx.imageSmoothingEnabled=false;
    ctx.save();ctx.translate(0,mokiDivineMotion.hover('auri',phase,now,reduced));
    if(phase==='exercising')mokiWorkoutAnimation.draw(ctx,exerciseSheet,images[1],index,reduced,mokiVariantArt.offsets('auri'),true);
    else ctx.drawImage(images[0],animation.frames[index]*64,0,64,64,0,0,64,64);
    mokiDivineMotion.draw(ctx,'auri',now,phase,reduced);ctx.restore();
   };
   const draw=()=>{paint();if(!reduced)timer=setTimeout(()=>{index=(index+1)%animation.frames.length;draw();},animation.times[index]);};
   draw();if(!reduced)lightTimer=setInterval(paint,160);
  }).catch(()=>{if(!cancelled)setState('error');});
  return()=>{cancelled=true;clearTimeout(timer);clearInterval(lightTimer);};
 },[stage,phase,retry]);
 return <section className={styles.card} aria-label={t.title} data-testid="divine-collection">
  <div className={styles.heading}><span className={styles.star} aria-hidden="true">✦</span><div><h3>{t.title}</h3><p>{t.subtitle}</p></div></div>
  <div className={styles.portrait}>
   <span className={styles.preview}>{t.preview} · {t[stage]}</span>
   <canvas ref={canvas} width={64} height={64} role="img" aria-label={`Auri · ${t[stage]} · ${t[phase]}`} className={styles.sprite}/>
   {state==='loading'&&<span className={styles.load} role="status">{t.loading}</span>}
   {state==='error'&&<div className={styles.load} role="status">{t.error}<Button variant="ghost" className={styles.button} onClick={()=>setRetry(x=>x+1)}>{t.retry}</Button></div>}
  </div>
  <div className={styles.stages} aria-label={t.preview}>{(['baby','teen','adult'] as const).map(value=><Button key={value} variant="ghost" className={styles.stage} aria-pressed={stage===value} onClick={()=>setStage(value)}>{t[value]}</Button>)}</div>
  <Select value={phase} onValueChange={value=>setPhase(value as Phase)}><SelectTrigger className={styles.select} aria-label={t.action}><SelectValue/></SelectTrigger><SelectContent>{(['idle','eating','bathing','sleeping','exercising'] as const).map(value=><SelectItem key={value} value={value}>{t[value]}</SelectItem>)}</SelectContent></Select>
  <p className={styles.hint}>{progress.unlocked?t.unlocked:t.hint}</p>
  <div className={styles.count}><span>{t.progress}</span><strong>{progress.count}/{progress.total}</strong></div>
  <Progress className={styles.progress} value={progress.percent} aria-label={t.progress} getValueLabel={()=>`${progress.count}/${progress.total}`}/>
  <Button variant="ghost" className={styles.collection} aria-expanded={expanded} onClick={()=>setExpanded(value=>!value)}>{expanded?t.hide:t.collection}</Button>
  {expanded&&<div className={styles.groups}>{progress.groups.map(group=><div key={group.family}><strong>{mokiVariants.familyNames[group.family][language]}</strong><ul>{group.ids.map(id=>{const done=progress.complete.includes(id);return <li key={id} data-complete={done}><i style={{background:mokiVariants.catalog[id].color}} aria-hidden="true"/><span>{mokiVariants.catalog[id].name[language]}</span><span aria-label={done?t.ready:t.pending}>{done?'✓':'—'}</span></li>;})}</ul></div>)}</div>}
  <p className={styles.hint}>{t.set}</p>
  <Button className={styles.button} disabled={!progress.unlocked||busy} onClick={onRequest} data-testid="receive-divine">{progress.unlocked?t.receive:t.locked}</Button>
 </section>;
}