import React,{useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {PixelIcon} from './PixelIcon';
import {mokiVariants} from '../helpers/mokiVariants';
import {mokiVariantArt} from '../helpers/mokiVariantArt';
import {mokiCanvas} from '../helpers/mokiCanvas';
import styles from './MokiEggPicker.module.css';
type Family=typeof mokiVariants.families[number];
const hints={
 es:{moki:'Bosque encantado',bird:'Entre las copas',alien:'Otro mundo',robot:'Ciudad del futuro',divine:'Refugio celeste'},
 en:{moki:'Enchanted woodland',bird:'Among the treetops',alien:'Another world',robot:'City of the future',divine:'Celestial haven'}
};
function EggArt({family}:{family:Family}){
 const canvas=useRef<HTMLCanvasElement>(null),[ready,setReady]=useState(false);
 useEffect(()=>{
  let active=true;setReady(false);
  const variant=mokiVariants.members(family)[0],egg=mokiVariantArt.get(variant).egg;
  void mokiCanvas.load(egg.src).then(image=>{
   if(!active||!canvas.current)return;
   const ctx=canvas.current.getContext('2d');if(!ctx)return;
   const [x,y,w,h]=egg.frames[0],width=Math.round(w*egg.scale),height=Math.round(h*egg.scale);
   ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,64,64);ctx.drawImage(image,x,y,w,h,Math.round((64-width)/2),variant==='green'?57-height:0,width,height);setReady(true);
  }).catch(()=>{});
  return()=>{active=false;};
 },[family]);
 return <span className={styles.art} aria-hidden="true"><i/>{!ready&&<PixelIcon name="egg" size={44}/>}<canvas ref={canvas} width={64} height={64}/></span>;
}
export function MokiEggPicker({selected,onSelect,language,allowDivine=false,disabled=false}:{selected:Family|null;onSelect:(family:Family)=>void;language:'es'|'en';allowDivine?:boolean;disabled?:boolean}){
 const families=mokiVariants.families.filter(id=>id!=='divine'||allowDivine);
 return <div className={styles.grid} role="group" aria-label={language==='es'?'Familia del huevo':'Egg family'} data-testid="egg-picker">
  {families.map(id=><Button key={id} variant="ghost" className={styles.egg} data-family={id} data-testid={'egg-choice-'+id} aria-pressed={selected===id} disabled={disabled} onClick={()=>onSelect(id)}>
   <span className={styles.check} aria-hidden="true">{selected===id?'✓':'·'}</span><EggArt family={id}/><strong>{mokiVariants.familyNames[id][language]}</strong><small>{hints[language][id]}</small>
  </Button>)}
 </div>;
}
