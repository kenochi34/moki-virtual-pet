import React from 'react';
import {PixelIcon} from './PixelIcon';
import {mokiLife} from '../helpers/mokiLife';
import {mokiPet} from '../helpers/mokiPet';
import {mokiVariants} from '../helpers/mokiVariants';
import styles from './MokiLifeNotice.module.css';
export function MokiLifeNotice({pet,language,memorial=false}:{pet:ReturnType<typeof mokiPet.create>;language:'es'|'en';memorial?:boolean}){
 const health=mokiLife.status(pet.life),es=language==='es',robot=mokiVariants.family(pet.variant)==='robot';
 if(pet.stage==='egg'||!health.critical&&!health.dead)return null;
 if(memorial!==health.dead)return null;
 const names=es?{hunger:robot?'energía muy baja':'hambre',fatigue:robot?'falta de reposo':'falta de sueño',dirt:robot?'falta de mantenimiento':'falta de baño'}:{hunger:robot?'very low energy':'hunger',fatigue:robot?'lack of standby time':'lack of sleep',dirt:robot?'lack of maintenance':'lack of bathing'};
 const cause=health.cause?names[health.cause]:'';
 if(health.dead)return <section className={styles.memorial} data-testid="moki-memorial" aria-label={es?'Recuerdo de Moki':'Moki memorial'}><svg className={styles.tombstone} viewBox="0 0 64 64" role="img" aria-label={es?'Lápida en recuerdo de Moki':'Moki memorial gravestone'} shapeRendering="crispEdges">
 <path d="M8 55h48v5H8zM4 58h56v4H4z" fill="#294b43"/>
 <path d="M24 8h16v4h8v8h4v34H12V20h4v-8h8z" fill="#283347"/>
 <path d="M24 12h16v4h8v34H16V20h4v-4h4z" fill="#7d849e"/>
 <path d="M24 12h16v4H24zM20 16h4v4h-4zM16 20h4v30h-4z" fill="#bec2d0"/>
 <path d="M44 20h4v30h-4zM20 46h24v4H20z" fill="#565e79"/>
 <path d="M24 24h4v-4h4v4h4v-4h4v12h-4v4h-4v4h-4v-4h-4z" fill="#39445b"/>
 <path d="M24 24h4v-4h4v4h4v-4h4v4h-4v4h-4v-4h-4v4h-4z" fill="#ced5d6" opacity=".55"/>
 <path d="M8 50h48v8H8z" fill="#283347"/><path d="M12 50h40v4H12z" fill="#a4aabd"/>
 <path d="M9 48h2v12H9zM53 46h2v14h-2zM5 53h4v3H5zM55 51h4v3h-4z" fill="#6d995a"/>
 <path d="M7 42h6v2h2v6h-2v2H7v-2H5v-6h2z" fill="#e1acde"/><path d="M9 46h2v2H9z" fill="#fce3a0"/>
 <path d="M51 40h6v2h2v6h-2v2h-6v-2h-2v-6h2z" fill="#efcb72"/><path d="M53 44h2v2h-2z" fill="#fff1cf"/>
 </svg><h2>{es?`Aquí descansa ${pet.name}`:`Here rests ${pet.name}`}</h2><p>{es?`48 h en estado crítico por ${cause}.`:`48 h in a critical state due to ${cause}.`}</p></section>;
 return <div className={styles.warning} data-testid="moki-critical" role="status"><PixelIcon name="heart" size={16}/><div><strong>{es?'Necesita cuidados':'Needs care'}</strong><p>{es?`${cause} · ${health.remainingHours} h para atenderlo antes de que muera.`:`${cause} · ${health.remainingHours} h to provide care before it passes away.`}</p><small>{robot?(es?'Energía ≤5%; fatiga o mantenimiento ≥95%.':'Energy ≤5%; fatigue or maintenance ≥95%.'):(es?'Atiende cada necesidad crítica (95% o más).':'Attend to each critical need (95% or higher).')}</small></div></div>;
}