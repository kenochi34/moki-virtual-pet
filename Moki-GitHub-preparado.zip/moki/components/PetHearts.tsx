import React, { useEffect } from 'react';
import { PixelIcon } from './PixelIcon';
import styles from './PetHearts.module.css';

const particles = [
  { x: -35, y: 4, drift: -12, rise: -42, size: 16, delay: 0 },
  { x: -16, y: 9, drift: 7, rise: -56, size: 12, delay: 100 },
  { x: 5, y: 0, drift: -3, rise: -65, size: 20, delay: 220 },
  { x: 30, y: 6, drift: 14, rise: -48, size: 16, delay: 340 },
  { x: -1, y: -9, drift: -7, rise: -73, size: 12, delay: 480 }
];

export function PetHearts({ id, onComplete, center=50 }: { center?:number; id: number; onComplete: (id: number) => void }) {
  useEffect(() => {
    const timer = setTimeout(() => onComplete(id), 3000);
    return () => clearTimeout(timer);
  }, [id, onComplete]);
  return <div className={styles.burst} style={{left:`${center-22}%`}} aria-hidden="true" data-testid="pet-hearts" data-burst={id}>
    {particles.map((particle, index) => <span key={index} className={styles.heart} style={{
      left: `calc(50% + ${particle.x}px)`, top: `${particle.y}px`,
      '--heart-drift': `${particle.drift}px`, '--heart-rise': `${particle.rise}px`, '--heart-delay': `${particle.delay}ms`
    } as React.CSSProperties}><PixelIcon name="heart" size={particle.size} /></span>)}
  </div>;
}