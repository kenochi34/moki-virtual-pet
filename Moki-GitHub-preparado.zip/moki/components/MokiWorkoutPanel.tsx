import React from 'react';
import { Progress } from './Progress';
import { PixelIcon } from './PixelIcon';
import { mokiPet } from '../helpers/mokiPet';
import {mokiFamilyCopy} from '../helpers/mokiFamilyCopy';
import { mokiConfig } from '../helpers/mokiConfig';
import styles from './MokiWorkoutPanel.module.css';
export function MokiWorkoutPanel({pet,now,language}:{pet:ReturnType<typeof mokiPet.create>;now:number;language:'es'|'en'}) {
  const t=mokiFamilyCopy.get(pet.variant,language), active=Boolean(pet.workout);
  const elapsed=pet.workout ? Math.max(0,Math.min(mokiPet.workoutMs,now-pet.workout.startedAt)) : 0;
  const seconds=Math.ceil((mokiPet.workoutMs-elapsed)/1000);
  const rewardAvailable=mokiPet.localDay(now)>pet.player.lastExerciseRewardDay;
  const needsCare=pet.sleeping || pet.hunger>=80 || pet.fatigue>=80;
  const result=pet.lastWorkout;
  return <section className={styles.panel} aria-label={t.exercise} data-testid="workout-panel">
    <div className={styles.vitality}><PixelIcon name="exercise" size={15}/><span>{t.vitality}</span><output data-testid="stat-vitality">{Math.round(pet.vitality)}%</output></div>
    <Progress className={styles.bar} value={pet.vitality} aria-label={t.vitality}/>
    <div className={styles.title}><strong>{t.hops}</strong>{active && <output className={styles.timer} role="timer" aria-label={t.exercise} data-testid="workout-timer">0:{String(seconds).padStart(2,'0')}</output>}</div>
    {active ? <>
      <Progress className={styles.progress} value={elapsed/mokiPet.workoutMs*100} aria-label={t.workoutTrial}/>
      <p>{t.workoutTrial}</p>
    </> : result ? <div role="status" className={styles.result} data-testid="workout-result">
      <strong>{result.complete ? t.workoutComplete : t.workoutStopped}</strong>
      <p>+{Math.round(result.vitalityGained*10)/10} {t.vitality.toLowerCase()}{result.stars>0 && <span className={styles.reward}> · <PixelIcon name="coin" size={13}/> +{result.stars}</span>}</p>
      {!result.complete && <p>{t.workoutKept}</p>}
    </div> : <p>{t.workoutTrial}<br/>{t.workoutBenefits}</p>}
    {!active && needsCare ? <p className={styles.warning}>{pet.sleeping ? t.wakeFirst : t.workoutNeeds}</p> :
      <p className={styles.daily}><PixelIcon name="coin" size={12}/>{rewardAvailable ? t.workoutReward : t.rewardTaken}</p>}
  </section>;
}
