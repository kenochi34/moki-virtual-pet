import React,{useEffect,useRef,useState} from 'react';
import {Button} from './Button';
import {PixelIcon} from './PixelIcon';
import {MokiEggPicker} from './MokiEggPicker';
import {mokiPet} from '../helpers/mokiPet';
import {mokiVariants} from '../helpers/mokiVariants';
import {mokiVariantArt} from '../helpers/mokiVariantArt';
import {mokiCanvas} from '../helpers/mokiCanvas';
import {mokiExplorationThemes} from '../helpers/mokiExplorationThemes';
import styles from './MokiWelcome.module.css';
type Family=typeof mokiVariants.families[number];
type Pet=ReturnType<typeof mokiPet.create>;
const copy={
 es:{tag:'UN PEQUEÑO MUNDO, CONTIGO',title:'Tu próxima pequeña aventura.',intro:'Cuida, juega y descubre. Tu compañero crecerá contigo.',start:'Elegir mi compañero',continue:'Continuar con',guide:'Cómo jugar',local:'Tu aventura se guarda en este dispositivo.',saveError:'No se puede guardar en este dispositivo. Inténtalo de nuevo cuando el guardado esté disponible.',choose:'¿Quién vendrá contigo?',chooseHelp:'Cuatro familias. Cuatro mundos por descubrir.',surprise:'Elige una familia. La variante dentro del huevo será una sorpresa.',pick:'Elige un huevo para continuar',confirm:'Este será mi compañero',back:'Volver',first:'Tu primer huevo es gratis.',care:'Cuida',play:'Juega',explore:'Explora',saved:'TU AVENTURA TE ESPERA'},
 en:{tag:'A LITTLE WORLD, WITH YOU',title:'Your next little adventure.',intro:'Care, play and discover. Your companion will grow with you.',start:'Choose my companion',continue:'Continue with',guide:'How to play',local:'Your adventure is saved on this device.',saveError:'Progress cannot be saved on this device. Try again when saving is available.',choose:'Who’s coming with you?',chooseHelp:'Four families. Four worlds to discover.',surprise:'Choose a family. The variant inside the egg will be a surprise.',pick:'Choose an egg to continue',confirm:'This is my companion',back:'Back',first:'Your first egg is free.',care:'Care',play:'Play',explore:'Explore',saved:'YOUR ADVENTURE AWAITS'}
};
function Companion({pet}:{pet:Pet}){
 const canvas=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  let active=true;const art=mokiVariantArt.get(pet.variant),isEgg=pet.stage==='egg';
  void mokiCanvas.load(isEgg?art.egg.src:art.stageSheets[pet.stage as 'baby'|'teen'|'adult'][0]).then(image=>{
   if(!active||!canvas.current)return;const ctx=canvas.current.getContext('2d');if(!ctx)return;
   ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,64,64);
   if(isEgg){const [x,y,w,h]=art.egg.frames[0],dw=Math.round(w*art.egg.scale),dh=Math.round(h*art.egg.scale);ctx.drawImage(image,x,y,w,h,Math.round((64-dw)/2),pet.variant==='green'?57-dh:0,dw,dh);}
   else ctx.drawImage(image,0,0,64,64,0,0,64,64);
  }).catch(()=>{});
  return()=>{active=false;};
 },[pet.variant,pet.stage]);
 return <canvas ref={canvas} className={styles.companion} width={64} height={64} aria-hidden="true"/>;
}
export function MokiWelcome({pet,language,saved,onContinue,onChoose,onGuide}:{pet:Pet;language:'es'|'en';saved:boolean;onContinue:()=>void;onChoose:(family:Family)=>void;onGuide:()=>void}){
 const t=copy[language],fresh=!pet.player.starterChosen;
 const [screen,setScreen]=useState<'welcome'|'eggs'>('welcome'),[selected,setSelected]=useState<Family|null>(null);
 const title=useRef<HTMLHeadingElement>(null);
 const theme=mokiExplorationThemes.get(pet.variant,language);
 useEffect(()=>{title.current?.focus({preventScroll:true});},[screen]);
 return <section className={styles.screen} lang={language} data-testid="moki-welcome">
  <header className={styles.brand}><span>MOKI</span><small>BETA</small></header>
  {screen==='welcome'||!fresh?<><div className={styles.landscape}><img src={theme.src} alt="" draggable={false}/><div className={styles.shade}/><span className={styles.kicker}>{fresh?t.tag:t.saved}</span><Companion pet={pet}/><i className={styles.ground}/></div>
   <div className={styles.body}><h1 ref={title} tabIndex={-1}>{t.title}</h1><p>{t.intro}</p><div className={styles.features}><span><PixelIcon name="heart" size={18}/>{t.care}</span><span><PixelIcon name="game" size={18}/>{t.play}</span><span><PixelIcon name="sparkle" size={18}/>{t.explore}</span></div>
    <Button className={styles.primary} data-testid="welcome-continue" onClick={()=>fresh?setScreen('eggs'):onContinue()}>{fresh?t.start:t.continue+' '+pet.name}<PixelIcon name={fresh?'egg':'heart'} size={20}/></Button>
    <Button variant="ghost" className={styles.secondary} onClick={onGuide}>{t.guide}</Button><small className={styles.local}>{t.local}</small>
   </div></>:<div className={styles.body+' '+styles.selection}>
    <h1 ref={title} tabIndex={-1}>{t.choose}</h1><p>{t.chooseHelp}</p>
    <MokiEggPicker selected={selected} onSelect={setSelected} language={language}/>
    <p className={styles.surprise}>{t.surprise}</p><small className={styles.free}>{t.first}</small>
    {!saved&&<p role="alert" className={styles.error}>{t.saveError}</p>}
    <Button className={styles.primary} disabled={!selected||!saved} data-testid="confirm-starter" onClick={()=>{if(selected)onChoose(selected);}}>{selected?t.confirm:t.pick}</Button>
    <Button variant="ghost" className={styles.secondary} onClick={()=>setScreen('welcome')}>{t.back}</Button>
   </div>}
 </section>;
}
