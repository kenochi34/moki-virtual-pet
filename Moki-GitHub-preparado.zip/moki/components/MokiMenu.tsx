import {MokiEggPicker} from './MokiEggPicker';
import {MokiLifeNotice} from './MokiLifeNotice';
import {MokiNotifications} from './MokiNotifications';
import type {useMokiNotifications} from '../helpers/useMokiNotifications';
import {mokiDivine} from '../helpers/mokiDivine';
import {MokiDivineCollection} from './MokiDivineCollection';
import React, { useState } from 'react';
import { Button } from './Button';
import { Input } from './Input';
import { Switch } from './Switch';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from './Select';
import { Dialog, DialogTrigger, DialogContent, DialogTitle, DialogDescription, DialogClose } from './Dialog';
import { PixelIcon } from './PixelIcon';
import { mokiPet } from '../helpers/mokiPet';
import {mokiFamilyCopy} from '../helpers/mokiFamilyCopy';
import { mokiConfig } from '../helpers/mokiConfig';
import styles from './MokiMenu.module.css';
import {mokiVariants} from '../helpers/mokiVariants';
const copy = {
  es: { menu:'Menú', info:'Mi Moki', settings:'Ajustes', intro:'Un pequeño compañero, a tu manera.', name:'Nombre', rename:'Guardar nombre', renamed:'Nombre guardado.', green:'Moki verde', stage:'Etapa', age:'Edad', born:'Nacimiento', waiting:'Todavía dentro del huevo', sound:'Sonidos retro', soundHelp:'Efectos retro y una voz propia para cada Moki al cuidarlo y acariciarlo. Sin música.', test:'Escuchar a mi Moki', language:'Idioma', auto:'Automático · sistema', lights:'Luciérnagas', lightsHelp:'Luces decorativas del cuarto.', adoption:'Dar en adopción', replaceEgg:'Cambiar de huevo', confirmTitle:'¿Empezar con otro Moki?', confirm:'Confirmar y recibir huevo', cancel:'Quedarme con mi Moki', warning:'Tu Moki saldrá del cuarto y su nombre y progreso actuales se perderán. Esta acción no se puede deshacer.', eggWarning:'Se sustituirá este huevo y se perderán sus grietas y nombre.', trial:'Recibirás un huevo aleatorio. Elige la familia. Sus variantes no se repiten hasta haber recibido las tres.', local:'Tu Moki y estos ajustes se guardan en este dispositivo.', busy:'Espera a que termine su animación para cambiar de Moki.', close:'Volver al cuarto', species:'Raza', invalid:'Escribe un nombre de 1 a 18 caracteres.', until:'Para la siguiente etapa', max:'¡Ya es adulto!', error:'No se pudo guardar. El cambio durará solo esta sesión.' },
  en: { menu:'Menu', info:'My Moki', settings:'Settings', intro:'A little companion, your way.', name:'Name', rename:'Save name', renamed:'Name saved.', green:'Green Moki', stage:'Stage', age:'Age', born:'Hatched', waiting:'Still inside the egg', sound:'Retro sounds', soundHelp:'Retro effects and a distinct voice for each Moki during care and petting. No music.', test:'Hear my Moki', language:'Language', auto:'Automatic · system', lights:'Fireflies', lightsHelp:'Decorative lights in the room.', adoption:'Give up for adoption', replaceEgg:'Change egg', confirmTitle:'Start with another Moki?', confirm:'Confirm and receive egg', cancel:'Keep my Moki', warning:'Your Moki will leave the room and its current name and progress will be lost. This cannot be undone.', eggWarning:'This egg will be replaced and its cracks and name will be lost.', trial:'Receive a random egg. Choose a family. Its variants will not repeat until you have received all three.', local:'Your Moki and settings are saved on this device.', busy:'Wait for the animation to finish before changing Moki.', close:'Back to the room', species:'Species', invalid:'Enter a name with 1–18 characters.', until:'For the next stage', max:'Already an adult!', error:'Could not save. The change will last only for this session.' }
};
type Props = {
  notifications:ReturnType<typeof useMokiNotifications>;
  pet: ReturnType<typeof mokiPet.create>; saved: boolean; busy: boolean; language:'es'|'en';
  languageChoice:'auto'|'es'|'en'; onLanguage:(value:'auto'|'es'|'en')=>void;
  onGuide:()=>void; sound:boolean; onSound:(value:boolean)=>void; onPreview:()=>void; onClickSound:()=>void;
  magic:boolean; onMagic:(value:boolean)=>void; onRename:(name:string)=>void; onNewEgg:(family:typeof mokiVariants.families[number])=>boolean;
};
export function MokiMenu(props: Props) {
  const {pet, language} = props, t=copy[language], labels=mokiFamilyCopy.get(pet.variant,language);
  const [open,setOpen]=useState(false);
  const [tab,setTab]=useState<'info'|'settings'>('info');
  const [confirm,setConfirm]=useState(false);
  const [nextFamily,setNextFamily]=useState<typeof mokiVariants.families[number]>(()=>mokiVariants.family(pet.variant));
  const [draft,setDraft]=useState(pet.name);
  const [notice,setNotice]=useState<'renamed'|'invalid'|null>(null);
  const evolution=mokiPet.progress(pet), egg=pet.stage==='egg',dead=pet.life.diedAt!==null;
  const variant=mokiVariants.restore(pet.variant),family=mokiVariants.catalog[variant];
  const group=mokiVariants.family(variant),members=mokiVariants.members(group);
  const received=mokiVariants.history(pet.player.variants,variant).filter(id=>members.includes(id));
  const raised=mokiVariants.history(pet.player.raised).filter(id=>members.includes(id));
  const divine=mokiDivine.progress(pet.player.raised,pet.player.divineUnlocked);
  const robot=group==='robot',adoption=mokiPet.adoptionQuote(pet);
  const needs=[[robot?'battery':'food',labels.hunger,robot?100-pet.hunger:pet.hunger],[robot?'power':'moon',labels.fatigue,pet.fatigue],[robot?'tool':'drop',labels.dirt,pet.dirt],['heart',labels.mood,pet.mood],['exercise',labels.vitality,pet.vitality]] as const;
  function changeOpen(value:boolean) {
    setOpen(value); setConfirm(false); setNotice(null);
    if(value) { setDraft(pet.name); setTab('info'); setNextFamily(mokiVariants.family(pet.variant)); }
  }
  function saveName() {
    if(!mokiPet.cleanName(draft)) { setNotice('invalid'); return; }
    props.onRename(draft); setDraft(mokiPet.cleanName(draft)); setNotice('renamed');
  }
  return <Dialog open={open} onOpenChange={changeOpen}>
    <DialogTrigger asChild><Button variant="ghost" className={styles.trigger} data-testid="moki-menu" aria-label={t.menu}><PixelIcon name="menu" size={16}/><span>{t.menu}</span></Button></DialogTrigger>
    <DialogContent closeLabel={t.close} className={styles.panel} lang={language} data-testid="moki-menu-panel" onClickCapture={event=>{
      const button=(event.target as Element).closest('button');
      if(button && !button.disabled && !button.closest('[data-no-click-sound]')) props.onClickSound();
    }}>
      <DialogTitle className={styles.title}>{confirm ? t.confirmTitle : t.menu}</DialogTitle>
      <DialogDescription className={styles.subtitle}>{confirm ? nextFamily==='divine'?(language==='es'?'Recibirás el huevo único de Auri. Tu colección se conserva.':'Receive Auri’s unique egg. Your collection is kept.'):t.trial : t.intro}</DialogDescription>
      {confirm ? <div className={styles.confirm}>
        <PixelIcon name="egg" size={40}/>
        <p>{dead?(language==='es'?'Recibirás un nuevo compañero. Tus monedas y accesorios se conservan.':'Receive a new companion. Your coins and accessories are kept.'):egg ? t.eggWarning : t.warning}</p><p className={styles.hint}>{language==='es'?'Conservas tu colección y las monedas restantes. El nuevo Moki llega sin accesorios puestos.':'You keep your collection and remaining coins. Your new Moki arrives without accessories equipped.'}</p>
        <strong>{pet.name}</strong>
        <MokiEggPicker selected={nextFamily} onSelect={setNextFamily} language={language} allowDivine={divine.unlocked}/>
        <div className={styles.adoptionCost} data-testid="adoption-cost">
          <div><span>{language==='es'?'Costo de adopción':'Adoption cost'}</span><strong><PixelIcon name="coin" size={18}/>{adoption.cost===0?(language==='es'?'Gratis':'Free'):adoption.cost}</strong></div>
          <div><span>{language==='es'?'Tus monedas':'Your coins'}</span><span>{pet.player.stars}</span></div>
          <small>{dead?(language==='es'?'Un nuevo compañero tras un fallecimiento es gratis.':'A new companion after a loss is free.'):language==='es'?`Primeros ${mokiPet.freeAdoptions} cambios gratis; después, ${mokiPet.adoptionCost} monedas. Gratis restantes: ${adoption.freeLeft}.`:`First ${mokiPet.freeAdoptions} changes free; then ${mokiPet.adoptionCost} coins. Free changes left: ${adoption.freeLeft}.`}</small>
        </div>
        {!adoption.affordable&&<p className={styles.hint} role="status">{language==='es'?`Te faltan ${adoption.cost-pet.player.stars} monedas. Puedes ganarlas en Play.`:`You need ${adoption.cost-pet.player.stars} more coins. Earn them in Play.`}</p>}
        {!props.saved&&<p role="alert" className={styles.hint}>{language==='es'?'No se pudo guardar. Tu Moki se queda contigo hasta que el guardado funcione.':'Could not save. Your Moki stays with you until saving is available.'}</p>}
        <Button className={styles.button} onClick={()=>setConfirm(false)} autoFocus>{t.cancel}</Button>
        <Button className={styles.danger} data-testid="confirm-adoption" disabled={props.busy||!props.saved||!adoption.affordable||nextFamily==='divine'&&!divine.unlocked} onClick={()=>{if(props.onNewEgg(nextFamily))changeOpen(false);}}>{t.confirm}{adoption.cost>0?' · '+adoption.cost+' '+(language==='es'?'monedas':'coins'):''}</Button>
      </div> : <>
        <nav className={styles.tabs} aria-label={t.menu}>
          <Button variant="ghost" className={styles.tab} aria-pressed={tab==='info'} onClick={()=>setTab('info')}>{t.info}</Button>
          <Button variant="ghost" className={styles.tab} data-testid="menu-settings" aria-pressed={tab==='settings'} onClick={()=>setTab('settings')}>{t.settings}</Button>
        </nav>
        {tab==='info' ? <div className={styles.stack}>
          <div className={styles.identity}><PixelIcon name={egg ? 'egg' : 'happy'} size={32}/><div><strong data-testid="moki-name">{pet.name}</strong><span>{family.name[language]} · {dead?(language==='es'?'En recuerdo':'In memory'):labels[pet.stage]}</span></div></div>
          <div className={styles.familyCollection} data-testid="variant-history">
            <div className={styles.collectionHeading}><span>{mokiVariants.familyNames[group][language]} · {language==='es'?'recibidas':'received'}</span><strong>{received.length}/{members.length}</strong></div>
            <div className={styles.familyRow}>{members.map(id=><div key={id} className={styles.familyTile} data-received={received.includes(id)}><i style={{background:mokiVariants.catalog[id].color}}/><span>{mokiVariants.catalog[id].name[language].replace('Moki ','').replace(' Moki','').replace('Ave ','').replace(' Bird','')}</span><b aria-label={received.includes(id)?language==='es'?'Recibida':'Received':language==='es'?'Pendiente':'Not received'}>{received.includes(id)?'✓':'·'}</b></div>)}</div>
            <p className={styles.hint}>{group==='divine'?(language==='es'?'Auri es una mascota única; no tiene variantes.':'Auri is a unique pet with no variants.'):received.length<members.length?(language==='es'?'Los próximos huevos serán de las variantes que te faltan.':'Your next eggs will be the variants you have not received.'):(language==='es'?'¡Ya recibiste las tres! Los próximos huevos serán aleatorios.':'You have received all three! Your next eggs will be random.')}</p><p className={styles.hint} data-testid="raised-history">{language==='es'?'Criadas hasta adultas':'Raised to adulthood'}: {raised.length}/{members.length}</p>
          </div>
          <MokiDivineCollection raised={pet.player.raised} unlocked={divine.unlocked} language={language} busy={props.busy} onRequest={()=>{setNextFamily('divine');setConfirm(true);}}/>
          <div className={styles.rename}>
            <label htmlFor="moki-name-input">{t.name}</label>
            <Input id="moki-name-input" className={styles.input} value={draft} maxLength={18} autoComplete="off" onChange={e=>{setDraft(e.target.value);setNotice(null);}} onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();saveName();}}}/>
            <Button className={styles.button} onClick={saveName}>{t.rename}</Button>
            {notice && <p className={styles.notice} role="status">{notice==='renamed' && !props.saved ? t.error : t[notice]}</p>}
          </div>
          <dl className={styles.facts}><div><dt>{labels.stars}</dt><dd>{pet.player.stars}</dd></div><div><dt>{t.species}</dt><dd>{mokiVariants.familyNames[group][language]}</dd></div><div><dt>{t.stage}</dt><dd>{labels[pet.stage]}</dd></div>{!egg && <><div><dt>{t.age}</dt><dd>{evolution.ageHours} h</dd></div><div><dt>{t.born}</dt><dd>{new Date(pet.bornAt).toLocaleDateString(language)}</dd></div></>}</dl>
          {dead ? <p className={styles.hint}>{language==='es'?'Esta mascota ha fallecido. Puedes recibir un nuevo huevo y conservar tu colección.':'This pet has passed away. You can receive a new egg and keep your collection.'}</p> : egg ? <p className={styles.hint}>{t.waiting}. {labels.hatchHelp}</p> : <>
            <div className={styles.stats}>{needs.map(([icon,label,value])=><div key={icon}><PixelIcon name={icon}/><span>{label}</span><strong>{Math.round(value)}%</strong></div>)}</div>
            <MokiLifeNotice pet={pet} language={language}/><div className={styles.growth}><strong>{labels.evolution} · {evolution.percent}%</strong><p>{pet.stage==='adult' ? t.max : `${labels[pet.stage]} → ${labels[evolution.next as 'teen'|'adult']}`}</p>{pet.stage!=='adult' && <><p>{labels.ageRequirement}: {evolution.ageHours}/{evolution.targetHours} h · {labels.careRequirement}: {evolution.care}/{evolution.targetCare}</p><p>{labels.mood}: {Math.round(pet.mood)}% / 50% {evolution.moodReady ? '✓' : ''}</p></>}</div>
          </>}
          <Button variant="ghost" className={styles.adoption} data-testid="adoption" disabled={props.busy} onClick={()=>setConfirm(true)}>{dead?(language==='es'?'Recibir un nuevo huevo':'Receive a new egg'):egg ? t.replaceEgg : t.adoption}</Button>
          {props.busy && <p className={styles.hint}>{pet.expedition||pet.expeditionReward?(language==='es'?'Regresa de la expedición y recoge tus hallazgos antes de cambiar de Moki.':'Return from the expedition and collect discoveries before changing Moki.'):t.busy}</p>}
        </div> : <div className={styles.stack}>
          <MokiNotifications notifications={props.notifications} language={language}/>
          <div className={styles.setting} data-no-click-sound><div><label htmlFor="moki-sound"><PixelIcon name={props.sound ? 'sound' : 'muted'}/>{t.sound}</label><p>{t.soundHelp}</p></div><Switch id="moki-sound" className={styles.toggle} data-testid="sound-toggle" checked={props.sound} onCheckedChange={props.onSound}/></div>
          <Button className={styles.button} data-no-click-sound disabled={!props.sound} onClick={props.onPreview}>{t.test}</Button>
          <div className={styles.language}><label htmlFor="moki-language">{t.language}</label><Select value={props.languageChoice} onValueChange={value=>props.onLanguage(value as Props['languageChoice'])}><SelectTrigger id="moki-language" className={styles.input}><SelectValue/></SelectTrigger><SelectContent><SelectItem value="auto">{t.auto}</SelectItem><SelectItem value="es">Español</SelectItem><SelectItem value="en">English</SelectItem></SelectContent></Select></div>
          <div className={styles.setting}><div><label htmlFor="moki-lights"><PixelIcon name="sparkle"/>{labels.fireflies}</label><p>{labels.firefliesHelp}</p></div><Switch id="moki-lights" className={styles.toggle} checked={props.magic} onCheckedChange={props.onMagic}/></div>
          <Button className={styles.button} data-testid="how-to-play" onClick={()=>{changeOpen(false);props.onGuide();}}>{language==='es'?'Cómo jugar':'How to play'}</Button>
          <p className={styles.hint}>{labels.autoHelp}</p>
        </div>}
        <p className={styles.local}>{props.saved ? t.local : t.error}<br/><span>Moki · v0.2 beta</span></p>
        <DialogClose asChild><Button className={styles.button}>{t.close}</Button></DialogClose>
      </>}
    </DialogContent>
  </Dialog>;
}
