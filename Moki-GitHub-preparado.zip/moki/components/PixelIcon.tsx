import React from 'react';
import styles from './PixelIcon.module.css';
const paths = {
  battery:'M1 4h12v2h2v5h-2v2H1zM3 6v5h2V6zM6 6v5h2V6zM9 6v5h2V6z',
  tool:'M10 1h4v2h-3v3h3V3h2v5h-2v2h-4L5 15H1v-4l6-5V3h3z',
  power:'M7 0h2v8H7zM3 3h2v2H3v7h2v2h6v-2h2V5h-2V3h2v2h2v8h-2v2H3v-2H1V5h2z',
  game:'M3 4h10v1h2v2h1v6h-1v1h-3v-2H4v2H1v-1H0V7h1V5h2zM3 6v2H1v2h2v2h2v-2h2V8H5V6zM11 7h2v2h-2zM9 10h2v2H9z',
  exercise: 'M0 6h2V3h3v4h6V3h3v3h2v4h-2v3h-3V9H5v4H2v-3H0z',
  coin: 'M5 0h6v1h2v2h2v2h1v6h-1v2h-2v2h-2v1H5v-1H3v-2H1v-2H0V5h1V3h2V1h2z',
  stop: 'M3 3h10v10H3z',
  menu: 'M2 3h12v2H2zM2 7h12v2H2zM2 11h12v2H2z',
  sound: 'M1 6h3V4h2V2h2v12H6v-2H4v-2H1zM10 5h2v6h-2zM12 2h2v2h1v8h-1v2h-2v-2h1V4h-1z',
  muted: 'M1 6h3V4h2V2h2v12H6v-2H4v-2H1zM10 5h2v2h1V5h2v2h-2v2h2v2h-2V9h-1v2h-2V9h2V7h-2z',
  food: 'M8 1h2v2H8zM6 3h2v2H6zM3 5h3v1h4V5h3v2h1v5h-1v2h-3v-1H6v1H3v-2H2V7h1z',
  moon: 'M6 1h4v2H6v2H4v6h2v2h6v-2h2v3h-2v1H5v-1H3v-2H2V5h1V3h3z',
  sun: 'M7 0h2v3H7zM7 13h2v3H7zM0 7h3v2H0zM13 7h3v2h-3zM2 2h2v2H2zM12 2h2v2h-2zM2 12h2v2H2zM12 12h2v2h-2zM6 4h4v1h1v1h1v4h-1v1h-1v1H6v-1H5v-1H4V6h1V5h1z',
  drop: 'M7 1h2v2h1v2h2v2h1v5h-1v2h-2v1H6v-1H4v-2H3V7h1V5h2V3h1z',
  heart: 'M2 3h4v1h1v1h2V4h1V3h4v1h1v5h-1v1h-1v1h-1v1h-1v1h-1v1H9v1H7v-1H6v-1H5v-1H4v-1H3v-1H2V9H1V4h1z',
  sleep: 'M1 5h2v5h10V6h2v9h-2v-3H3v3H1zM4 6h3v3H4zM8 7h4v2H8zM8 1h6v1l-3 2h3v1H8V4l3-2H8z',
  bath: 'M1 9h14v4h-2v2h-2v-1H5v1H3v-2H1zM2 2h2V1h5v1h1v3H7V3H4v5H2zM7 6h1v2H7zM10 6h1v2h-1zM13 6h1v2h-1z',
  back: 'M6 2h2v2H6v2H4v1h11v2H4v1h2v2h2v2H6v-2H4v-2H2V6h2V4h2z',
  sparkle: 'M7 1h2v4h2v2h4v2h-4v2H9v4H7v-4H5V9H1V7h4V5h2zM12 1h2v2h-2zM1 12h2v2H1z',
  happy: 'M3 2h10v1h1v1h1v8h-1v1h-1v1H3v-1H2v-1H1V4h1V3h1zM4 4v3h2V4zM10 4v3h2V4zM4 9v2h2v1h4v-1h2V9h-2v1H6V9z',
  neutral: 'M3 2h10v1h1v1h1v8h-1v1h-1v1H3v-1H2v-1H1V4h1V3h1zM4 4v3h2V4zM10 4v3h2V4zM5 10v2h6v-2z',
  sad: 'M3 2h10v1h1v1h1v8h-1v1h-1v1H3v-1H2v-1H1V4h1V3h1zM4 4v3h2V4zM10 4v3h2V4zM4 10v2h2v-1h4v1h2v-2h-2V9H6v1z',
  egg: 'M6 1h4v1h2v2h1v2h1v6h-1v2h-2v1H5v-1H3v-2H2V6h1V4h1V2h2zM6 3v2H5v3h2V5h2V3z',
  warm: 'M2 15V9h2v2h2V7H5V4h2v3h2V4H8V1h2v3h1v4h2v3h1V8h1v6h-2v1z',
};
const colors: Record<keyof typeof paths, string> = {
  battery:'var(--icon-leaf)',tool:'var(--icon-warm)',power:'var(--icon-water)',
  game:'var(--icon-heart)',
  exercise: 'var(--icon-leaf)', coin:'var(--icon-sun)', stop:'var(--icon-warm)',
  menu: 'var(--icon-highlight)', sound: 'var(--icon-water)', muted: 'var(--icon-sleep)',
  food: 'var(--icon-food)', moon: 'var(--icon-sleep)', sun: 'var(--icon-sun)',
  drop: 'var(--icon-water)', heart: 'var(--icon-heart)', sleep: 'var(--icon-sleep)',
  bath: 'var(--icon-water)', back: 'var(--icon-highlight)', sparkle: 'var(--icon-sun)',
  happy: 'var(--icon-sun)', neutral: 'var(--icon-warm)', sad: 'var(--icon-sleep)',
  egg: 'var(--icon-leaf)', warm: 'var(--icon-warm)'
};
export function PixelIcon({ name, size = 18, className }: { name: keyof typeof paths; size?: number; className?: string }) {
  return <svg viewBox="0 0 16 16" width={size} height={size} className={`${styles.icon} ${className || ''}`} style={{ color: colors[name] }} fill="currentColor" shapeRendering="crispEdges" aria-hidden="true" data-icon={name}>
    <path d={paths[name]} fillRule="evenodd" />
    {name === 'coin' && <><path d="M5 2h6v1h2v2h1v6h-1v2h-2v1H5v-1H3v-2H2V5h1V3h2z" fill="#c78b36"/><path d="M7 3h2v3h4v2h-2v2h1v2H9v-2H7v2H4v-2h1V8H3V6h4z" fill="var(--icon-highlight)"/></>}
    {name === 'food' && <path d="M8 1h2v2H8zM6 3h2v2H6z" fill="var(--icon-leaf)" />}
    {name === 'heart' && <path d="M3 4h2v1H3zM2 5h1v2H2z" fill="var(--icon-highlight)" />}
    {name === 'drop' && <path d="M6 6h1v2H6zM5 8h1v3H5z" fill="var(--icon-highlight)" />}
    {name === 'egg' && <path d="M9 5h2v2H9zM5 10h2v2H5z" fill="var(--icon-highlight)" />}
  </svg>;
}
