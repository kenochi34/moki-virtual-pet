import React from 'react';
import { PixelIcon } from './PixelIcon';
import { mokiCondition } from '../helpers/mokiCondition';
import styles from './MokiConditionEffects.module.css';
type Props = {
  stage:'egg'|'baby'|'teen'|'adult'; dirt:number; hunger:number; mood:number;
  phase:string; quiet?:boolean; robot?:boolean;
};
export function MokiConditionEffects({stage,dirt,hunger,mood,phase,quiet=false,robot=false}:Props) {
  const condition=mokiCondition.read({stage,dirt,hunger,mood});
  if(stage==='egg') return null;
  const idle=phase==='idle';
  const washing=phase==='bathing';
  const tear=stage==='baby' ? [35,43] : stage==='teen' ? [30,35] : [30,33];
  return <svg className={styles.effects} viewBox="0 0 64 64" aria-hidden="true" shapeRendering="crispEdges" data-testid="condition-effects" data-dirty={condition.dirty} data-hungry={condition.hungry} data-sad={condition.sad}>
    {condition.dirty && !washing && <g data-testid="dirt-effect" className={styles.dirt}>
      {(condition.veryDirty ? [0,1,2] : [0,1]).map(i=><g key={i} transform={`translate(${i===0?6:i===1?51:45} ${i===0?43:i===1?45:32})`}>
        <g className={styles.wisp} style={{animationDelay:`${-i*1.1}s`}}>
          <path d="M2 0h3v1h2v3H5v2H1V4H0V2h2z" fill="#867152"/>
          <path d="M2 1h2v1H2zM1 3h3v1H1z" fill="#baaa85"/>
        </g>
      </g>)}
      {condition.veryDirty && !robot && <g className={styles.fly}><path d="M0 1h2v2H0zM3 0h2v2H3z" fill="#c1d6c6"/><path d="M2 2h2v2H2z" fill="#092b3c"/></g>}
    </g>}
    {condition.hungry && idle && !quiet && <g className={`${styles.thought} ${condition.veryHungry ? styles.urgent : ''}`} data-testid="hunger-effect">
      <path d="M43 0h18v2h2v15h-2v2H43v-2h-2V2h2z" fill="#092b3c"/>
      <path d="M44 2h16v2h1v11h-1v2H44v-2h-1V4h1z" fill="#fff1ce"/>
      <g transform="translate(46 3)"><PixelIcon name={robot?"battery":"food"} size={12}/></g>
      <path d="M42 20h3v3h-3zM39 25h2v2h-2z" fill="#fff1ce"/>
    </g>}
    {condition.sad && idle && !robot && <g transform={`translate(${tear[0]} ${tear[1]})`} data-testid="sad-effect">
      <g className={`${styles.tear} ${condition.verySad ? styles.moreSad : ''}`}>
        <path d="M1 0h1v2h1v3H0V2h1z" fill="#6ed5fa"/>
        <path d="M1 2h1v1H1z" fill="#fff1ce"/>
      </g>
    </g>}
  </svg>;
}
