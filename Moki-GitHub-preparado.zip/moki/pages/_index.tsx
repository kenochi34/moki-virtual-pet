import {mokiVoices} from '../helpers/mokiVoices';
import {MokiExploration} from '../components/MokiExploration';
import {mokiExplorationThemes} from '../helpers/mokiExplorationThemes';
import {mokiCanvas} from '../helpers/mokiCanvas';
import {MokiLifeNotice} from '../components/MokiLifeNotice';
import {useMokiNotifications} from '../helpers/useMokiNotifications';
import {MokiGuide} from '../components/MokiGuide';
import {MokiWelcome} from '../components/MokiWelcome';
import {mokiRelease} from '../helpers/mokiRelease';
import {mokiDivineMotion} from '../helpers/mokiDivineMotion';
import React, { useMemo, useCallback, useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '../components/Button';
import { Progress } from '../components/Progress';
import { MokiChallenges } from '../components/MokiChallenges';
import { PixelIcon } from '../components/PixelIcon';
import { MokiConditionEffects } from '../components/MokiConditionEffects';
import { mokiCondition } from '../helpers/mokiCondition';
import { mokiWorkoutAnimation } from '../helpers/mokiWorkoutAnimation';
import { PetHearts } from '../components/PetHearts';
import { MokiWorkoutPanel } from '../components/MokiWorkoutPanel';
import { MokiMenu } from '../components/MokiMenu';
import {MokiDock} from '../components/MokiDock';
import {MokiScene} from '../components/MokiScene';
import {mokiRobotMotion} from '../helpers/mokiRobotMotion';
import {mokiFamilyCopy} from '../helpers/mokiFamilyCopy';
import { MokiCloset } from '../components/MokiCloset';
import { MokiGames } from '../components/MokiGames';
import { mokiAccessories } from '../helpers/mokiAccessories';
import { useMokiSound } from '../helpers/useMokiSound';
import { EggShellBurst } from '../components/EggShellBurst';
import { mokiConfig as config } from '../helpers/mokiConfig';
import { mokiPet } from '../helpers/mokiPet';
import { mokiVariants } from '../helpers/mokiVariants';
import { mokiAlienMotion } from '../helpers/mokiAlienMotion';
import { mokiVariantArt } from '../helpers/mokiVariantArt';
import { useMokiPet } from '../helpers/useMokiPet';
import styles from './_index.module.css';

type Phase = keyof typeof config.animations;
type Message = keyof typeof config.copy.es;
type Icon = React.ComponentProps<typeof PixelIcon>['name'];
const fireflies = [[16,39,0],[72,30,1.2],[56,47,2.4],[28,62,.7],[82,58,1.8],[43,24,3],[66,78,.4],[20,81,2.1]];

export default function MokiRoom() {
  const [environment, setEnvironment] = useState(() => config.environment());
  const { chooseStarter, startExpedition, recallExpedition, claimExpedition, claimChallenges, pet, commit, saved, rename, newEgg, buyAccessory, equipAccessory, startGame, catchFirefly, stopGame, startMemory, pauseMemory, flipMemory } = useMokiPet();
  const sound = useMokiSound();
  const [startOpen,setStartOpen]=useState(true);
  const showWelcome=startOpen||!pet.player.starterChosen;
  const [guideOpen,setGuideOpen]=useState(false);
  const changeGuide=useCallback((open:boolean)=>{setGuideOpen(open);if(!open)try{localStorage.setItem(mokiRelease.welcomeKey,'seen');}catch{}},[]);
  const variant=mokiVariants.restore(pet.variant);
  const art=mokiVariantArt.get(variant);
  const family=mokiVariants.catalog[variant];
  const isBird=family.family==='bird';
  const isAlien=family.family==='alien';
  const isRobot=family.family==='robot';
  const isDivine=family.family==='divine';
  const wrappedFit=isBird||isAlien||isRobot||isDivine;
  const lightSeed=useMemo(()=>Math.floor(Math.random()*4294967296),[variant,pet.bornAt]);
  const [dockStep,setDockStep]=useState(0);
  const [lessMotion]=useState(()=>typeof window!=='undefined'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const loadedVariant=useRef<string|null>(null);
  const [languageChoice, setLanguageChoice] = useState<'auto'|'es'|'en'>(() => {
    try { const value=localStorage.getItem('moki.language.v1'); return value==='es'||value==='en' ? value : 'auto'; } catch { return 'auto'; }
  });
  const [magic, setMagic] = useState(() => { try { return localStorage.getItem('moki.fireflies.v1') !== 'false'; } catch { return true; } });
  const [place, setPlace] = useState<'room' | 'bath' | 'gym'>(()=>pet.workout ? 'gym' : 'room');
  const [phase, setPhase] = useState<Phase>(() => pet.workout ? 'exercising' : pet.sleeping ? 'sleeping' : 'idle');
  const [bubble, setBubble] = useState<Message | null>(null);
  const [sheets, setSheets] = useState<HTMLImageElement[] | null>(null);
  const [workoutSheets,setWorkoutSheets]=useState<ReturnType<typeof mokiWorkoutAnimation.prepare>|null>(null);
  const [workoutAssetError,setWorkoutAssetError]=useState(false);
  const [assetError, setAssetError] = useState(false);
  const [gymReady,setGymReady]=useState(false);
  const [workoutNow,setWorkoutNow]=useState(Date.now);
  const gymAction=useRef<HTMLButtonElement>(null);
    const returnGymFocus=useRef(false);
  const previousWorkout=useRef<number|null>(null);
  const [showGrowth, setShowGrowth] = useState(false);
  const [closetOpen,setClosetOpen]=useState(false);
  const [explorationOpen,setExplorationOpen]=useState(()=>typeof window!=='undefined'&&window.location.hash==='#explore');
  const exploreFromHub=useRef(false),hubHandoff=useRef(false);
  const [gameOpen,setGameOpen]=useState(()=>Boolean(pet.minigame || pet.memory?.active));
  const gameEntry=useRef<HTMLButtonElement>(null);
  const tickGame=useCallback(()=>commit('gameTick'),[commit]);
  const [heartBursts, setHeartBursts] = useState<number[]>([]);
  const [shellBursts, setShellBursts] = useState<{ id: number; strength: number }[]>([]);
  const nextShellBurst = useRef(0);
  const eggHatching = useRef(false);
  const pendingCare=useRef<'bathing'|'lying'|null>(null);
  const removeShellBurst = useCallback((id: number) => setShellBursts(current => current.filter(burst => burst.id !== id)), []);
  const nextHeartBurst = useRef(0);
  const removeHeartBurst = useCallback((id: number) => setHeartBursts(current => current.filter(burst => burst !== id)), []);
  const canvas = useRef<HTMLCanvasElement>(null);
  const groundShadow=useRef<HTMLDivElement>(null);
  const bubbleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bathAction = useRef<HTMLButtonElement>(null);
  const doorAction = useRef<HTMLButtonElement>(null);
  const returnFocus = useRef(false);
  const { night, time } = environment;
  const language = languageChoice === 'auto' ? environment.language : languageChoice;
  const notifications=useMokiNotifications(pet,language);
  const t = mokiFamilyCopy.get(variant,language);
  const isEgg = pet.stage === 'egg';
  const isDead=pet.life.diedAt!==null;
  const voiceVisible=useRef(false);
  voiceVisible.current=!showWelcome&&!guideOpen&&!closetOpen&&!gameOpen&&!explorationOpen&&!isDead;
  const inBath = place === 'bath';
  const inGym = place === 'gym';
  const dock=isRobot&&place==='room'?mokiRobotMotion.dock(phase,dockStep,lessMotion):{left:50,travel:0,cable:0,state:'off'};
  const resting = phase === 'lying' || phase === 'sleeping';
  const busy = Boolean(pet.expedition || pet.workout || pet.minigame || pet.memory?.active) || (phase !== 'idle' && phase !== 'sleeping');
  const condition = mokiCondition.read(pet);
  const conditionRef = useRef(condition);
  conditionRef.current = condition;
  const outfitRef=useRef(pet.player.wardrobe.equipped);
  outfitRef.current=pet.player.wardrobe.equipped;
  const outfitKey=Object.values(pet.player.wardrobe.equipped).join(',');
  const idleCondition = phase === 'idle' ? Number(condition.dirty) + Number(condition.veryDirty)*2 + Number(condition.hungry)*4 + Number(condition.sad)*8 : 0;
  const conditionDescription = [condition.dirty ? t.needsBath : '', condition.hungry ? t.feelsHungry : '', condition.sad ? t.feelsSad : ''].filter(Boolean).join(', ');
  const evolution = mokiPet.progress(pet);
  const nextStage = evolution.next as 'baby' | 'teen' | 'adult';
  const eggFrame = pet.eggTaps >= 4 ? 5 : pet.eggTaps >= 3 ? 4 : pet.eggTaps >= 2 ? 3 : 0;
  const needs: { key: string; icon: Icon; value: number; label: string; help: string; warning: boolean }[] = [
    { key: 'hunger', icon: isRobot?'battery':'food', value: isRobot?100-pet.hunger:pet.hunger, label: t.hunger, help: t.hungerHelp, warning: pet.hunger >= 70 },
    { key: 'fatigue', icon: isRobot?'power':'moon', value: pet.fatigue, label: t.fatigue, help: t.fatigueHelp, warning: pet.fatigue >= 70 },
    { key: 'dirt', icon: isRobot?'tool':'drop', value: pet.dirt, label: t.dirt, help: t.dirtHelp, warning: pet.dirt >= 70 },
    { key: 'mood', icon: pet.mood >= 50 ? 'happy' : pet.mood >= 25 ? 'neutral' : 'sad', value: pet.mood, label: t.mood, help: t.moodHelp, warning: pet.mood < 40 }
  ];

  const say = useCallback((message: Message) => {
    if (bubbleTimer.current) clearTimeout(bubbleTimer.current);
    setBubble(message);
    bubbleTimer.current = setTimeout(() => setBubble(null), 2600);
  }, []);

  useEffect(() => {
    const sync = () => setEnvironment(config.environment());
    const timer = setInterval(sync, 15000);
    window.addEventListener('focus', sync);
    window.addEventListener('languagechange', sync);
    document.addEventListener('visibilitychange', sync);
    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', sync);
      window.removeEventListener('languagechange', sync);
      document.removeEventListener('visibilitychange', sync);
    };
  }, []);

  useEffect(() => {
    let active = true;
    setSheets(null);setAssetError(false);
    const sources = [...Object.values(art.stageSheets).flat(), art.egg.src];
    Promise.all(sources.map(mokiCanvas.load)).then(images => { if (active) {loadedVariant.current=variant;setSheets(images);} }).catch(() => { if (active) setAssetError(true); });
    return () => { active = false; };
  }, [variant]);

  useEffect(() => {
    if (isDead || !sheets || !canvas.current) return;
    const ctx = canvas.current.getContext('2d');
    if (!ctx) return;
    if(loadedVariant.current!==variant){ctx.clearRect(0,0,64,64);return;}
    ctx.imageSmoothingEnabled = false;
    if(groundShadow.current) {
      groundShadow.current.style.removeProperty('transform');
      groundShadow.current.style.removeProperty('opacity');
    }
    delete canvas.current.dataset.workoutPose;
    const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (isEgg && phase !== 'hatching') {
      const [x,y,w,h] = art.egg.frames[eggFrame];
      const dw = Math.round(w * art.egg.scale), dh = Math.round(h * art.egg.scale);
      const paintEgg=()=>{
        ctx.clearRect(0,0,64,64);
        ctx.drawImage(sheets[12], x,y,w,h, Math.round((64-dw)/2),variant==='green'?59-dh:0,dw,dh);
        mokiAlienMotion.draw(ctx,variant,performance.now(),'egg',reducedMotion);
        mokiDivineMotion.draw(ctx,variant,performance.now(),'egg',reducedMotion);
        mokiRobotMotion.draw(ctx,variant,performance.now(),'egg',reducedMotion,lightSeed);
      };
      paintEgg();canvas.current.dataset.frame = String(eggFrame);
      const lightTimer=(isAlien||isRobot||isDivine)&&!reducedMotion?setInterval(paintEgg,140):undefined;
      return()=>clearInterval(lightTimer);
    }
    const animation = mokiVariantArt.animation(variant,phase);
    const frames = idleCondition ? [0,1,2,3,2,1,0,1,0] : phase === 'idle' && variant==='green' && pet.stage !== 'adult' ? [0,1,2,3,2,1,0,5,7] : animation.frames;
    const times = idleCondition && conditionRef.current.sad ? [1200,500,180,400,180,500,850,500,700] : animation.times;
    const cycles = animation.cycles;
    const sheet = animation.sheet + (pet.stage === 'baby' ? 0 : pet.stage === 'teen' ? 4 : 8);
    const removal=phase==='undressing' && pet.stage!=='egg' ? mokiAccessories.prepareRemoval(sheets[sheet],pet.stage,outfitRef.current,mokiVariantArt.eyes(variant,pet.stage,'idle',0),wrappedFit,variant) : null;
    let index = 0, completed = 0;
    let timer: ReturnType<typeof setTimeout>,lightTimer:ReturnType<typeof setInterval>|undefined;
    let finished=false;
    const paint = () => {
      if(finished)return;
      const now=performance.now(),hover=mokiAlienMotion.hover(variant,phase,now,reducedMotion)+mokiDivineMotion.hover(variant,phase,now,reducedMotion);
      ctx.clearRect(0,0,64,64);
      ctx.save();ctx.translate(0,hover);
      if (isEgg) {
        const [x,y,w,h] = art.egg.frames[frames[index]];
        const scale = art.egg.scale;
        const dw = Math.round(w * scale), dh = Math.round(h * scale);
        ctx.drawImage(sheets[12], x,y,w,h, Math.round((64-dw)/2),variant==='green'?59-dh:0,dw,dh);
      } else {
        if(phase==='exercising' && workoutSheets && pet.stage!=='egg') {
          const motion=mokiWorkoutAnimation.draw(ctx,workoutSheets[pet.stage],sheets[sheet],index,reducedMotion,mokiVariantArt.offsets(variant),variant==='nebula'||isRobot||isDivine);
          if(canvas.current)canvas.current.dataset.workoutPose=motion.pose;
          if(groundShadow.current) {
            groundShadow.current.style.transform=`scaleX(${motion.shadowScale})`;
            groundShadow.current.style.opacity=String(motion.shadowOpacity);
          }
        } else ctx.drawImage(sheets[sheet],phase==='exercising' ? 0 : frames[index]*64,0,64,64,0,0,64,64);
      }
      mokiAlienMotion.draw(ctx,variant,now,phase,reducedMotion);
      mokiDivineMotion.draw(ctx,variant,now,phase,reducedMotion);
      mokiRobotMotion.draw(ctx,variant,now,phase,reducedMotion,lightSeed);
      const fit=pet.stage!=='egg'?mokiVariantArt.eyes(variant,pet.stage,phase,frames[index],index,reducedMotion):undefined;
      if (!isEgg && phase === 'idle') mokiCondition.draw(ctx, pet.stage, frames[index], conditionRef.current,fit?{eyes:fit,ink:family.ink,cream:family.cream,bird:wrappedFit}:undefined);
      if(removal)mokiAccessories.drawRemoval(ctx,removal,index,reducedMotion);
      else if(pet.stage!=='egg')mokiAccessories.draw(ctx,pet.stage,phase==='exercising' && !workoutSheets ? 'idle' : phase,frames[index],outfitRef.current,index,reducedMotion,fit,wrappedFit,variant);
      ctx.restore();
      if (canvas.current) {
        canvas.current.dataset.frame = String(frames[index]);
        canvas.current.dataset.expression = phase !== 'idle' || isEgg ? 'action' : conditionRef.current.sad ? 'sad' : conditionRef.current.hungry ? 'hungry' : 'normal';
      }
    };
    const draw=()=>{
      if(isRobot)setDockStep(index);
      paint();
      if(reducedMotion && (phase==='exercising'||(isAlien||isRobot||isDivine)&&phase==='idle'))return;
      timer = setTimeout(() => {
        index++;
        if (index === frames.length) {
          completed++;
          if (cycles && completed >= cycles) {
            finished=true;clearInterval(lightTimer);
            if(phase==='undressing') {
              const next=pendingCare.current;pendingCare.current=null;
              if(next) {sound.play(next==='bathing' ? (isRobot?'maintain':'bath') : (isRobot?'powerDown':'sleep'));if(next==='lying')say('nap');}
              setDockStep(0);setPhase(next ?? 'idle');return;
            }
            const reaction=mokiVoices.afterAnimation(phase);
            if(reaction&&voiceVisible.current)sound.voice(variant,reaction);
            if (phase === 'hatching') { commit('hatch'); say('hatch'); }
            if (phase === 'lying') commit('sleep');
            if (phase === 'eating') { commit('feed'); say('fed'); }
            if (phase === 'bathing') { commit('bathe'); say('clean'); }
            setPhase(phase === 'lying' ? 'sleeping' : 'idle');
            return;
          }
          index = 0;
        }
        draw();
      },times[index]);
    };
    draw();
    if((isAlien||isRobot||isDivine)&&!reducedMotion)lightTimer=setInterval(paint,140);
    return () => {
      finished=true;clearInterval(lightTimer);clearTimeout(timer);
      groundShadow.current?.style.removeProperty('transform');
      groundShadow.current?.style.removeProperty('opacity');
    };
  },[isDead,phase,sheets,workoutSheets,say,commit,sound.play,sound.voice,pet.stage,variant,isEgg,eggFrame,idleCondition,outfitKey,lightSeed]);

  useEffect(()=>{
    let active=true;setWorkoutSheets(null);setWorkoutAssetError(false);
    const sources=art.workout ? Object.values(art.workout) : [mokiWorkoutAnimation.src];
    Promise.all(sources.map(mokiCanvas.load)).then(images=>{
      if(!active)return;
      if(!art.workout)setWorkoutSheets(mokiWorkoutAnimation.prepare(images[0]));
      else {
        const result={} as ReturnType<typeof mokiWorkoutAnimation.prepare>;
        (['baby','teen','adult'] as const).forEach((stage,i)=>{
          const sheet=document.createElement('canvas');sheet.width=256;sheet.height=64;
          const ctx=sheet.getContext('2d');if(!ctx)throw new Error('Cannot load workout');
          ctx.imageSmoothingEnabled=false;ctx.drawImage(images[i],0,0);result[stage]=sheet;
        });
        setWorkoutSheets(result);
      }
    }).catch(()=>{if(active)setWorkoutAssetError(true);});
    return()=>{active=false;};
  },[variant]);

  useEffect(() => {
    if (isEgg && pet.eggTaps === 5 && phase === 'idle') { eggHatching.current = true; setPhase('hatching'); }
    else if (pet.sleeping && phase === 'idle') setPhase('sleeping');
    else if (!pet.sleeping && phase === 'sleeping') setPhase('idle');
  },[pet.sleeping,phase,isEgg,pet.eggTaps]);
  useEffect(() => () => { if (bubbleTimer.current) clearTimeout(bubbleTimer.current); },[]);
  useEffect(() => {
    if (!isEgg) return;
    pendingCare.current=null;
    setPlace('room');
    setShowGrowth(false);
    setHeartBursts([]);
    setShellBursts([]);
    setClosetOpen(false);
    setGameOpen(false);
    setBubble(null);
    eggHatching.current = pet.eggTaps === 5;
    setPhase(pet.eggTaps === 5 ? 'hatching' : 'idle');
  }, [isEgg, pet.bornAt]);
  useEffect(() => {
    if (inBath) bathAction.current?.focus({preventScroll:true});
    else if (returnFocus.current) document.querySelector<HTMLButtonElement>('[data-testid="bath-control"]')?.focus({preventScroll:true});
  },[inBath]);

  useEffect(()=>{
    if(!pet.workout)return;
    const deadline=pet.workout.startedAt+mokiPet.workoutMs;
    const tick=()=>{
      const now=Date.now();setWorkoutNow(now);
      if(now>=deadline)commit('workoutTick');
    };
    tick();
    const timer=setInterval(tick,250);
    return()=>clearInterval(timer);
  },[pet.workout?.startedAt,commit]);
  useEffect(()=>{
    if(pet.workout) {
      previousWorkout.current=pet.workout.startedAt;
      setPlace('gym');setPhase('exercising');
    } else if(phase==='exercising') setPhase('idle');
    if(!pet.workout && previousWorkout.current!==null) {
      const fresh=mokiVoices.completedWorkout(previousWorkout.current,pet.lastWorkout,Date.now());
      previousWorkout.current=null;
      if(pet.lastWorkout?.complete) {
        say('workoutDone');
        if(fresh&&voiceVisible.current)sound.voice(variant,'exercise');
      }
    }
  },[pet.workout?.startedAt,pet.lastWorkout?.endedAt,phase,say,sound.voice,variant]);
  useEffect(()=>{
    if(inGym)gymAction.current?.focus({preventScroll:true});
    else if(returnGymFocus.current)gameEntry.current?.focus({preventScroll:true});
  },[inGym]);

  useEffect(()=>{
    if(!isDead)return;
    sound.stop();pendingCare.current=null;clearTimeout(bubbleTimer.current??undefined);
    setBubble(null);setHeartBursts([]);setShellBursts([]);setClosetOpen(false);setGameOpen(false);setShowGrowth(false);setPlace('room');setPhase('idle');
  },[isDead,sound.stop]);

  function openExploration(){exploreFromHub.current=false;setBubble(null);setShowGrowth(false);setExplorationOpen(true);}
  function exploreFromPlay(){hubHandoff.current=true;setGameOpen(false);openExploration();exploreFromHub.current=true;}
  function exerciseFromPlay(){hubHandoff.current=true;setGameOpen(false);enterGym();}
  function closeExploration(){setExplorationOpen(false);if(exploreFromHub.current)setGameOpen(true);else requestAnimationFrame(()=>gameEntry.current?.focus({preventScroll:true}));}
  function requireAwake() {
    if (isDead || busy || !sheets || !gymReady || isEgg) return false;
    if (resting) { say('wakeFirst'); return false; }
    return true;
  }
  function beginCare(next:'bathing'|'lying') {
    setBubble(null);
    if(isRobot&&next==='lying'){setDockStep(0);setPlace('room');}
    if(Object.values(outfitRef.current).some(Boolean)) {
      pendingCare.current=next;sound.play('button');setPhase('undressing');
    } else {
      sound.play(next==='bathing' ? (isRobot?'maintain':'bath') : (isRobot?'powerDown':'sleep'));setPhase(next);
      if(next==='lying')say('nap');
    }
  }
  function feed() {
    if (requireAwake() && pet.hunger >= 1) { sound.play(isRobot?'charge':'eat'); if(isRobot){setDockStep(0);setPlace('room');} setPhase('eating'); say('yummy'); }
    else { sound.play('button'); if (!resting && pet.hunger < 1) say('full'); }
  }
  function bathe() {
    if (requireAwake() && pet.dirt >= 1) beginCare('bathing');
    else { sound.play('button'); if (!resting && pet.dirt < 1) say('alreadyClean'); }
  }
  function enterBath() { if (requireAwake()) { returnFocus.current = true; setPlace('bath'); say('bathWelcome'); } }
  function enterCloset() { if(requireAwake()) {setShowGrowth(false);setBubble(null);setClosetOpen(true);} }
  function enterGame() {setShowGrowth(false);setBubble(null);setGameOpen(true);}
  function enterGym() {
    if(requireAwake()) { returnGymFocus.current=true;setShowGrowth(false);setBubble(null);setWorkoutNow(Date.now());setPlace('gym'); }
  }
  function startWorkout() {
    if(!requireAwake() || !gymReady || !workoutSheets)return;
    const next=commit('startWorkout');
    if(next.workout) { setWorkoutNow(Date.now());setBubble(null);setPhase('exercising'); }
    else say('workoutNeeds');
  }
  function stopWorkout() { commit('stopWorkout');setPhase('idle');setBubble(null);sound.stop(); }
  function toggleRest() {
    if (isDead || busy || !sheets || !gymReady || isEgg) return;
    if(resting) {sound.play(isRobot?'powerUp':'wake');commit('wake');setDockStep(0);setPhase('waking');say('awake');}
    else beginCare('lying');
  }
  function goBack() { pendingCare.current=null;if(pet.workout)commit('stopWorkout');sound.stop();setPhase('idle');setPlace('room');setBubble(null); }
  function petMoki() {
    if (isDead || !sheets || !gymReady) return;
    if (isEgg) {
      if (busy || eggHatching.current) return;
      const next = commit('tap');
      sound.play(next.eggTaps === 5 ? 'hatch' : 'crack', next.eggTaps);
      const id = ++nextShellBurst.current;
      setShellBursts(current => [...current.slice(-4), { id, strength: next.eggTaps }]);
      setBubble(null);
      if (next.eggTaps === 5) { eggHatching.current = true; setPhase('hatching'); }
      return;
    }
    sound.voice(variant,'pet');
    const id = ++nextHeartBurst.current;
    setHeartBursts(current => [...current.slice(-2), id]);
    setBubble(null);
    if (busy || resting) return;
    commit('affection');
  }

  function changeLanguage(value: 'auto'|'es'|'en') {
    setLanguageChoice(value);
    try { localStorage.setItem('moki.language.v1', value); } catch {}
  }
  function changeMagic(value: boolean) {
    setMagic(value);
    try { localStorage.setItem('moki.fireflies.v1', String(value)); } catch {}
  }
  function replaceMoki(group:typeof mokiVariants.families[number]) {
    const next=newEgg(group,pet.bornAt);
    if(next.bornAt===pet.bornAt)return false;
    pendingCare.current=null;
    sound.stop(); setPhase('idle'); setPlace('room'); setBubble(null);
    setHeartBursts([]); setShellBursts([]); setShowGrowth(false); eggHatching.current=false;
    if (bubbleTimer.current) clearTimeout(bubbleTimer.current);
    return true;
  }
  function selectStarter(group:typeof mokiVariants.families[number]){
    const next=chooseStarter(group);
    if(next.player.starterChosen){setPhase('idle');setPlace('room');setStartOpen(false);}
  }
  return <main className={styles.page} lang={language} data-family={family.family} style={{'--shell-outline':family.ink,'--shell-mint':family.color,'--shell-cream':family.cream} as React.CSSProperties} onClickCapture={event=>{
    const target=event.target as Element;
    if(target.closest('[data-testid="moki-menu-panel"], [data-testid="moki-closet"], [data-testid="firefly-game"], [data-testid="memory-game"], [data-testid="moki-games"], [data-testid="moki-challenges"], [data-testid="challenges-control"]')) return;
    const button=target.closest('button');
    if(!button || button.disabled || ['pet-touch','warm-egg','affection','feed','bathe','rest'].includes(button.dataset.testid || '')) return;
    sound.play('button');
  }}>
    <Helmet><title>Moki - Virtual Pet</title><meta name="description" content={t.description} /><meta name="application-name" content="Moki"/><meta name="theme-color" content={mokiRelease.theme}/><link rel="manifest" href="/manifest.json"/><link rel="icon" type="image/png" href={mokiRelease.smallIcon}/><link rel="apple-touch-icon" href={mokiRelease.smallIcon}/></Helmet>
    <MokiGuide open={guideOpen} onOpenChange={changeGuide} language={language}/>
    <MokiCloset open={closetOpen} onOpenChange={setClosetOpen} onReturnFocus={()=>doorAction.current?.focus({preventScroll:true})} pet={pet} saved={saved} language={language} idleImage={sheets?.[pet.stage==='baby' ? 0 : pet.stage==='teen' ? 4 : 8] ?? null} onBuy={buyAccessory} onEquip={equipAccessory} onClickSound={()=>sound.play('button')} onBuySound={()=>sound.play('heart')}/>
    <MokiGames onExplore={exploreFromPlay} onExercise={exerciseFromPlay} exerciseDisabled={isDead||isEgg||resting||busy||!sheets||!gymReady} open={!showWelcome&&gameOpen} onOpenChange={setGameOpen} onReturnFocus={()=>{if(hubHandoff.current){hubHandoff.current=false;return;}gameEntry.current?.focus({preventScroll:true});}} pet={pet} language={language} saved={saved} disabled={isDead || isEgg || resting || phase!=='idle' || !sheets || !gymReady || Boolean(pet.workout || pet.expedition)} onStart={startGame} onStop={stopGame} onTick={tickGame} onCatch={catchFirefly} onMemoryStart={startMemory} onMemoryPause={pauseMemory} onMemoryFlip={flipMemory} onSound={effect=>sound.play(effect)}/>
    <div className={styles.app}>
      {showWelcome&&<MokiWelcome pet={pet} language={language} saved={saved} onContinue={()=>setStartOpen(false)} onChoose={selectStarter} onGuide={()=>changeGuide(true)}/>}
      {!showWelcome&&explorationOpen&&<MokiExploration pet={pet} language={language} saved={saved} busy={phase!=='idle'&&phase!=='sleeping'||Boolean(pet.workout||pet.minigame||pet.memory?.active)} onBack={closeExploration} onStart={route=>{const next=startExpedition(route);if(next.expedition){setPlace('room');setBubble(null);sound.play('button');}}} onRecall={recallExpedition} onClaim={id=>{claimExpedition(id);sound.play('heart');}} onTick={tickGame}/>}
      <section hidden={showWelcome||explorationOpen} data-away={Boolean(pet.expedition)} className={`${styles.room} ${night ? styles.night : ''}`} aria-label={inGym ? t.gym : inBath ? t.bath : t.room} data-night={night} data-phase={phase} data-place={place} data-dead={isDead} data-stage={pet.stage} data-variant={variant} data-family={family.family}>
        <MokiScene family={family.family} place={place} night={night} alt={inGym?t.gymAlt:inBath?t.bathAlt:t.roomAlt} onReady={setGymReady} onError={()=>setAssetError(true)}/>
        <div className={styles.sceneShade} />
        <header className={styles.hud}>
          <div className={styles.topRow}><div className={styles.brand}><h1 className={styles.wordmark}>MOKI</h1><span className={styles.location}>{inGym ? t.gym : inBath ? t.bath : t.room}</span></div><MokiChallenges pet={pet} language={language} saved={saved} onClaim={claimChallenges} onClickSound={()=>sound.play('button')} onRewardSound={()=>sound.play('hatch')}/><span className={styles.clock} title={t.autoHelp} data-testid="local-clock"><PixelIcon name={night ? 'moon' : 'sun'} size={12}/>{time}</span></div>
          <div className={styles.petInfo}><span className={styles.petSummary}><strong title={pet.name}>{pet.name}</strong><span>{isDead?(language==='es'?'En recuerdo':'In memory'):`${t[pet.stage]} · ${t.dayLabel} ${evolution.day}`}</span></span><div className={styles.hudActions}><span className={styles.wallet} title={t.starsHelp}><PixelIcon name="coin" size={16}/><output data-testid="star-balance" aria-label={t.stars} aria-live="polite">{pet.player.stars}</output></span><MokiMenu notifications={notifications} onGuide={()=>changeGuide(true)} pet={pet} saved={saved} busy={busy||Boolean(pet.expeditionReward)} language={language} languageChoice={languageChoice} onLanguage={changeLanguage} sound={sound.enabled} onSound={sound.setEnabled} onPreview={()=>sound.voice(variant,'pet')} onClickSound={()=>sound.play('button')} magic={magic} onMagic={changeMagic} onRename={rename} onNewEgg={replaceMoki}/></div></div>
          {!isDead && !isEgg && <div className={styles.needs}>{needs.map(({key,icon,value,label,help,warning}) => <div key={key} className={`${styles.need} ${warning ? styles.needWarning : ''}`} title={`${label}: ${Math.round(value)}%. ${help}`}>
            <div className={styles.needValue}><PixelIcon name={icon} size={15}/><output data-testid={`stat-${key}`} aria-label={`${label}: ${Math.round(value)}%`} data-value={value}>{Math.round(value)}<small>%</small></output></div>
            <Progress className={styles.needBar} value={value} aria-label={label}/>
          </div>)}</div>}
          {!isDead&&<MokiLifeNotice pet={pet} language={language}/>}
        </header>
        {isDead&&<MokiLifeNotice pet={pet} language={language} memorial/>}
        <div className={`${styles.lantern} ${styles.lanternLeft}`}/><div className={`${styles.lantern} ${styles.lanternRight}`}/>
        {!isDead && place==='room' && <Button ref={doorAction} variant="ghost" className={styles.door} data-testid="closet-door" aria-label={t.enterCloset} disabled={!sheets || !gymReady || busy || isEgg} onClick={enterCloset}><span className={styles.doorLabel}>{t.closet}</span></Button>}
        {place==='room' && <Button ref={gameEntry} variant="ghost" className={styles.gamesButton} data-testid="games-control" onClick={enterGame} aria-label={pet.expeditionReward?(language==='es'?'Jugar: hay hallazgos para recoger':'Play: discoveries ready to collect'):t.play}><PixelIcon name="game" size={18}/><span>{t.play}</span>{pet.expeditionReward&&<i className={styles.activityBadge} aria-hidden="true"/>}</Button>}
        {pet.expedition&&<div className={styles.travelNotice} role="status"><strong>{language==='es'?'Moki está explorando':'Moki is exploring'}</strong><span>{mokiExplorationThemes.get(pet.variant,language).routes[pet.expedition.route].name}</span><Button className={styles.control} onClick={openExploration}>{language==='es'?'Ver viaje':'View trip'}</Button></div>}
        {magic && <div className={styles.magic} aria-hidden="true" data-testid="fireflies">{fireflies.map(([left,top,delay],i)=><i key={i} className={styles.firefly} style={{left:`${left}%`,top:`${top}%`,animationDelay:`${-delay}s`}}/>)}</div>}
        {!isDead && !isEgg && !inGym && <Button variant="ghost" className={styles.evolution} onClick={()=>setShowGrowth(v=>!v)} aria-expanded={showGrowth} aria-label={t.evolution}>
          <span className={styles.evolutionTarget}>{pet.stage === 'adult' ? 'MAX' : t[nextStage]}</span>
          <span className={styles.evolutionDots} role="progressbar" aria-label={t.evolution} aria-valuemin={0} aria-valuemax={100} aria-valuenow={evolution.percent} data-testid="evolution">{Array.from({length:10},(_,i)=><i key={i} className={`${styles.evolutionDot} ${evolution.percent >= (i+1)*10 ? styles.litDot : ''}`}/>)}</span>
          <strong>{evolution.percent}<small>%</small></strong>
        </Button>}
        {!isDead && !isEgg && !inGym && showGrowth && <div className={styles.growthPanel}><strong>{t[pet.stage]} → {pet.stage === 'adult' ? t.completed : t[nextStage]}</strong><p>{isEgg ? t.hatchHelp : t.evolutionHelp}</p>{!isEgg && pet.stage !== 'adult' && <p>{t.ageRequirement} {evolution.ageHours}/{evolution.targetHours}h<br/>{t.careRequirement} {evolution.care}/{evolution.targetCare}<br/>{t.mood} {Math.round(pet.mood)}/50%</p>}</div>}
        {inGym && !isEgg && <MokiWorkoutPanel pet={pet} now={pet.workout ? workoutNow : Date.now()} language={language}/>}
        {!isDead&&isRobot&&place==='room'&&!isEgg&&!pet.expedition&&<MokiDock phase={phase} step={dockStep} stage={pet.stage} reduced={lessMotion}/>}
        <div hidden={isDead} ref={groundShadow} style={isRobot?{left:`${dock.left-(inGym?10:place==='room'?13.5:11.5)}%`}:undefined} className={styles.petShadow}/>
        <Button variant="ghost" className={styles.pet} style={isRobot?{left:`${dock.left}%`,zIndex:2}:undefined} hidden={isDead} data-testid="pet-touch" aria-label={isEgg ? t.warm : t.affection} onClick={petMoki} disabled={isDead || !sheets || !gymReady}>
          <canvas ref={canvas} width={64} height={64} className={styles.sprite} role="img" aria-label={isEgg ? t.egg : `${pet.name}, ${family.name[language]}: ${conditionDescription || t.idleStatus}`} data-ready={Boolean(sheets)}/>
          {!isDead && sheets && <MokiConditionEffects robot={isRobot} stage={pet.stage} dirt={pet.dirt} hunger={pet.hunger} mood={pet.mood} phase={phase} quiet={Boolean(bubble) || heartBursts.length>0}/>}
        </Button>
        {bubble && <div className={styles.bubble} role="status">{t[bubble]}</div>}
        {heartBursts.map(id => <PetHearts center={dock.left} key={id} id={id} onComplete={removeHeartBurst} />)}
        {shellBursts.map(burst => <EggShellBurst key={burst.id} id={burst.id} strength={burst.strength} onComplete={removeShellBurst} />)}
        {(!sheets || !gymReady) && !assetError && <div className={styles.message}>{t.ready}</div>}
        {inGym && !workoutSheets && !workoutAssetError && sheets && <div className={styles.message}>{t.ready}</div>}
        {(assetError || (inGym && workoutAssetError)) && <div className={styles.message} role="alert">{t.error}</div>}
        <footer className={styles.bottomHud}>
          <nav className={`${styles.controls} ${isEgg || isDead ? styles.eggControls : ''} ${inGym ? styles.gymControls : ''}`} aria-label={t.controls}>
            {isDead ? <Button className={styles.control} data-testid="new-egg-after-death" disabled={Boolean(pet.expeditionReward)} onClick={()=>replaceMoki(mokiVariants.family(variant))}><PixelIcon name="egg"/><span>{language==='es'?'Nuevo huevo':'New egg'}</span></Button> : isEgg ? <Button className={`${styles.control} ${styles.careControl}`} data-testid="warm-egg" disabled={!sheets || !gymReady || busy} onClick={petMoki}><PixelIcon name="egg"/><span>{t.warm}</span></Button> :
              inGym ? <>
                <Button variant="ghost" className={styles.control} data-testid="back-room" aria-label={t.backLabel} onClick={goBack}><PixelIcon name="back"/><span>{t.back}</span></Button>
                <Button ref={gymAction} variant="ghost" className={styles.control} data-testid={pet.workout ? 'stop-workout' : 'start-workout'} disabled={!pet.workout && (!sheets || !gymReady || !workoutSheets || busy || resting || pet.hunger>=80 || pet.fatigue>=80)} onClick={pet.workout ? stopWorkout : startWorkout}><PixelIcon name={pet.workout ? 'stop' : 'exercise'}/><span>{pet.workout ? t.stopExercise : t.startExercise}</span></Button>
              </> : <>
                {inBath ? <><Button variant="ghost" className={styles.control} data-testid="back-room" aria-label={t.backLabel} onClick={goBack}><PixelIcon name="back"/><span>{t.back}</span></Button><Button ref={bathAction} variant="ghost" className={`${styles.control} ${styles.careControl}`} data-testid="bathe" disabled={!sheets || !gymReady || busy} onClick={bathe}><PixelIcon name={isRobot?"tool":"bath"}/><span>{t.wash}</span></Button></> :
                  <><Button variant="ghost" className={`${styles.control} ${styles.careControl}`} data-testid="feed" disabled={!sheets || !gymReady || busy} onClick={feed}><PixelIcon name={isRobot?"battery":"food"}/><span>{t.food}</span></Button><Button variant="ghost" className={styles.control} data-testid="rest" aria-pressed={resting} disabled={!sheets || !gymReady || busy} onClick={toggleRest}><PixelIcon name={isRobot?"power":"sleep"}/><span>{resting ? t.wake : t.sleep}</span></Button></>}
                {!inBath && <Button variant="ghost" className={styles.control} data-testid="bath-control" disabled={!sheets || !gymReady || busy} onClick={enterBath}><PixelIcon name={isRobot?"tool":"bath"}/><span>{t.door}</span></Button>}
              </>}
          </nav>
          <div className={styles.saveHint} role={!saved ? 'alert' : undefined}>{!saved ? t.saveError : isDead ? (language==='es'?'Tus monedas y accesorios se conservan.':'Your coins and accessories are kept.') : isEgg ? t.eggHint : inGym && pet.workout ? t.workoutContinue : t.savedHere}</div>
        </footer>
      </section>
    </div>
  </main>;
}
